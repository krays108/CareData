package com.care.BOBDLPAPI.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.care.BOBDLPAPI.dto.TrackMyStatus;
import com.care.BOBDLPAPI.dto.WorkflowStatusDto;
import com.care.BOBDLPAPI.repository.AcfRequestRepository;
import com.care.BOBDLPAPI.util.DlpUtil;

@Service
public class AcfRequestService {
	@Autowired
	AcfRequestRepository acfRequestRepository;

	@Autowired
	DlpUtil dlpUtil;

	public ResponseEntity<?> getWorkflowStatus(Long mobile) {

		List<WorkflowStatusDto> statusList = acfRequestRepository.findStatusByWorkflow(mobile);
		if (statusList.isEmpty()) {
			return ResponseEntity.ok(dlpUtil.WORKFLOW_STATUS);
		}
		return ResponseEntity.ok(statusList);

	}

	public ResponseEntity<?> getStatus(Long mobile) {

		List<String> customerIdList = acfRequestRepository.findCustomerIdByMobile(mobile);
		if(customerIdList.isEmpty()) {
			return ResponseEntity.ok(dlpUtil.INVALID_CUSTOMER);		}
		List<WorkflowStatusDto> trackMyStatus = new ArrayList<>();
		
		customerIdList.forEach(customerId -> {
		Integer acfRequestId=	acfRequestRepository.findACFRequestIdByCustomerId(customerId);
		
		Integer statusValue=acfRequestRepository.findStatusByACFRequestId(acfRequestId);
	
	List<WorkflowStatusDto>	 workFlowStatus=acfRequestRepository.findStatus(statusValue,customerId);
		
		trackMyStatus.addAll(workFlowStatus);
		});
		if (trackMyStatus.isEmpty()&& !customerIdList.isEmpty()) {
			
			List<TrackMyStatus> trackMyStatusList=new ArrayList<>();
			customerIdList.forEach(custId ->{
			List<WorkflowStatusDto> status=acfRequestRepository.findStatusByCustomerId(custId);
			
		
			status.forEach(n ->{
				TrackMyStatus tMyStatus= new TrackMyStatus();
				tMyStatus.setEmail(n.getEmail());
				tMyStatus.setFullName(n.getFull_name());
				tMyStatus.setLoanAmount(n.getLoan_amount());
				tMyStatus.setLoanType(n.getLoan_type());
				tMyStatus.setMobile(n.getMobile());
				tMyStatus.setPurposeOfLoan(n.getPurpose_of_loan());
				tMyStatus.setStatus("Pending");
				tMyStatus.setLoanReferenceNo(n.getCustomer_id());
				tMyStatus.setUniqueIdentifierNumber(n.getUnique_identifier_number());
				trackMyStatusList.add(tMyStatus);
				
			});
			
			});
			
			return ResponseEntity.ok(trackMyStatusList);
		}
		

		return ResponseEntity.ok(trackMyStatus)  ;
	}

}
