package com.care.BOBDLPAPI.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public interface TransactionDetailsDto {

	@JsonProperty(value = "loanReferenceNo")
	public String getCustomer_id();
	
	@JsonProperty(value = "fullName")
	public String getFull_name();
	
	@JsonProperty(value = "loanType")
	public String getLoan_type();
	
	@JsonProperty(value = "status")
	public String getStatus();
	
	@JsonProperty(value = "purposeOfLoan")
	public String getPurpose_of_loan();
		
	@JsonProperty(value = "loanAmount")
	public Integer getLoan_amount();
	
	@JsonProperty(value = "UniqueIdentifierNumber")
	public String getUnique_identifier_number();
	
	@JsonProperty(value = "product")
	public String getProduct();
	
	@JsonProperty(value = "subProduct")
	public String getSub_product();
	
	@JsonProperty(value = "productTypeId")
	public Integer getProduct_type_id();
	
}
