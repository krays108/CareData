package com.care.BOBDLPAPI.service;

import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.care.BOBDLPAPI.model.OtpEntity;
import com.care.BOBDLPAPI.repository.OtpRepository;
import com.care.BOBDLPAPI.util.BobMailSender;
import com.care.BOBDLPAPI.util.DlpUtil;

@Service
public class OtpService {

	@Autowired
	OtpRepository otpRepository;
	
	@Autowired DlpUtil dlpUtil;
	
	@Autowired   BobMailSender bobMailSender;

	public ResponseEntity<String> generateOtp(String email) {
		
		if(email==null) {
			ResponseEntity.ok(dlpUtil.EMAIL_IS_NULL);
		}

		Random random = new Random();
		// algorithm to generate OTP
		int otp = 100000 + random.nextInt(900000);
		
		String subject=dlpUtil.OTP_SUBJECT;
		String body=otp+dlpUtil.OTP_BODY;
		
		//smtp server config method
	String mail=	bobMailSender.sendEmail(email,subject, body);
	
	if(mail.equalsIgnoreCase(dlpUtil.OTP_FAILED)) {
		return ResponseEntity.ok(dlpUtil.FAILURE_STATUS_CODE);
	}

		OtpEntity otpEntity = new OtpEntity();
		otpEntity.setOtp(otp);
		otpEntity.setStatus(dlpUtil.OTP_PENDING);
		otpEntity.setEmail(email);
		otpRepository.save(otpEntity);
		return ResponseEntity.ok(dlpUtil.SUCCESS_STATUS_CODE);
	}

	public ResponseEntity<String> submitOtp(Integer otp,String email) {
		
		//To get the OTP details from the Table
		OtpEntity otpEntity = otpRepository.findByOtpAndEmail(otp,email);
		if(otpEntity==null) {
			return ResponseEntity.ok(dlpUtil.INVALID_OTP);
		}
		
		//current System time in Milliseconds 
		Long currentTime= System.currentTimeMillis();
		
		// to check whether the OTP is expired or not
		if (currentTime> otpEntity.getExpiryTime()||otpEntity.getStatus().equalsIgnoreCase(dlpUtil.OTP_VERIFIED)
				||otpEntity.getStatus().equalsIgnoreCase(dlpUtil.OTP_EXPIRED))
		{
			
			OtpEntity expiredOtp = otpRepository.findByOtp(otp);
			expiredOtp.setStatus(dlpUtil.OTP_EXPIRED);
			otpRepository.save(expiredOtp);
			return ResponseEntity.ok(dlpUtil.EXPIRED_OTP_MESG);
		}
		//Valid OTP
		otpEntity.setStatus(dlpUtil.OTP_VERIFIED);
		otpRepository.save(otpEntity);
		return ResponseEntity.ok(dlpUtil.SUCCESS_OTP);
	}

}
