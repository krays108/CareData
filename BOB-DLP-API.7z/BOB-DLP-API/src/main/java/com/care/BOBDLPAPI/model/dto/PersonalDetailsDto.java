package com.care.BOBDLPAPI.model.dto;
import java.sql.Date;
import java.sql.Timestamp;
import java.time.LocalDateTime;

import lombok.Data;
@Data
public class PersonalDetailsDto {
	
	public Long personalDtlsId;
	
	public String customerId;
	
	public Long eligibleLoanAmt;
	
	public String purposeOfLoan;
	
	public Float eligibleInt;
	
	public Integer eligibleTenor;
	
	public Float eligibleEmi;
	
	public String existingCustomer;
	
	public String aadharNumber;
	
	public String panNumber;
	
	public String otherProof;
	
	public String otherProofDtls;
	
	public String ckycId;
	
	public String fatca;
	
	public String firstName;
	
	public String middleName;
	
	public String lastName;
	
	public String gender;
	
	public Long mobileNumber;
	
	public Date dob;
	
	public String emailId;
	
	public String martialStatus;

	public String qualification;
	
	public String nationality;
	
	public String residenceType;
	
	public String currAdd1;
	
	public String currAdd2;
	
	public String currLandmark;
	
	public String currCity;
	
	public String currState;
	
	public String currCountry;
	
	public String currPincode;
	
	public String currSamePerm;
	
	public String permAdd1;
	
	public String permAdd2;
	
	public String permLandmark;
	
	public String permCity;
	
	public String permState;
	
	public String permCountry;
	
	public String permPincode;
	
	public Timestamp createdDate =Timestamp.valueOf(LocalDateTime.now());
	
	public String otherProffSpecify;
	
	public String otherQualification;
	
	public String otherNationality;
	
	public String otherResidence;
	
	public String applicantType;
	
	public String coApplicantCustomerId;
	
	public Long noOfCoapplicant;

}
