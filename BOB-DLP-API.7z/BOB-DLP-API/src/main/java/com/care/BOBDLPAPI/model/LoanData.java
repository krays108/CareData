package com.care.BOBDLPAPI.model;

import java.sql.Timestamp;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "DLP_LOAN_DATA")
@SequenceGenerator(name = "loandata_detail", sequenceName = "loandata_detail", allocationSize = 1)

public class LoanData {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "loandata_detail")
	public Long loanDataId;

	@Column(length = 1000)
	public String customerId;

	@Lob
	public String jsonData;

	public String description;

	@Column(columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
	public Timestamp createdDate = Timestamp.valueOf(LocalDateTime.now());

	public Integer revisionNumber;

	@Column(length = 1, columnDefinition = "INTEGER DEFAULT 0")
	public Integer isValidated;

	public Integer journeySetuId;

	public String uniqueIdentifier;

	public String uniqueIdentifierNumber;

}
