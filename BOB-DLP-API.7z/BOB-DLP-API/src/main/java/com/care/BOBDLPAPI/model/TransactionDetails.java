package com.care.BOBDLPAPI.model;

import java.sql.Timestamp;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "DLP_TRANSACTION_DETAILS")
@SequenceGenerator(name = "trans_seq", sequenceName = "trans_seq", allocationSize = 1)
public class TransactionDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "trans_seq")
	public Long transactionId;

	@Column(length = 2000, nullable = false)
	public String customerId;

	@Column(length = 200)
	public String fullName;

	public Long mobile;

	@Column(length = 200)
	public String email;

	@Column(length = 100)
	public String loanType;

	@Column(length = 200)
	public String purposeOfLoan;

	public Integer loanAmount;

	public Float loanIntRate;

	public Integer loanTenor;

	public Float loanEmi;

	public Float loanFees;

	public Float loanCharges;

	public String status;

	public Timestamp createdDate = Timestamp.valueOf(LocalDateTime.now());

	public String uniqueIdentifier;

	public String uniqueIdentifierNumber;

}
