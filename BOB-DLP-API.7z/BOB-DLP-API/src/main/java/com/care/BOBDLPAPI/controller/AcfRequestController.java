package com.care.BOBDLPAPI.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.care.BOBDLPAPI.service.AcfRequestService;

import io.swagger.annotations.Api;

@Api(tags = "APPLICATION STATUS")
@CrossOrigin(origins="*")
@RestController
@RequestMapping(value =  "/dlp/api",produces="application/json"  )
public class AcfRequestController {
@Autowired
AcfRequestService acfRequestService;

//@ApiIgnore
@GetMapping("/trackMyStatus")
public ResponseEntity<?> getWorkflowStatus(@RequestHeader Long mobile){
	return acfRequestService.getWorkflowStatus(mobile);
}

@GetMapping("/getWorkflowStatus")
public ResponseEntity<?> getStatus(@RequestHeader Long mobile){
	return acfRequestService.getStatus(mobile);
}

}
