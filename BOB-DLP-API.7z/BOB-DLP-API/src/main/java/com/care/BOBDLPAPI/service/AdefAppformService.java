package com.care.BOBDLPAPI.service;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.care.BOBDLPAPI.dto.AdefXmlDto;
import com.care.BOBDLPAPI.dto.EntityDto;
import com.care.BOBDLPAPI.dto.EntryFormRule;
import com.care.BOBDLPAPI.dto.LosDataForm;
import com.care.BOBDLPAPI.dto.Msection;
import com.care.BOBDLPAPI.model.Section;
import com.care.BOBDLPAPI.repository.AdefRepository;
import com.care.BOBDLPAPI.util.BobUtil;
import com.care.BOBDLPAPI.util.DlpUtil;
import com.fasterxml.jackson.databind.JsonNode;

@Service
public class AdefAppformService {

	@Autowired
	AdefRepository adefRepository;

	
	@Autowired
	BobUtil bobUtil;

	@Autowired
	DlpUtil dlpUtil;
	
	
	
	 

	public ResponseEntity<?> getXmlData(Integer journeySetupId,String uniqueIdentifier) {
		AdefXmlDto xmlData = adefRepository.getXmlData(journeySetupId);
		if(xmlData==null) {
			return ResponseEntity.ok("XML data is null ");
		}
		String xmlString = bobUtil.clobToString(xmlData.getXml_data());

		JsonNode node;
		node = bobUtil.convertXmlToJsonNode(xmlString);
		
		JsonNode MsectionList = node.get(dlpUtil.M_SECTION);
		List<Section> responseList = new LinkedList<>();
		List<Msection> losDataFormList = new LinkedList<>();
		LosDataForm losDataForm=new LosDataForm();
		MsectionList.forEach(mSection -> {
			
			JsonNode visibilityType=mSection.get(dlpUtil.VISIBILITY_TYPE);
			
			if(visibilityType==null || visibilityType.asBoolean()) {
				
			List<Section> entryFormlist = bobUtil.getEntryForm(mSection,uniqueIdentifier);
			List<Section> dynamicGridList = bobUtil.getDynamicColumnGrid(mSection,uniqueIdentifier);
			String mSectionSeq = mSection.get(dlpUtil.SEQUENCE_NUMBER).textValue();
			List<Section> combinedList = new ArrayList<>();
			combinedList.addAll(entryFormlist);
			combinedList.addAll(dynamicGridList);
			combinedList.stream().sorted();
		//	responseList.addAll(combinedList);
			Msection mSectionList = new Msection();
		//	losDataResponse.setDropdownEntryFormRuleList(dropdwonRuleList);
			mSectionList.setEntryFormList(combinedList);
			mSectionList.setSequenceNumber(Integer.parseInt(mSectionSeq));
			mSectionList.setTitle(mSection.get(dlpUtil.TITLE).textValue());
			mSectionList.setDataKey(mSection.get(dlpUtil.DATA_KEY).textValue());
			
			losDataForm.setMSection(losDataFormList);
			
			
			losDataFormList.add(mSectionList);
			
			}
		});
		List<EntryFormRule> dropdownRuleList = bobUtil.getDropdownEntryformRule(node);
		List<EntryFormRule> dropdownGridRuleList = bobUtil.getDropdownGridRule(node);
		losDataForm.setDropdownEntryFormRuleList(dropdownRuleList);
		losDataForm.setDropdownGridRuleList(dropdownGridRuleList);
		
		losDataFormList.stream().sorted();
		return ResponseEntity.ok(losDataForm);
	}



	public ResponseEntity<?> getGewog(String code) {
		List<EntityDto> codeDetail = adefRepository.findEntityDtoByCode(code);
		if(codeDetail.isEmpty()) {
			return ResponseEntity.ok("Invalid Code");
		}
		return ResponseEntity.ok(codeDetail);
	}



	
	
	

	
	


}
