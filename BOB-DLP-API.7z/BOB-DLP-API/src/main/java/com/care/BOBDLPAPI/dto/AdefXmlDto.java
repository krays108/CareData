package com.care.BOBDLPAPI.dto;

import java.sql.Clob;

public interface AdefXmlDto {
	
	public Clob getXml_data();
	
	

}
