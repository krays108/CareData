package com.care.BOBDLPAPI.model.dto;

import java.sql.Date;

import org.springframework.stereotype.Component;

import lombok.Data;

@Data
@Component
public class ProductDto {
	
	public Integer productId;
	
	public Integer productTypeId;
	
	public String code;
	
	public String description;
	
	public Integer relatedTo;
	
	public Integer isCapChargeApplicable;
	
	public Integer exposureNatureIdStd;
	
	public Integer treatment;
	
	public Integer derivativeType;
	
	public Integer nature;
	
	public Integer isCancellable;
	
	public Integer isRevolving;
	
	public Double ccfValue;
	
	public Integer exposureCcfNatureIdDrawn;
	
	public Double fundingCost;
	
	public Double utilisationLevel;
	
	public Integer revisionNumber;
	
	public String limitAction;
	
	public Integer exposureCcfNatureIdIrb;
	
	public Integer exposureCcfNatureIdUndrawn;
	
	public String oldCode;
	
	public Integer productGroupId;
	
	public 	Integer isDlpGroup;
	
	public Integer isActive;
	
	public Date activeFrom;
	
	public Date activeTo;
	
}
