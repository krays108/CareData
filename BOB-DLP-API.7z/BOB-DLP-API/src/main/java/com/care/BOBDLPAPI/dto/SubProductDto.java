package com.care.BOBDLPAPI.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public interface SubProductDto {
	
	@JsonProperty(value = "subProduct")
	public String getDescription();
	
	@JsonProperty(value = "productId")
	public Integer getProduct_id();
	
	@JsonProperty(value = "maxLoanAmount")
	public  Float  getMax_loan_amount();
	
	@JsonProperty(value = "productEligibility")
	public String getProduct_eligibility();
	
	@JsonProperty(value = "tenureEligibility")
	public String getTenure_eligibility();
	
	@JsonProperty(value = "journeySetupId")
	public Integer getJourney_setup_id();

}
