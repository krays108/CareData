package com.care.BOBDLPAPI.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.care.BOBDLPAPI.model.dto.LoginDto;
import com.care.BOBDLPAPI.service.LoginService;

import io.swagger.annotations.Api;
@Api(tags = "LOAN REFERENCE NO")
@CrossOrigin(origins="*")
@RestController
@RequestMapping(value =  "/dlp/api",produces="application/json")
public class LoginController {

	@Autowired LoginService loginService ;
	
	@PostMapping("/customerLogin")
	public ResponseEntity<?> login(@RequestBody LoginDto login) {
		return loginService.login(login);
	}
	
//	@ApiIgnore
	@GetMapping("/getCustomerDetails")
		public ResponseEntity<?> getCustomerDetails(@RequestHeader String customerId){
		return	loginService.getCustomerDetails(customerId);
		}
	
//	@ApiIgnore
	@GetMapping("/getCustomerLogin")
	public ResponseEntity<?> getCustomerLogin(@RequestHeader Long mobile,@RequestHeader String email){
	return	loginService.getCustomerLogin(mobile,email);
	}
	
	//@ApiIgnore
	@GetMapping("/getCustomerIdByMobileNo")
	public String getCustomerIdByMobileNo(@RequestHeader Long mobile) {
		return loginService.getCustomerIdByMobileNo(mobile);
	
}
	
	//@ApiIgnore
	@GetMapping("/getDuplicateLoanType")
	public ResponseEntity<Boolean> getDuplicateLoanType(@RequestHeader String email,
						@RequestHeader String loanType,@RequestHeader String purposeOfLoan){
							return loginService.getDuplicateLoanType(email,loanType,purposeOfLoan);
		
	}
	

}