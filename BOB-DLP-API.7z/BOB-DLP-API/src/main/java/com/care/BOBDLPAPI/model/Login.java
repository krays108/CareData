package com.care.BOBDLPAPI.model;

import java.sql.Timestamp;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@Table(name = "DLP_LOGIN")
@NoArgsConstructor
@AllArgsConstructor
@SequenceGenerator(name = "login_seq", sequenceName = "login_seq", allocationSize = 1)
public class Login {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "login_seq")
	public Long loginId;

	@Column(length = 200)
	public String fullName;

	public Long mobile;

	@Column(length = 200)
	public String email;

	@Column(length = 1)
	public String agreeDtc;

	@Column(length = 10)
	public String mobileOtp;

	@Column(length = 10)
	public String emailOtp;

	@Column(length = 2000, nullable = false, unique = true)
	public String customerId;

	public Timestamp loggedInDate = Timestamp.valueOf(LocalDateTime.now());

	public Timestamp loggedOutDate;

	@Column(length = 200)
	public String ip;

	@Column(length = 1)
	public String lockedStatus;

	@Column(length = 100)
	public String loanType;

	@Column(length = 200)
	public String purposeOfLoan;

	@Column(length = 100)
	public String agentCode;

	public String uniqueIdentifier;

	public String uniqueIdentifierNumber;

	public String sourceOfRequest;

	public Integer journeySetupId;

	public Integer productTypeId;

	public Integer productId;

	public String product;

	public String subProduct;
}
