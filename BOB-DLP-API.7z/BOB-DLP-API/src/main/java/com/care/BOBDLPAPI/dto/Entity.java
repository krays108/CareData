package com.care.BOBDLPAPI.dto;

import java.util.Map;


public interface Entity {

	public Map<String, Object> getEntity();
	
}
