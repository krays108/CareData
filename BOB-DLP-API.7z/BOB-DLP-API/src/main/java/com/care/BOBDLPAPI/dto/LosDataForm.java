package com.care.BOBDLPAPI.dto;

import java.util.List;

import lombok.Data;

@Data
public class LosDataForm {
	
	
	List<Msection>  mSection;
	
	List<EntryFormRule> DropdownEntryFormRuleList;
	
	List<EntryFormRule> DropdownGridRuleList;
	

}
