package com.care.BOBDLPAPI.model;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class AcfRequest {
	@Id
	public Integer acfRequestId;

	public String referenceNo;

	public String description;

	public Integer entityId;

	public Integer adefFlowId;

	public Integer workflowStatus;

	public Integer revisionNumber;

	public Integer acfLogDetailIdCurrent;

	public Integer currencyId;

	public Date limitsAsof;

	public Date conductAsof;

	public Integer acfDisbursementId;

	public Integer isWorkflowComplete;

	public Integer adefPostapprovalStatusId;

	public Integer revisionNumberDecision;

	public Integer leadChecklistId;

	public Integer isOnlineRequest;
}
