package com.care.BOBDLPAPI.dto;

import lombok.Data;

@Data
public class IntRateDto {
	
	Float interestRate;
}
