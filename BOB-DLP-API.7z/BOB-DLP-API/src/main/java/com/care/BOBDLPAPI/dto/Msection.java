package com.care.BOBDLPAPI.dto;

import java.util.List;

import com.care.BOBDLPAPI.model.Section;

import lombok.Data;

@Data
public class Msection {
	
	String title;
	
	String dataKey;
	
	int sequenceNumber;
	
	List<Section> entryFormList;
	
//	List<EntryFormRule> DropdownEntryFormRuleList;
	
	
	
	
	
	public int compareTo(Msection losDataForms) {
		return this.sequenceNumber - losDataForms.sequenceNumber;
	}
	

}
