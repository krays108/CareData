package com.care.BOBDLPAPI.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ControlAction {
	
	public String actionName;
	
	public String matchType;
	
	public List<String> controlName;
	
	int seqNumber;
	 

}
