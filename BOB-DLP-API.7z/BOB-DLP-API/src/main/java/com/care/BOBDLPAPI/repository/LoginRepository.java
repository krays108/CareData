package com.care.BOBDLPAPI.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.care.BOBDLPAPI.dto.LoginDetailsDto;
import com.care.BOBDLPAPI.model.Login;

@Repository
public interface LoginRepository extends JpaRepository<Login,Long> {
	


	List<Login> findByCustomerId(String customerId);
	   
	 @Query(value = "select n.EMAIL,n.MOBILE"
	   		+ ",n.FULL_NAME,n.LOAN_TYPE,n.PURPOSE_OF_LOAN,b.ELIGIBLE_LOAN_AMT from DLP_LOGIN n"
	   		+ " inner join DLP_PERSONAL_DETAILS b on n.CUSTOMER_ID=? and  n.CUSTOMER_ID=b.CUSTOMER_ID"
	   		,nativeQuery = true)
	   List<LoginDetailsDto> findDetailsByCustomerId(String customerId);
	

	 Login findCustomerLoginByCustomerId(String customerId);
	 
	 
	 @Query(value="SELECT * FROM DLP_LOGIN WHERE MOBILE=?1 AND EMAIL=?2",nativeQuery=true)
	 List<Login> findByMobileAndEmail(Long mobile, String email);

	 Login findAllByMobile(Long mobileNo);

	 @Query(value="SELECT * FROM DLP_LOGIN WHERE EMAIL=?1 AND LOAN_TYPE=?2 AND PURPOSE_OF_LOAN=?3",nativeQuery=true)
	List<Login> findByEmailLoanTypeAndPurposeOfLoan(String email, String loanType, String purposeOfLoan);

	 @Query(value="SELECT EMAIL FROM DLP_LOGIN WHERE CUSTOMER_ID=?", nativeQuery=true)
	String getEmail(String customerId);
	 
}
