package com.care.BOBDLPAPI.util;

import org.springframework.stereotype.Component;

@Component
public final  class DlpUtil {

  public static final String PROPOSED_LOAN_DETAILS_KEY_1="bank";
  public static final String PROPOSED_LOAN_DETAILS_KEY_2="feeAmount";
  public static final String PROPOSED_LOAN_DETAILS_KEY_3="customerFeedback";
  public static final String PROPOSED_LOAN_DETAILS_KEY_4="principleLetter";
  public static final String PROPOSED_LOAN_DETAILS_KEY_5="offerLetter";
  
  public static final String INVALID_CUSTOMER="Customer does not exist";
  public static final String DATA_UPDATED="Customer Data Updated";
  public static final String CUSTOMER_NOT_AVAILABLE="Customer Not Available";
  public static final String PROCESS_FAILD="Process Failed";
  
  public static final String LOGGED_IN="Logged in";
  
  public static final String IN_PROGRESS="In Progress";
  public static final String REFERENCE_NO_GENERATED="In Progress-Reference No.Generated";
  public static final String ACCEPTED_PRINCIPLE_LETTER="In Principle Sanction Letter Accepted";
  public static final String REJECTED_PRINCIPLE_LETTER="In Principle Sanction Letter Rejected";
  public static final String OFFER_LETTER_GENERATED="Offer Letter Generated";
  public static final String LOAN_AGREE_GENERATED="Loan agreement Generated";
  public static final String DATA_TO_LOS="Data Pushed to LOS";
  
  public static final String CO_APPLICANT_NOT_EXIST="CoApplicant does no exist";
  
  public static final String EDUCATION_LOAN="Education Loan";
  public static final String PERSONAL_LOAN="Personal Loan";
  public static final String VEHICLE_LOAN="Vechical Loan";
	public static final String HOME_LOAN="Home Loan";
  public static final String MORTGAGE_LOAN="Mortgage Loan";
  public static final String LOAN_AGAINST_SHARES="Loan Against Shares";
  
  public static final String AGENT_NOT_ELIGIBLE="Agent is not eligible.Kindly contact the bank.";
  public static final String AGENT_NOT_AVAILABLE="Agent Details is not Available";
  
  public static final String KCR_PRODUCT_ID_NOT_EXIST="Product GroupId does not exist";
  
  //Constant for ADEF App Data Form
  public static final String DROPDOWN="dropdown";
  public static final String DATE="date";
  public static final String TEXT="text";
  public static final String LABLE="label";
  public static final String NUMERIC="numeric";
  public static final String ID="__id";
  public static final String MANDATORY  ="mandatory";
  public static final String OPTION="option";
  public static final String SECTION="section";
  public static final String CAPTION="entry-form";
  public static final String MULTICOL_GRID="multicol-grid";
  public static final String TITLE="title";
  public static final String DATA_KEY="data-key";
  public static final String M_SECTION="Msection";
  public static final String ENTRY_FORM="entry-form";
  public static final String SYSTEM_DROPDOWN="systemdropdown";
  public static final String TEXT_AREA="textarea";
  public static final String DYNAMIC_GRID="dynamic-column-grid";
  public static final String SEQUENCE_NUMBER="SequenceNumber";
  public static final String SOURCE="source";
  public static final String CHECKBOX="Checkbox";
  public static final String RADIO="Radio";
  public static final String VISIBILITY_TYPE="is-Visible-DLP";
  public static final String MULTIPLE_VALUES="(multiple values)";
  public static final String VALUE="value";

  
  
  public static final String WORKFLOW_STATUS="Status pending";
  public static final String INVALID_MOBILE_NO="Invalid Mobile NO";
  public static final String INVALID_UNIQUE_IDENTIFIER="Invalid Unique Identifier";
  public static final String INVALID_REFERENCE_NO="Invalid Reference NO";
  
  public static final String OTP_PENDING="pending";
  public static final String OTP_EXPIRED="expired";
  public static final String OTP_VERIFIED="verified";
  public static final String EXPIRED_OTP_MESG="OTP Expired";
  public static final String SUCCESS_OTP="OTP verified successfully";
  public static final String OTP_SUBJECT="OTP for Digital Lending Login";
  public static final String OTP_BODY=" "+"is the OTP for Digital Lending login. OTPs are SECRET.DO NOT disclose it to anyone.";
  public static final String OTP_FAILED="failed";
  public static final String INVALID_OTP="OTP Invalid";
  public static final String SUCCESS_STATUS_CODE="200";
  public static final String FAILURE_STATUS_CODE="400";
  public static final String EMAIL_IS_NULL="Kindly Enter the email.";
  public static final String KIN="Congratulations, your loan application has been successfully submitted bearing Loan Application Number customerId. You can track the status of the Loan under \"Track Status\". Thank you for trusting the Bank of Bhutan as your preferred banking partner.";
  public static final String KOUT="Thank you for trusting Bank of Bhutan as your preferred banking partner. Your Loan Application Number customerId. Please contact your branch for further detail.";
  public static final String INVALID_PHONE_NUMBER="Invalid Mobile Number";
  
}
