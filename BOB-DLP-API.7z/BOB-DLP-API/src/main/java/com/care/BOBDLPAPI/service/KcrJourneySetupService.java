package com.care.BOBDLPAPI.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.care.BOBDLPAPI.dto.DocumentTypeDto;
import com.care.BOBDLPAPI.dto.JourneySetupDto;
import com.care.BOBDLPAPI.dto.ProdIntrateDto;
import com.care.BOBDLPAPI.dto.ProdPurposeDto;
import com.care.BOBDLPAPI.dto.SubProductDto;
import com.care.BOBDLPAPI.repository.KcrJourneySetupRepository;

@Service
public class KcrJourneySetupService {
	
	@Autowired KcrJourneySetupRepository kcrJourneySetupRepository;

	public ResponseEntity<?> getDLPProducts(Integer productFor,String requestFrom) {
	if(requestFrom.equalsIgnoreCase("DLP") ) {
		List<JourneySetupDto> productList=	 kcrJourneySetupRepository.findProductByDLP(productFor);
		return ResponseEntity.ok(productList);
	}else if(requestFrom.equalsIgnoreCase("BOT")) {
		List<JourneySetupDto> productList1 = kcrJourneySetupRepository.findProductByBOT(productFor);
		 return ResponseEntity.ok(productList1);
	}
	return ResponseEntity.ok("Data does not exist");
	}


	public ResponseEntity<List<SubProductDto>> getDLPSubProduct(Integer productTypeId) {
		List<SubProductDto> subProductList=	 kcrJourneySetupRepository.findDLPSubProduct(productTypeId);
		if(subProductList.isEmpty()) {
			return ResponseEntity.badRequest().build();
		}
		 return ResponseEntity.ok(subProductList);
	}


	public ResponseEntity<List<ProdPurposeDto>> getDLPProdPurpose(Integer productId) {
		List<ProdPurposeDto> list=kcrJourneySetupRepository.getDLPProdPurpose(productId);
		return ResponseEntity.ok(list);	}


	/*
	 * public ResponseEntity<?> getInterstRate(Integer productId, String
	 * interestType) {
	 * 
	 * IntRateDto interestRate= new IntRateDto();
	 * 
	 * if(interestType.equalsIgnoreCase("Floating")) { Float intRate
	 * =kcrJourneySetupRepository.findByFloating(productId);
	 * interestRate.setInterestRate(intRate); return ResponseEntity.ok(interestRate)
	 * ; }
	 * 
	 * else if(interestType.equalsIgnoreCase("Fixed")) { Float intRate
	 * =kcrJourneySetupRepository.findByFixedRate(productId);
	 * interestRate.setInterestRate(intRate); return ResponseEntity.ok(interestRate)
	 * ; }
	 * 
	 * else if(interestType.equalsIgnoreCase("Floating with 5 year reset")) { Float
	 * intRate =kcrJourneySetupRepository.findByFloatingReset(productId);
	 * interestRate.setInterestRate(intRate); return ResponseEntity.ok(interestRate)
	 * ; }
	 * 
	 * return ResponseEntity.ok("Invalid Input"); }
	 */

	
	public ResponseEntity<?> getInterstRate(Integer productId) {
		
	      ProdIntrateDto intList=kcrJourneySetupRepository.findIntrate(productId);
				return ResponseEntity.ok(intList);
			
		}
	
	public ResponseEntity<?> getDocumentTypes(Integer journeySetupId) {
		
	List<DocumentTypeDto> documentTypes=	 kcrJourneySetupRepository.findDocumentByJourneySetupId(journeySetupId);
		 if(documentTypes.isEmpty()) {
			 return ResponseEntity.ok("Documnet does not exist for this ID");
		 }
		 return ResponseEntity.ok(documentTypes);
	}


	
	}

