package com.care.BOBDLPAPI.dto;



public interface ConfigList {

	public Integer getValue();
	
	public String getText();
}
