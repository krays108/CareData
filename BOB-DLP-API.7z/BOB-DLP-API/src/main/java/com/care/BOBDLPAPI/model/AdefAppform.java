package com.care.BOBDLPAPI.model;

import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class AdefAppform {
	
	@Id
	public Integer adefAppformId;
	
	public String description;
	
	public String xmlData;
	
	public Integer workflowStatus;
	
	public Integer changedBy;
	
	public Timestamp changedOn;
	
	public Integer authorisedBy;
	
	public Timestamp authorisedOn;
	
	public Integer obsoletedBy;
	
	public Timestamp obsoletedOn;
	
	public Integer revisionNumber;
	
	public Integer purpose;
	
	

}
