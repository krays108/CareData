package com.care.BOBDLPAPI.model.dto;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Date;

import lombok.Data;

@Data
public class ProductDetailsDto {

	public Integer id;	
	
	public Integer productSubCatId;
	
	public Integer rangeFrom;
	
	public Integer rangeTo;
	
	public Integer minRepayPeriod;
	
	public Integer maxRepayPeriod;
	
	public Integer minIncome;
	
	public Integer minInt;
	
	public Integer maxInt;
	
	public String activeStatus;
		
	public Date effectiveFrom;
	
	public Date effectiveTill;	
	
	public Timestamp createdDate= Timestamp.valueOf(LocalDateTime.now());
	
	public Timestamp modifiedDate;

}
