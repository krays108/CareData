package com.care.BOBDLPAPI.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.care.BOBDLPAPI.service.AdefAppformService;

//@ApiIgnore
@CrossOrigin(origins="*")
@RestController
@RequestMapping(value =  "/dlp/api",produces="application/json")
public class AdefAppformController {
	
	@Autowired
	AdefAppformService adefAppformService;
	
	@GetMapping("/getLOSDataForm")
	public  ResponseEntity<?>  getXmlData(@RequestHeader Integer journeySetupId,@RequestHeader String uniqueIdentifier) {
		return adefAppformService.getXmlData(journeySetupId,uniqueIdentifier);
	}
	
	@GetMapping("/getGewog")
	public ResponseEntity<?> getGewog(@RequestHeader String code){
		return adefAppformService.getGewog(code);
	}
}
