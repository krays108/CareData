package com.care.BOBDLPAPI.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.care.BOBDLPAPI.dto.WorkflowStatusDto;
import com.care.BOBDLPAPI.model.AcfRequest;


@Repository
public interface AcfRequestRepository  extends JpaRepository<AcfRequest,Integer> {
	
	@Query(value="SELECT DISTINCT a.description,b.CUSTOMER_ID,b.UNIQUE_IDENTIFIER_NUMBER, b.FULL_NAME,b.LOAN_AMOUNT,b.PURPOSE_OF_LOAN,b.MOBILE,b.EMAIL,b.LOAN_TYPE from kco_system_enums a,DLP_TRANSACTION_DETAILS b WHERE a.column_name='WORKFLOW_STATUS' and a.table_name='KCR_ACF_REQUEST' and value IN (select WORKFLOW_STATUS from KCR_ACF_REQUEST where ACF_REQUEST_ID IN (select ACF_REQUEST_ID_CONVERTED from KCR_ACF_APPFORM where DLP_REQUEST_NUMBER IN (SELECT CUSTOMER_ID FROM DLP_LOGIN WHERE MOBILE=?1))) AND b.CUSTOMER_ID IN (SELECT CUSTOMER_ID FROM DLP_LOGIN WHERE MOBILE=?1)"
			,nativeQuery = true)
	List<WorkflowStatusDto>	findStatusByWorkflow(Long mobile);

	
	@Query(value="SELECT * FROM KCR_ACF_REQUEST WHERE ACF_REQUEST_ID IN (SELECT ACF_REQUEST_ID FROM KCR_ACF_CPTY WHERE UNIQUE_IDENTIFIER=?1)" , nativeQuery=true)
	List<AcfRequest> findAcfRequestDetails(String uniqueIdentifier);


	@Query(value="SELECT CUSTOMER_ID FROM DLP_LOGIN WHERE MOBILE=?1",nativeQuery=true)
	List<String> findCustomerIdByMobile(Long mobile);


	@Query(value="SELECT distinct a.description,b.CUSTOMER_ID,b.UNIQUE_IDENTIFIER_NUMBER, b.FULL_NAME,b.LOAN_AMOUNT,b.PURPOSE_OF_LOAN,b.MOBILE,b.EMAIL,b.LOAN_TYPE from kco_system_enums a, DLP_TRANSACTION_DETAILS b WHERE a.column_name='WORKFLOW_STATUS' and a.table_name='KCR_ACF_REQUEST' and a.value=?1 and b.CUSTOMER_ID=?2",nativeQuery=true)
	List<WorkflowStatusDto> findStatus(Integer statusValue, String customerId);


	@Query(value="select ACF_REQUEST_ID_CONVERTED from KCR_ACF_APPFORM where DLP_REQUEST_NUMBER =?1",nativeQuery=true)
	Integer findACFRequestIdByCustomerId(String customerId);

	@Query(value="select WORKFLOW_STATUS from KCR_ACF_REQUEST where ACF_REQUEST_ID=?1",nativeQuery=true)
	Integer findStatusByACFRequestId(Integer acfRequestId);


	@Query(value="select distinct CUSTOMER_ID,UNIQUE_IDENTIFIER_NUMBER,FULL_NAME,LOAN_AMOUNT,PURPOSE_OF_LOAN,MOBILE,EMAIL,LOAN_TYPE from DLP_TRANSACTION_DETAILS where CUSTOMER_ID=?1",nativeQuery=true)
	List<WorkflowStatusDto> findStatusByCustomerId(String string);
	
 






	

}
