
package com.care.BOBDLPAPI.service;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.care.BOBDLPAPI.dto.LoginDetailsDto;
import com.care.BOBDLPAPI.model.History;
import com.care.BOBDLPAPI.model.Login;
import com.care.BOBDLPAPI.model.dto.LoginDto;
import com.care.BOBDLPAPI.repository.HistoryRepository;
import com.care.BOBDLPAPI.repository.LoginRepository;
import com.care.BOBDLPAPI.repository.TransactionDetailsRepository;
import com.care.BOBDLPAPI.util.DlpUtil;

@Service
public class LoginService {

	@Autowired
	LoginRepository loginRepository;

	@Autowired
	HistoryRepository historyRepository;
	
	@Autowired
	DlpUtil dlpUtil;
	
	@Autowired private ModelMapper modelMapper;
	
	@Autowired
	TransactionDetailsRepository transactionDetailsRepository;

	public ResponseEntity<?> login(LoginDto loginDto) {

		List<Login> list = loginRepository.findByCustomerId(loginDto.getCustomerId());
		if (!list.isEmpty()) {
			Login editLogin = loginRepository.findByCustomerId(loginDto.getCustomerId()).get(0);
			editLogin.setAgreeDtc(loginDto.getAgreeDtc());
			editLogin.setEmail(loginDto.getEmail());
			editLogin.setEmailOtp(loginDto.getEmailOtp());
			editLogin.setFullName(loginDto.getFullName());
			editLogin.setIp(loginDto.getIp());
			editLogin.setLoanType(loginDto.getLoanType());
			editLogin.setMobile(loginDto.getMobile());
			editLogin.setMobileOtp(loginDto.getMobileOtp());
			editLogin.setPurposeOfLoan(loginDto.getPurposeOfLoan());
			editLogin.setLockedStatus(loginDto.getLockedStatus());
			editLogin.setLoggedInDate(loginDto.getLoggedInDate());
			editLogin.setLoggedOutDate(loginDto.getLoggedOutDate());
			editLogin.setSourceOfRequest(loginDto.getSourceOfRequest());
			editLogin.setUniqueIdentifier(loginDto.getUniqueIdentifier());
			editLogin.setUniqueIdentifierNumber(loginDto.getUniqueIdentifierNumber());
			editLogin.setProductId(loginDto.getProductId());
			editLogin.setProductTypeId(loginDto.getProductTypeId());
			editLogin.setJourneySetupId(loginDto.getJourneySetupId());
			editLogin.setSubProduct(loginDto.getSubProduct());
			editLogin.setProduct(loginDto.getProduct());
			
			loginRepository.save(editLogin);
			History history = new History();
			history.setApplicantStatus(dlpUtil.LOGGED_IN);
			history.setCustomerId(loginDto.getCustomerId());
			history.setApplicantEmail(loginDto.getEmail());
			history.setApplicantMobile(loginDto.getMobile());
			history.setApplicantName(loginDto.getFullName());

			historyRepository.save(history);

			return ResponseEntity.ok("Data updated");
		}
		Login login=  modelMapper.map(loginDto, Login.class);
		Login loginDtl = loginRepository.save(login);
		LoginDto loginDto1=modelMapper.map(loginDtl, LoginDto.class);

		History history = new History();
		history.setApplicantStatus(dlpUtil.LOGGED_IN);
		history.setCustomerId(login.getCustomerId());
		history.setApplicantEmail(login.getEmail());
		history.setApplicantMobile(login.getMobile());
		history.setApplicantName(login.getFullName());

		historyRepository.save(history);

		return ResponseEntity.ok(loginDto1);

	}

	public ResponseEntity<?> getCustomerDetails(String customerId) {
	       List<LoginDetailsDto> loginDetails= 
	    		   loginRepository.findDetailsByCustomerId(customerId);
	     
		return ResponseEntity.ok(loginDetails);
	}
	
	

	public ResponseEntity<?> getCustomerLogin(Long mobile, String email) {
		
		List<Login> customerLogin= loginRepository.findByMobileAndEmail(mobile, email);
		 
		if(customerLogin.isEmpty()) {
			
			return ResponseEntity.ok(dlpUtil.CUSTOMER_NOT_AVAILABLE);
		}
		
		List<String> customerId= new ArrayList<>();
		customerLogin.forEach(custId->customerId.add(custId.getCustomerId()));
		
		return ResponseEntity.ok(customerId.get(0)); 
	}

	public String getCustomerIdByMobileNo(Long mobile) {
		Login login=loginRepository.findAllByMobile(mobile);
		String customerId=login.getCustomerId();
		 return customerId ;
	}

	public ResponseEntity<Boolean> getDuplicateLoanType(String email, String loanType, String purposeOfLoan) {
		List<Login> loginDtls=
				loginRepository.findByEmailLoanTypeAndPurposeOfLoan(email,loanType,purposeOfLoan);
		if(loginDtls.isEmpty()) {
			return ResponseEntity.ok(false);
			
		}
		return ResponseEntity.ok(true);
	}

}
