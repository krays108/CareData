package com.care.BOBDLPAPI.dto;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonProperty;

@Component
public interface ProdPurposeDto {
	
	@JsonProperty(value = "purpose" )
	public String getDescription();
	
	public Integer getCode();

}
