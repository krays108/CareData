package com.care.BOBDLPAPI.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.care.BOBDLPAPI.model.OtpEntity;

@Repository
public interface OtpRepository extends JpaRepository<OtpEntity, Integer> {

	OtpEntity findByOtp(Integer otp);

	@Query(value="SELECT * FROM DLP_OTP WHERE OTP=?1 AND EMAIL=?2",nativeQuery = true)
	OtpEntity findByOtpAndEmail(Integer otp, String email);
	
	

}
