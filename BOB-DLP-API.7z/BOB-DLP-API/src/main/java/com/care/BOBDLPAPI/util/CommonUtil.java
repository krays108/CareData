package com.care.BOBDLPAPI.util;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.care.BOBDLPAPI.dto.EntityDto;
import com.care.BOBDLPAPI.repository.AdefRepository;

@Component
public class CommonUtil {
	
	@Autowired
	AdefRepository adefRepository;

	
    
	public List<?> getSystemDropDown(String source) {
		String tableName=adefRepository.findBySystemDataKey(source);
	
		if(tableName!=null && tableName.equalsIgnoreCase("kcr_gewog")) {
			List<EntityDto> entity=adefRepository.findByGewog(tableName);
			return entity;
		}
		
		else if(tableName!=null && tableName.equalsIgnoreCase("kcr_dzongkhag")) {
			List<EntityDto> entity=adefRepository.findByDzongkhag(tableName);
			return entity;
		}
		
		else if(tableName!=null && tableName.equalsIgnoreCase("kco_entity")) {
			List<EntityDto> entity=adefRepository.findByEntity(tableName);
			return entity;
		} 
	/*
	 * if(tableName!=null) {
	 * 
	 * List<Entity> entity= adefRepository.findByFunction(tableName); return entity;
	 * 
	 * }
	 */
			 
		
		return null;
		
	}


	public String getCounterPartyName(String tableName, String columnName,String uniqueIdentifier) {
		
		if(tableName!=null &&  columnName!=null &&uniqueIdentifier!=null) {
			String columnArray[]=columnName.split("/");
			String colName=	columnArray[1];
			if(colName.equalsIgnoreCase("NA")) {
				return null;
			}else {
				String result=adefRepository.findCounterPartyId(tableName,colName,uniqueIdentifier);
				return result ;
			}
			
		}
		
		return null;
		
	}


	public List<EntityDto> getConfigList(String source) {
	String tableName=adefRepository.getTableForConfig(source);
		
	if(tableName!=null) {

	List<EntityDto> configList=	adefRepository.getConfigList(tableName);
	return configList;
	}
		
		return null;
	}



}
