package com.care.BOBDLPAPI.model;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class KcrJourneySetup {

	@Id
	public Integer journeySetupId;
	
	public Integer productTypeId;
	
	public Integer productId;
	
	public String name;
	
	public String detailDesc;
	
	public Integer isInitFrmDlp;
	
	public Date activitedDlpFrom;
	
	public Date activitedDlpTo;
	
	public Integer isInitFrmChatbot;
	
	public  Date activitedChatbotFrom;
	
	public Date activitedChatbotTo;
	
	public Integer isInitFrmBranch;
	
	public Date activitedBranchFron;
	
	public Date activitedBranchTo;
	
	public Integer coApplicantNeeded;
	
	public Integer extValidationNeeded;
	
	public Integer createdBy;
	
	public Date createdOn;
	
	public Integer authorisedBy;
	
	public Date authorisedOn;
	
	public Integer RevisionNumber;
	
	

}
