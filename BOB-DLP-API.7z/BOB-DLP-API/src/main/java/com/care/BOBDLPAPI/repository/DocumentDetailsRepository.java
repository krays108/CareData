package com.care.BOBDLPAPI.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.care.BOBDLPAPI.model.DocumentDetails;


@Repository
public interface DocumentDetailsRepository  extends JpaRepository<DocumentDetails, Long>{
	
	List<DocumentDetails> findByCustomerId(String customerId);


}
