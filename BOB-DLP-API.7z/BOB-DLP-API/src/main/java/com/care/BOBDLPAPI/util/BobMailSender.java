package com.care.BOBDLPAPI.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailAuthenticationException;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class BobMailSender {
	
@Autowired
  private JavaMailSender javaMailSender ;
	
	public String sendEmail(String toEmailId,
			String emailSubject, String emailBody) {
		
		SimpleMailMessage message= new SimpleMailMessage();
		
		try {
			message.setFrom("crspl.dlpsupport@careedge.in");
			message.setTo(toEmailId);
			message.setSubject(emailSubject);
			message.setText(emailBody);
			javaMailSender.send(message);
		} catch (MailException e) {
			
			return "failed";
			
		}
		return "success";
		
	}
}
