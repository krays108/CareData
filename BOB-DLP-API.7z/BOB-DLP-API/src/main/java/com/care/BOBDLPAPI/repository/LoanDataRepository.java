package com.care.BOBDLPAPI.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.care.BOBDLPAPI.model.LoanData;

@Repository
public interface LoanDataRepository extends JpaRepository<LoanData, Long>{

	List<LoanData> findByCustomerId(String customerId);

}
