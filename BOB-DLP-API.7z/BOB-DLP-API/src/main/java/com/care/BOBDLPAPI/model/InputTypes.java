package com.care.BOBDLPAPI.model;

import java.util.List;
import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class InputTypes {
	
	String fieldType; // dropdown , checkbox , textbox 
	
	String fieldName; // label
	
	Integer maxLength; //text max length
	
	String dataKey; //dataKey
	
	String counterparty;
	
	List<String> fieldValues; // options 
	
	List<?> systemDropDownList;
	
	Boolean mandatory; 
	
	Boolean multiple;
	
	Integer seqNumber;

}
