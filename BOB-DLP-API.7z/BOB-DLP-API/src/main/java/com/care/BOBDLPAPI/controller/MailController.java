package com.care.BOBDLPAPI.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.care.BOBDLPAPI.util.BobMailSender;
import com.care.BOBDLPAPI.util.DlpUtil;

//@ApiIgnore
@CrossOrigin(origins="*")
@RestController
@RequestMapping("/dlp/api")
public class MailController {
	
	@Autowired   BobMailSender bobMail;
	@Autowired DlpUtil dlpUtil;

	@PostMapping("/sendMail")
	public String sendMail(@RequestHeader String toEmailId,
			@RequestHeader String emailSubject,
			@RequestHeader String emailBody
			) {
		return bobMail.sendEmail(toEmailId, emailSubject, emailBody);
		
	}
	
	@PostMapping("/sendSubmitEmail")
	public String sendEmail(@RequestHeader String toEmailId,
			@RequestHeader String customerId,
			@RequestHeader String status){
		String emailSubject="BoB e-Loan";
		
		if(status.equalsIgnoreCase("KIN")) {
			String emailBody=dlpUtil.KIN.replaceFirst("customerId", customerId);
			return  bobMail.sendEmail(toEmailId,emailSubject,emailBody);
		}else if(status.equalsIgnoreCase("KOUT")) {
			String emailBody = dlpUtil.KOUT.replaceFirst("customerId", customerId);
			return  bobMail.sendEmail(toEmailId,emailSubject,emailBody);
 
		}
		return "submit Failed";
	}
	
}
