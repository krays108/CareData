package com.care.BOBDLPAPI.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public interface JourneySetupDto {
	
	@JsonProperty(value = "product")
	public String getDescription();
	
	@JsonProperty(value = "productTypeId")
	public Integer getProduct_type_Id();
	
	
	
	/*
	 * @JsonProperty(value = "tenureType") public String getTenure_unit();
	 * 
	 * public Integer getTenure();
	 */
	


}
