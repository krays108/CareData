package com.care.BOBDLPAPI.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public interface WorkflowStatusDto {
	
	@JsonProperty(value="fullName")
	public String getFull_name();
	
	
	public Long getMobile();
	
	public String getEmail();
	
	@JsonProperty(value="LoanType")
	public String getLoan_type();
	
	@JsonProperty(value="purposeOfLoan")
	public String getPurpose_of_loan();
	
	@JsonProperty(value="LoanAmount")
	public Integer getLoan_amount();
	
	@JsonProperty(value="status")
	public String getDescription();
	
	@JsonProperty(value="LoanReferenceNo")
	public String getCustomer_id();
	
	@JsonProperty(value="uniqueIdentifierNumber")
	public String getUnique_identifier_number();

}
