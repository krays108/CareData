package com.care.BOBDLPAPI;

import org.modelmapper.ModelMapper;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

@EnableWebMvc
@SpringBootApplication
public class BobDlpApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(BobDlpApiApplication.class, args);
	}
	
	 @Bean
	  public InternalResourceViewResolver defaultViewResolver() {
	    return new InternalResourceViewResolver();
	  }
	  
	  @Bean
	  public ModelMapper modelMapper() {
	      return new ModelMapper();
	  }
	   
}
