package com.care.BOBDLPAPI.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.care.BOBDLPAPI.model.DocumentDetails;
import com.care.BOBDLPAPI.model.dto.DocumentDetailsDto;
import com.care.BOBDLPAPI.service.DocumentDetailsService;


@CrossOrigin(origins="*")
@RestController
@RequestMapping(value =  "/dlp/api",produces="application/json")
public class DocumentDetailsController {
	
	@Autowired  
	DocumentDetailsService documentDetailsService ;
	
	
	@PostMapping("/saveDocumentDetails")
	public ResponseEntity<List<DocumentDetails>> addDoucmentDetails(
			 @RequestBody List<DocumentDetailsDto> documentDetailsDto) {
		return documentDetailsService.addDoucmentDetails(documentDetailsDto) ;
		
	}
	
	@GetMapping("/getDocumentDetails")
	public ResponseEntity<List<DocumentDetailsDto>> getDocumentDetails(@RequestHeader String customerId){
		return documentDetailsService.getDocumentDetails(customerId);
	}

}
