package com.care.BOBDLPAPI.model;

import java.sql.Timestamp;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "DLP_HISTORY")
@SequenceGenerator(name = "history_detail", sequenceName = "history_detail", allocationSize = 1)
public class History {

	@Id

	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "history_detail")

	public Long historyId;

	@Column(length = 2000)
	public String customerId;

	@Column(length = 200)
	public String applicantStatus;

	public String applicantEmail;

	public String applicantName;

	public Long applicantMobile;

	public Timestamp createdDate = Timestamp.valueOf(LocalDateTime.now());
}
