package com.care.BOBDLPAPI.model.dto;

import java.sql.Timestamp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class DocumentDetailsDto {
	
	public Long documentId;
	
	public String customerId;
	
	public Long journeySetupId;
	
	public Long documentIdLos;
	
	public String documentType;
	
	public String documentFileName;
	
	public String documentContent;
	
//	public MultipartFile documentContentFile;
	
	public Timestamp createdDate;
	
	
	
	

}
