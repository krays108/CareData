package com.care.BOBDLPAPI.dto;

public interface EntityDto {

	public String getCode();

	public String getDescription();

}
