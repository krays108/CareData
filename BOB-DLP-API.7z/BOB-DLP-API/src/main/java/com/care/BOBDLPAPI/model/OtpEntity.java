package com.care.BOBDLPAPI.model;

import java.sql.Timestamp;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "DLP_OTP")
@Data
@SequenceGenerator(name = "otp_seq", sequenceName = "otp_seq", allocationSize = 1)
public class OtpEntity {
	@Id
		@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "otp_seq")

	public Integer otpId;

	public Integer otp;

	public String status;

	public String email;

	@Column(columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
	public Timestamp createdTime = Timestamp.valueOf(LocalDateTime.now());

	public Long expiryTime = System.currentTimeMillis() + (600 * 1000);

}
