package com.care.BOBDLPAPI.model;

import java.util.LinkedList;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Section {

	public String type;

	public String title;

	public LinkedList<InputTypes> inputType;

	public Integer seqNumber;

	public int compareTo(Section section) {
		return this.seqNumber - section.seqNumber;
	}

}
