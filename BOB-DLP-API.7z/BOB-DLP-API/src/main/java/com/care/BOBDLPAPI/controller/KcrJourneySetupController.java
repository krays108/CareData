package com.care.BOBDLPAPI.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.care.BOBDLPAPI.dto.ProdPurposeDto;
import com.care.BOBDLPAPI.dto.SubProductDto;
import com.care.BOBDLPAPI.service.KcrJourneySetupService;

import io.swagger.annotations.Api;
@Api(tags = "PRODUCT CONFIGURATION")
@CrossOrigin(origins="*")
@RestController
@RequestMapping(value =  "/dlp/api",produces="application/json")
public class KcrJourneySetupController {
	
	@Autowired KcrJourneySetupService kcrJourneySetupService;
	
	@GetMapping("/getDLPProducts")
	public ResponseEntity<?> getDLPProducts(@RequestHeader Integer productFor,@RequestHeader String requestFrom){
		return  kcrJourneySetupService.getDLPProducts(productFor,requestFrom);
	}
		
		@GetMapping("/getDLPSubProduct")
		public ResponseEntity<List<SubProductDto>> getDLPSubProduct(@RequestHeader Integer productTypeId){
			return  kcrJourneySetupService.getDLPSubProduct(productTypeId);
		
	}
		
		@GetMapping("/getDLPProdPurpose")
		public ResponseEntity<List<ProdPurposeDto>> getDLPProdPurpose(@RequestHeader Integer productId){
			return  kcrJourneySetupService.getDLPProdPurpose(productId);
}
		
/*
 * @GetMapping("/getIntRate") public ResponseEntity<?>
 * getInterstRate(@RequestHeader Integer productId,
 * 
 * @RequestHeader String interestType){ return
 * kcrJourneySetupService.getInterstRate(productId,interestType); }
 */
		
		@GetMapping("/getIntRate")
		public ResponseEntity<?> getInterstRate(@RequestHeader Integer productId){
			//Modified by raja on 16th Nov as per the LOS CHange
			return  kcrJourneySetupService.getInterstRate(productId);
		}
		
		@GetMapping("/getDocumentTypes")
		public ResponseEntity<?> getDocumentTypes(@RequestHeader Integer journeySetupId){
			return kcrJourneySetupService.getDocumentTypes(journeySetupId);
		}
		
}
