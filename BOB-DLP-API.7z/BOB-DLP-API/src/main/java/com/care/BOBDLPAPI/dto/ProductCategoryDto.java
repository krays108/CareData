package com.care.BOBDLPAPI.dto;

import java.sql.Timestamp;
import java.time.LocalDateTime;

import lombok.Data;

@Data
public class ProductCategoryDto {
	
	public Integer id;
	
	public String productName;
	
	public String productCode;
	
	public String activeStatus;
	
	
	
	public Timestamp createdDate=Timestamp.valueOf(LocalDateTime.now());
	

	public Timestamp modifiedDate;

}
