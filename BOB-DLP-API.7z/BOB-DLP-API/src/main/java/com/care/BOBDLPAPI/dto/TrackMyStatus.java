package com.care.BOBDLPAPI.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TrackMyStatus {
	
	public String LoanReferenceNo;

	public String fullName;

	public Long mobile;

	public String email;

	public String loanType;

	public String purposeOfLoan;

	public Integer loanAmount;
	
	public String status;
	
	public String uniqueIdentifierNumber;



}
