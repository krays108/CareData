package com.care.BOBDLPAPI.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public interface DocumentTypeDto {
	
	
	@JsonProperty(value = "documentId")
	public Integer getDocument_id();
	
	@JsonProperty(value = "documentType")
	public String getDescription();
	
	
	  @JsonProperty(value = "isMandatory")
	  public String getActive();
	  
	  
	 

}
