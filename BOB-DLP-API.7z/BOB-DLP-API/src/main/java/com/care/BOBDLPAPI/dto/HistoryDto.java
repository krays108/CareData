package com.care.BOBDLPAPI.dto;

import java.sql.Timestamp;
import java.time.LocalDateTime;

import lombok.Data;

@Data
public class HistoryDto {
	
	public Long historyId;
	
	public String customerId;
	
	public String applicantStatus;
	
	public Timestamp createdDate= Timestamp.valueOf(LocalDateTime.now());
}
