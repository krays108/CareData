package com.care.BOBDLPAPI.model.dto;

import java.sql.Timestamp;
import java.time.LocalDateTime;

import lombok.Data;

@Data
public class TransactionDtlsDto {

	public Long transactionId;

	public String customerId;

	public String fullName;

	public Long mobile;

	public String email;

	public String loanType;

	public String purposeOfLoan;

	public Integer loanAmount;

	public Float loanIntRate;

	public Integer loanTenor;

	public Float loanEmi;

	public Float loanFees;

	public Float loanCharges;

	public String status;

	public Timestamp createdDate = Timestamp.valueOf(LocalDateTime.now());

	public String uniqueIdentifier;

	public String uniqueIdentifierNumber;

}
