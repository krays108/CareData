package com.care.BOBDLPAPI.dto;

import org.springframework.stereotype.Component;

@Component
public interface KcrProductAndPurposeDto {

	public String getProduct();

	public String getPurpose();

}
