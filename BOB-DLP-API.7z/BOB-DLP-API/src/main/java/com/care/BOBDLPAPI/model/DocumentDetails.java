package com.care.BOBDLPAPI.model;

import java.sql.Timestamp;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Builder
@Table(name = "DLP_DOCUMENT_DETAILS")
@SequenceGenerator(name = "Document", sequenceName = "Document", allocationSize = 1)
public class DocumentDetails {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "Document")

	public Long documentId;
	
	public Long journeySetupId;
	
	public Long documentIdLos;
	
	@Column(length = 2000)
	public String customerId;
	
	@Column(length = 500)
	public String documentType;
	
	@Column(length = 1000)
	public String documentFileName;
	
	@Lob
	public byte[] documentContent;
	
	public Timestamp createdDate;
	
	
	
	

}
