package com.care.BOBDLPAPI.dto;

import java.util.List;
import java.util.Map;

import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;

import org.springframework.stereotype.Component;

import lombok.Data;

@Component
@Data
public class OutParameter {
    private List<Map<String, Object>> result;

    public List<Map<String, Object>> getResult() {
        return result;
    }

    public void setResult(List<Map<String, Object>> result) {
        this.result = result;
    }

    public void capture(StoredProcedureQuery storedProcedureQuery) {
        storedProcedureQuery.registerStoredProcedureParameter(1, void.class, ParameterMode.REF_CURSOR);
        storedProcedureQuery.execute();
        this.result = (List<Map<String, Object>>) storedProcedureQuery.getOutputParameterValue(1);
    }
}
