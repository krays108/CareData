package com.care.BOBDLPAPI.dto;

public interface LoginDetailsDto {
	
	public String getFull_name();
	
	public Long getMobile();
	
	public String getEmail();
	
	public String getLoan_type();
	
	public String getPurpose_of_loan();
	
	public Long  getEligible_loan_amt();
	
}
