package com.care.BOBDLPAPI.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.care.BOBDLPAPI.model.dto.TransactionDtlsDto;
import com.care.BOBDLPAPI.service.TransactionDetailsService;

//@ApiIgnore
@CrossOrigin(origins = "*")
@RestController
@RequestMapping(value = "/dlp/api", produces = "application/json")
public class TransactionDetailsController {

	@Autowired
	TransactionDetailsService transactionDetailsService;

	@PostMapping("/saveTransactionDetails")
	public ResponseEntity<TransactionDtlsDto> saveTransactionDetails(
			@RequestBody TransactionDtlsDto transactionDtlsDto) {
		return transactionDetailsService.saveTransactionDetails(transactionDtlsDto);

	}

	@GetMapping("/getTransactionDetails")
	public ResponseEntity<?> getTransactionDetails(@RequestHeader String customerId) {
		return transactionDetailsService.getTransactionDetails(customerId);
	}

	@GetMapping("/resumeApplication")
	public ResponseEntity<?> resumeApplication(@RequestHeader Long mobile) {
		return transactionDetailsService.getResumeApplication(mobile);

	}
	
}
