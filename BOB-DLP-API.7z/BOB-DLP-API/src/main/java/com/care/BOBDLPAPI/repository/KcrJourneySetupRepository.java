package com.care.BOBDLPAPI.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.care.BOBDLPAPI.dto.DocumentTypeDto;
import com.care.BOBDLPAPI.dto.JourneySetupDto;
import com.care.BOBDLPAPI.dto.ProdIntrateDto;
import com.care.BOBDLPAPI.dto.ProdPurposeDto;
import com.care.BOBDLPAPI.dto.SubProductDto;
import com.care.BOBDLPAPI.model.KcrJourneySetup;

@Repository
public interface KcrJourneySetupRepository extends JpaRepository<KcrJourneySetup, Integer>{

	
	
	@Query(value = "select distinct  a.product_type_id , b.description from KCR_JOURNEY_SETUP a left join kcr_product_type b on a.product_type_id= b.product_type_id "
			+ "WHERE a.ACTIVITED_DLP_FROM  <= CURRENT_DATE AND ( a.ACTIVITED_DLP_TO >= CURRENT_DATE OR  a.ACTIVITED_DLP_TO IS NULL )"
			+ " AND  b.IS_ACTIVE=1 AND a.IS_INIT_FRM_DLP=1 AND b.PRODUCT_FOR=?1",
			nativeQuery=true)
	List<JourneySetupDto> findProductByDLP(Integer productFor);

	@Query(value="select distinct a.product_id ,a.MAX_LOAN_AMOUNT,DBMS_LOB.SUBSTR(a.PRODUCT_ELIGIBILITY,dbms_lob.getlength(a.PRODUCT_ELIGIBILITY),1) AS PRODUCT_ELIGIBILITY,DBMS_LOB.SUBSTR(a.TENURE_ELIGIBILITY,dbms_lob.getlength(a.TENURE_ELIGIBILITY),1) AS TENURE_ELIGIBILITY,c.description,a.JOURNEY_SETUP_ID FROM KCR_JOURNEY_SETUP a left join kcr_product c on a.product_id=c.product_id where a.product_type_id=?1 AND a.ACTIVITED_DLP_FROM  <= CURRENT_DATE AND ( a.ACTIVITED_DLP_TO >= CURRENT_DATE OR  a.ACTIVITED_DLP_TO IS NULL ) and c.IS_ACTIVE=1",nativeQuery=true)
	List<SubProductDto> findDLPSubProduct(Integer productTypeId);

	@Query(value="select b.description ,b.code from kcr_product_purpose_mapping a left join kcr_product_purpose b on a.product_purpose_id = b.product_purpose_id where a.product_id =?1 AND b.IS_ACTIVE=1",nativeQuery=true)
	List<ProdPurposeDto> getDLPProdPurpose(Integer productId);

	@Query(value="select FLOATING from kcr_product where product_id=?1",nativeQuery=true)
	Float findByFloating(Integer productId);

	@Query(value="select FIXED_RATE from kcr_product where product_id=?1",nativeQuery=true)
	Float findByFixedRate(Integer productId);

	@Query(value="select FLOATING_RESET_5YRS from kcr_product where product_id=?1",nativeQuery=true)
	Float findByFloatingReset(Integer productId);

	@Query(value="select  b.DESCRIPTION,b.document_id, case when b.MANDATORY_FOR_ACTIVATION =0 then 'NO' else 'YES' end as active from KCR_JOURNEY_DOCUMENT a left join kcr_document b on a.document_id= b.document_id where journey_setup_id=?1 and b.document_group_id in (1,4,6)",nativeQuery=true)
	List<DocumentTypeDto> findDocumentByJourneySetupId(Integer journeySetupId);
	
	@Query(value="select distinct  a.product_type_id , b.description from KCR_JOURNEY_SETUP a left join kcr_product_type b on a.product_type_id= b.product_type_id WHERE a.ACTIVITED_CHATBOT_FROM <= CURRENT_DATE AND ( a.ACTIVITED_CHATBOT_TO >= CURRENT_DATE OR  a.ACTIVITED_CHATBOT_TO IS NULL ) AND  b.IS_ACTIVE=1 AND a.IS_INIT_FRM_CHATBOT=1 AND b.PRODUCT_FOR=?1",nativeQuery=true)
	List<JourneySetupDto> findProductByBOT(Integer productFor);
	
	
	@Query(value="select CASE RATE_TYPE WHEN 0 THEN 'Fixed' WHEN 1 THEN 'Floating' WHEN 2 THEN 'Floating with 5 year reset' ELSE 'NULL' END AS RATE_TYPE,CASE RATE_TYPE  WHEN 0 THEN FIXED_RATE WHEN 1 THEN FLOATING WHEN 2 THEN FLOATING_RESET_5YRS  ELSE 0 END AS intrate from KCR_PRODUCT where product_id=?1",nativeQuery=true)
	ProdIntrateDto findIntrate(Integer productId);
	
	
}
