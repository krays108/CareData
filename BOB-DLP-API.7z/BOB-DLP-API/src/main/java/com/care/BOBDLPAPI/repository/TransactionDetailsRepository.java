package com.care.BOBDLPAPI.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.care.BOBDLPAPI.dto.TransactionDetailsDto;
import com.care.BOBDLPAPI.model.TransactionDetails;

@Repository
public interface TransactionDetailsRepository extends JpaRepository<TransactionDetails,Long> {

        List<TransactionDetails> findByCustomerId(String customerId);
        
        
       @Query(value = "SELECT  a.CUSTOMER_ID, a.UNIQUE_IDENTIFIER_NUMBER,a.FULL_NAME,a.LOAN_TYPE,a.STATUS"
       		+ ",a.PURPOSE_OF_LOAN,a.LOAN_AMOUNT,b.PRODUCT,b.SUB_PRODUCT,b.PRODUCT_TYPE_ID "
       		+ "FROM DLP_TRANSACTION_DETAILS a  join DLP_LOGIN b on a.CUSTOMER_ID = b.CUSTOMER_ID "
       		+ "WHERE a.CUSTOMER_ID=?1  ORDER BY TRANSACTION_ID DESC",nativeQuery = true)
        List<TransactionDetailsDto> findResumeByCustomerId(String customerId );


		


       @Query(value="SELECT CUSTOMER_ID FROM DLP_LOGIN WHERE MOBILE=?1",nativeQuery=true)
   	List<String> findCustomerIdByMobile(Long mobile);


        
}
