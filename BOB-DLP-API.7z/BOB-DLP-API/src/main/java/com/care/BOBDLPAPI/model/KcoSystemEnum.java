package com.care.BOBDLPAPI.model;

import lombok.Data;

@Data
public class KcoSystemEnum {
	
	
	public String tableName;
	
	public String columnName;
	
	public Integer value;
	
	public String description;
	
	public String code;

}
