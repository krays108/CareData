
package com.care.BOBDLPAPI.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public interface ProdIntrateDto {
	
	@JsonProperty(value = "RATE_TYPE")
	public String getRATE_TYPE();
	
	@JsonProperty(value = "INTRATE")
	public Float getINTRATE();
	
	
}