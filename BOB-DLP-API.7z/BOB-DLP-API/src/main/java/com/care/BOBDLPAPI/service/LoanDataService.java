package com.care.BOBDLPAPI.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.care.BOBDLPAPI.model.LoanData;
import com.care.BOBDLPAPI.model.dto.LoanDataDto;
import com.care.BOBDLPAPI.repository.LoanDataRepository;
import com.care.BOBDLPAPI.util.DlpUtil;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class LoanDataService {
	
	@Autowired LoanDataRepository loanDataRepository;
	

	public ResponseEntity<LoanData> saveLoanData(LoanDataDto loanDataDto)  {
		List<LoanData> loanDataDetail=	loanDataRepository.findByCustomerId(loanDataDto.getCustomerId());
		if(!loanDataDetail.isEmpty()) {
			LoanData	editLoanData=	loanDataDetail.get(0);
			 
			editLoanData.setDescription(loanDataDto.getDescription());
			editLoanData.setIsValidated(loanDataDto.getIsValidated());
			editLoanData.setJourneySetuId(loanDataDto.getJourneySetuId());
			editLoanData.setJsonData(loanDataDto.getJsonData().toString());
			editLoanData.setRevisionNumber(loanDataDto.getRevisionNumber());
			editLoanData.setUniqueIdentifier(loanDataDto.getUniqueIdentifier());
			editLoanData.setUniqueIdentifierNumber(loanDataDto.getUniqueIdentifierNumber());
			LoanData updatedLoanData=  	loanDataRepository.save(editLoanData);
			return ResponseEntity.ok(updatedLoanData) ;
		}
		
		LoanData loanData=new LoanData();
		loanData.setCreatedDate(loanDataDto.getCreatedDate());
		loanData.setCustomerId(loanDataDto.getCustomerId());
		loanData.setDescription(loanDataDto.getDescription());
		loanData.setIsValidated(loanDataDto.getIsValidated());
		loanData.setRevisionNumber(loanDataDto.getRevisionNumber());
		loanData.setJourneySetuId(loanDataDto.getJourneySetuId());
		loanData.setUniqueIdentifier(loanDataDto.getUniqueIdentifier());
		loanData.setUniqueIdentifierNumber(loanDataDto.getUniqueIdentifierNumber());
		
		
		
		loanData.setJsonData(loanDataDto.getJsonData().toString());
		LoanData loanDataDtls=	loanDataRepository.save(loanData);
		return ResponseEntity.ok(loanDataDtls) ;
	}

	public ResponseEntity<?> getLoanDataInJson(String customerId) throws JsonMappingException, JsonProcessingException {
		List<LoanData> loanData=loanDataRepository.findByCustomerId(customerId);
		if(loanData.isEmpty()) {
			return ResponseEntity.ok(DlpUtil.INVALID_CUSTOMER) ;
		}
		
		 LoanData loanData2=loanDataRepository.findByCustomerId(customerId).get(0);
		  String jsonString = loanData2.getJsonData(); 
		  ObjectMapper mapper = new ObjectMapper();
		  
		  JsonNode actualObj = mapper.readTree(jsonString);
		 
		  LoanDataDto loanDataDto = new LoanDataDto();
		  loanDataDto.setCreatedDate(loanData2.getCreatedDate());
		  loanDataDto.setCustomerId(loanData2.getCustomerId());
		  loanDataDto.setDescription(loanData2.getDescription());
		  loanDataDto.setIsValidated(loanData2.getIsValidated());
		  loanDataDto.setJsonData(actualObj);
		  loanDataDto.setLoanDataId(loanData2.getLoanDataId());
		  loanDataDto.setRevisionNumber(loanData2.getRevisionNumber()); 
		  return
		  ResponseEntity.ok(loanDataDto);
		 
	}

}

