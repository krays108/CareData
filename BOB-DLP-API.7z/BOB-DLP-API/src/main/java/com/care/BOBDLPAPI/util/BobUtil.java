package com.care.BOBDLPAPI.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.json.JSONObject;
import org.json.XML;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.care.BOBDLPAPI.dto.ControlAction;
import com.care.BOBDLPAPI.dto.EntityDto;
import com.care.BOBDLPAPI.dto.EntryFormRule;
import com.care.BOBDLPAPI.dto.SystemDropdown;
import com.care.BOBDLPAPI.model.InputTypes;
import com.care.BOBDLPAPI.model.Section;
import com.care.BOBDLPAPI.repository.AdefRepository;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;

@Component
public class BobUtil {

	@Autowired
	DlpUtil dlpUtil;

	@Autowired
	CommonUtil commonUtil;

	@Autowired
	AdefRepository adefRepository;

	Map<Integer, JsonNode> idMap = new HashMap<>();

	Random random = new Random();
	
	
	
	public static  MultipartFile convertBase64ToMultipartFile(String base64String) throws IOException {
        // Decode Base64 string to byte array
        byte[] decodedBytes = Base64.getDecoder().decode(base64String);

        // Create ByteArrayResource from byte array
        ByteArrayResource resource = new ByteArrayResource(decodedBytes);

        // Create MockMultipartFile (you can also use other implementations of MultipartFile)
        return new MockMultipartFile("file","file.text", "text/plain", resource.getInputStream());
	}

	// XML to String converter method
	public static String convertXmlToString(Document doc) {
		DOMSource domSource = new DOMSource(doc);
		StringWriter writer = new StringWriter();
		StreamResult result = new StreamResult(writer);
		TransformerFactory tf = TransformerFactory.newInstance();
		Transformer transformer = null;
		try {
			transformer = tf.newTransformer();
			transformer.transform(domSource, result);
		} catch (TransformerException e) {
			throw new RuntimeException(e);
		}
		return writer.toString();
	}

	// String to XML converter method
	public static Document convertStringToXml(String xmlString) {

		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

		try {

			// optional, but recommended
			// process XML securely, avoid attacks like XML External Entities (XXE)
			dbf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);

			DocumentBuilder builder = dbf.newDocumentBuilder();

			Document doc = builder.parse(new InputSource(new StringReader(xmlString)));

			return doc;

		} catch (ParserConfigurationException | IOException | SAXException e) {
			throw new RuntimeException(e);
		}

	}

	// Clob to String Converter method
	public String clobToString(java.sql.Clob data) {
		final StringBuilder sb = new StringBuilder();

		try {
			final Reader reader = data.getCharacterStream();
			final BufferedReader br = new BufferedReader(reader);

			int b;
			while (-1 != (b = br.read())) {
				sb.append((char) b);
			}

			br.close();
		} catch (SQLException e) {
			System.out.println("error");
			return e.toString();
		} catch (IOException e)

		{
			System.out.println("error");
			return e.toString();

		}

		return sb.toString();

	}

	public JsonNode convertXmlToJsonNode(String xml) {

		XmlMapper xmlMapper = new XmlMapper();
		JsonNode node = null;
		try {
			node = xmlMapper.readTree(xml.getBytes("UTF-8"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ObjectMapper jsonMapper = new ObjectMapper();
		JsonNode json = jsonMapper.valueToTree(node);
		return json;
	}

	public JSONObject convertXmlToJson(String xml) {

		JSONObject jsonObject = XML.toJSONObject(xml);
		return jsonObject;
	}

	public List<EntryFormRule> getDropdownEntryformRule(JsonNode node) {
		JsonNode sectionList = node.get("dropdown-entryform-rule");
		List<EntryFormRule> entryForm = new ArrayList<>();
		if (sectionList != null && sectionList.isArray()) {
			sectionList.forEach(section -> {

				JsonNode visibilityType_1 = section.get(dlpUtil.VISIBILITY_TYPE);
				if (visibilityType_1 == null || visibilityType_1.asBoolean()) {

					EntryFormRule entryFormRule = new EntryFormRule();
					LinkedHashMap<Integer, ControlAction> sequenceMap = new LinkedHashMap<>();
					List<String> valueList = new ArrayList<>();
					JsonNode fieldName = section.get("field-name");
					JsonNode valueName = section.get("value-name");
					JsonNode controlActionList = section.get("control-action");
					JsonNode fieldActionList = section.get("field-action");
					String sectionSeqNumber = section.get(dlpUtil.ID).textValue();
					LinkedList<ControlAction> controlActionOrdered = new LinkedList<>();

					String fieldActt = "";
					String controlActt = "";

					if (fieldActionList != null && !fieldActionList.isArray()) {
						fieldActt = "field-action";
						JsonNode visibilityType = fieldActionList.get(dlpUtil.VISIBILITY_TYPE);
						if (visibilityType == null || visibilityType.asBoolean()) {
							List<String> labelList = new ArrayList<>();
							ControlAction controlAct = new ControlAction();
							controlAct.setActionName(fieldActionList.get("action-name").textValue());
							String multipleValues = fieldActionList.get("field-name").textValue();
							if (multipleValues.equalsIgnoreCase(dlpUtil.MULTIPLE_VALUES)) {
								String fieldId = fieldActionList.get("field-id").textValue();
								String[] splitId = fieldId.split("\n");
								for (String idd : splitId) {
									int id = Integer.parseInt(idd);
									JsonNode controlNode = idMap.get(id);
									if (controlNode != null) {
										String dataKey = controlNode.get(dlpUtil.DATA_KEY).asText();
										labelList.add(dataKey);
									}
								}
								controlAct.setControlName(labelList);

							} else {

								int id = fieldActionList.get("field-id").asInt();
								JsonNode controlNode = idMap.get(id);
								if (controlNode != null) {
									String dataKey = controlNode.get(dlpUtil.DATA_KEY).asText();
									labelList.add(dataKey);
									controlAct.setControlName(labelList);
								}
							}
							controlAct.setMatchType(fieldActionList.get("match-type").asText());
							String seqNumber = (fieldActionList.get(dlpUtil.ID).textValue());
							controlAct.setSeqNumber(Integer.parseInt(seqNumber));
							sequenceMap.put(Integer.parseInt(seqNumber), controlAct);
						}
					}

					else if (fieldActionList != null && fieldActionList.isArray()) {
						fieldActt = "field-action";
						fieldActionList.forEach(fieldAction -> {
							JsonNode visibilityType = fieldAction.get(dlpUtil.VISIBILITY_TYPE);
							if (visibilityType == null || visibilityType.asBoolean()) {
								List<String> labelList = new ArrayList<>();
								ControlAction controlAct = new ControlAction();
								controlAct.setActionName(fieldAction.get("action-name").textValue());

								String multipleValues = fieldAction.get("field-name").textValue();
								if (multipleValues.equalsIgnoreCase(dlpUtil.MULTIPLE_VALUES)) {
									String fieldId = fieldAction.get("field-id").textValue();
									String[] splitId = fieldId.split("\n");
									for (String idd : splitId) {
										int id = Integer.parseInt(idd);
										JsonNode controlNode = idMap.get(id);
										if (controlNode != null) {
											String dataKey = controlNode.get(dlpUtil.DATA_KEY).asText();
											labelList.add(dataKey);
										}
									}
									controlAct.setControlName(labelList);

								} else {
									int id = fieldAction.get("field-id").asInt();
									JsonNode controlNode = idMap.get(id);
									if (controlNode != null) {
										String dataKey = controlNode.get(dlpUtil.DATA_KEY).asText();
										labelList.add(dataKey);
										controlAct.setControlName(labelList);
									}
								}
								controlAct.setMatchType(fieldAction.get("match-type").asText());
								String seqNumber = fieldAction.get(dlpUtil.ID).textValue();
								controlAct.setSeqNumber(Integer.parseInt(seqNumber));
								sequenceMap.put(Integer.parseInt(seqNumber), controlAct);
							}
						});
					}

					if (controlActionList != null && !controlActionList.isArray()) {
						JsonNode visibilityType = controlActionList.get(dlpUtil.VISIBILITY_TYPE);
						if (visibilityType == null || visibilityType.asBoolean()) {
							controlActt = "control-action";
							ControlAction controlAct = new ControlAction();
							List<String> labelList = new ArrayList<>();
							controlAct.setActionName(controlActionList.get("action-name").textValue());
							labelList.add(controlActionList.get("control-name").textValue());
							controlAct.setControlName(labelList);
							String seqNumber = (controlActionList.get(dlpUtil.ID).textValue());
							controlAct.setSeqNumber(Integer.parseInt(seqNumber));
							controlAct.setMatchType(controlActionList.get("match-type").asText());
							sequenceMap.put(Integer.parseInt(seqNumber), controlAct);
						}
					}

					else if (controlActionList != null && controlActionList.isArray()) {
						controlActt = "control-action";
						controlActionList.forEach(controlAction -> {
							JsonNode visibilityType = controlAction.get(dlpUtil.VISIBILITY_TYPE);
							if (visibilityType == null || visibilityType.asBoolean()) {
								ControlAction controlAct = new ControlAction();
								List<String> labelList = new ArrayList<>();
								controlAct.setActionName(controlAction.get("action-name").textValue());
								labelList.add(controlAction.get("control-name").textValue());
								controlAct.setControlName(labelList);
								String seqNumber = controlAction.get(dlpUtil.ID).textValue();
								controlAct.setSeqNumber(Integer.parseInt(seqNumber));
								controlAct.setMatchType(controlAction.get("match-type").asText());
								sequenceMap.put(Integer.parseInt(seqNumber), controlAct);
							}
						});
					}

					List<Integer> listInteger = new ArrayList<>();
					listInteger.addAll(sequenceMap.keySet());// ;.sort(sequenceMap.keySet())
					Collections.sort(listInteger);

					listInteger.forEach(seqData -> {
						controlActionOrdered.add(sequenceMap.get(seqData));
					});

					if (fieldActt.equalsIgnoreCase("field-action")) {
						entryFormRule.setFieldAction(controlActionOrdered);
					} else if (controlActt.equalsIgnoreCase("control-action")) {
						entryFormRule.setControlAction(controlActionOrdered);
					}
					entryFormRule.setSeqNumber(Integer.parseInt(sectionSeqNumber));
					if (valueName.textValue().equalsIgnoreCase(dlpUtil.MULTIPLE_VALUES)) {
						String values = section.get("values").textValue();
						int fieldId = section.get("field-id").asInt();
						JsonNode controlNode = idMap.get(fieldId);
						JsonNode optionList = controlNode.get("option");
						if (optionList != null) {
							LinkedHashMap<Integer, JsonNode> optionMap = new LinkedHashMap<>();
							if (optionList.isArray()) {
								optionList.forEach(option -> {
									int value = option.get("value").asInt();
									optionMap.put(value, option);
								});
							} else {
								int value = optionList.get("value").asInt();
								optionMap.put(value, optionList);
							}
							String[] splitId = values.split("\n");
							for (String idd : splitId) {
								int id = Integer.parseInt(idd);
								JsonNode opt = optionMap.get(id);
								String text = opt.get("text").textValue();
								valueList.add(text);

							}
						}
						entryFormRule.setValueName(valueList);
					} else {
						valueList.add(valueName.textValue());
						entryFormRule.setValueName(valueList);
					}
					entryFormRule.setFieldName(fieldName.textValue());
					entryForm.add(entryFormRule);

				}
			});

		}

		else if (sectionList != null && !sectionList.isArray()) {

			JsonNode visibilityType_1 = sectionList.get(dlpUtil.VISIBILITY_TYPE);
			if (visibilityType_1 == null && visibilityType_1.asBoolean()) {
				JsonNode section = sectionList;
				EntryFormRule entryFormRule = new EntryFormRule();
				List<String> valueList = new ArrayList<>();
				LinkedHashMap<Integer, ControlAction> sequenceMap = new LinkedHashMap<>();
				JsonNode fieldName = section.get("field-name");
				JsonNode valueName = section.get("value-name");
				JsonNode controlActionList = section.get("control-action");
				JsonNode fieldActionList = section.get("field-action");
				String sectionSeqNumber = section.get(dlpUtil.ID).textValue();
				LinkedList<ControlAction> controlActionOrdered = new LinkedList<>();

				String fieldActt = "";
				String controlActt = "";

				if (fieldActionList != null && !fieldActionList.isArray()) {

					JsonNode visibilityType = fieldActionList.get(dlpUtil.VISIBILITY_TYPE);
					if (visibilityType == null || visibilityType.asBoolean()) {

						fieldActt = "field-action";
						ControlAction controlAct = new ControlAction();
						List<String> labelList = new ArrayList<>();

						controlAct.setActionName(fieldActionList.get("action-name").textValue());
						String multipleValues = fieldActionList.get("field-name").textValue();
						if (multipleValues.equalsIgnoreCase(dlpUtil.MULTIPLE_VALUES)) {
							String fieldId = fieldActionList.get("field-id").textValue();
							String[] splitId = fieldId.split("\n");
							for (String idd : splitId) {
								int id = Integer.parseInt(idd);
								JsonNode controlNode = idMap.get(id);
								if (controlNode != null) {
									String dataKey = controlNode.get(dlpUtil.DATA_KEY).asText();
									labelList.add(dataKey);
								}
							}
							controlAct.setControlName(labelList);

						} else {
							int id = fieldActionList.get("field-id").asInt();
							JsonNode controlNode = idMap.get(id);
							if (controlNode != null) {
								String dataKey = controlNode.get(dlpUtil.DATA_KEY).asText();
								labelList.add(dataKey);
								controlAct.setControlName(labelList);
							}
						}
						controlAct.setMatchType(fieldActionList.get("match-type").asText());
						String seqNumber = (fieldActionList.get(dlpUtil.ID).textValue());
						controlAct.setSeqNumber(Integer.parseInt(seqNumber));
						sequenceMap.put(Integer.parseInt(seqNumber), controlAct);

					}
				}

				else if (fieldActionList != null && fieldActionList.isArray()) {

					fieldActt = "field-action";
					fieldActionList.forEach(fieldAction -> {
						JsonNode visibilityType = fieldAction.get(dlpUtil.VISIBILITY_TYPE);
						if (visibilityType == null || visibilityType.asBoolean()) {
							ControlAction controlAct = new ControlAction();
							List<String> labelList = new ArrayList<>();

							controlAct.setActionName(fieldAction.get("action-name").textValue());
							String multipleValues = fieldAction.get("field-name").textValue();
							if (multipleValues.equalsIgnoreCase(dlpUtil.MULTIPLE_VALUES)) {
								String fieldId = fieldAction.get("field-id").textValue();
								String[] splitId = fieldId.split("\n");
								for (String idd : splitId) {
									int id = Integer.parseInt(idd);
									JsonNode controlNode = idMap.get(id);
									if (controlNode != null) {
										String dataKey = controlNode.get(dlpUtil.DATA_KEY).asText();
										labelList.add(dataKey);
									}
								}

								controlAct.setControlName(labelList);
							} else {
								int id = fieldAction.get("field-id").asInt();
								JsonNode controlNode = idMap.get(id);
								if (controlNode != null) {
									String dataKey = controlNode.get(dlpUtil.DATA_KEY).asText();
									labelList.add(dataKey);
									controlAct.setControlName(labelList);
								}
							}
							controlAct.setMatchType(fieldAction.get("match-type").asText());
							String seqNumber = fieldAction.get(dlpUtil.ID).textValue();
							controlAct.setSeqNumber(Integer.parseInt(seqNumber));
							sequenceMap.put(Integer.parseInt(seqNumber), controlAct);
						}
					});
				}

				if (!controlActionList.isArray()) {

					JsonNode visibilityType = controlActionList.get(dlpUtil.VISIBILITY_TYPE);
					if (visibilityType == null || visibilityType.asBoolean()) {
						controlActt = "control-action";
						ControlAction controlAct = new ControlAction();
						List<String> labelList = new ArrayList<>();
						controlAct.setActionName(controlActionList.get("action-name").textValue());
						labelList.add(controlActionList.get("control-name").textValue());
						controlAct.setControlName(labelList);
						String seqNumber = (controlActionList.get(dlpUtil.ID).textValue());
						controlAct.setMatchType(controlActionList.get("match-type").asText());
						controlAct.setSeqNumber(Integer.parseInt(seqNumber));
						sequenceMap.put(Integer.parseInt(seqNumber), controlAct);
					}
				}

				else if (controlActionList != null) {
					controlActt = "control-action";
					controlActionList.forEach(controlAction -> {

						JsonNode visibilityType = controlAction.get(dlpUtil.VISIBILITY_TYPE);
						if (visibilityType == null || visibilityType.asBoolean()) {
							ControlAction controlAct = new ControlAction();
							List<String> labelList = new ArrayList<>();

							controlAct.setActionName(controlAction.get("action-name").textValue());
							labelList.add(controlAction.get("control-name").textValue());
							controlAct.setControlName(labelList);
							String seqNumber = controlAction.get(dlpUtil.ID).textValue();
							controlAct.setSeqNumber(Integer.parseInt(seqNumber));
							controlAct.setMatchType(controlAction.get("match-type").asText());
							sequenceMap.put(Integer.parseInt(seqNumber), controlAct);
						}
					});
				}

				List<Integer> listInteger = new ArrayList<>();
				listInteger.addAll(sequenceMap.keySet());// ;.sort(sequenceMap.keySet())
				Collections.sort(listInteger);

				listInteger.forEach(seqData -> {
					controlActionOrdered.add(sequenceMap.get(seqData));
				});

				if (fieldActt.equalsIgnoreCase("field-action")) {
					entryFormRule.setFieldAction(controlActionOrdered);
				} else if (controlActt.equalsIgnoreCase("control-action")) {
					entryFormRule.setControlAction(controlActionOrdered);
				}
				entryFormRule.setSeqNumber(Integer.parseInt(sectionSeqNumber));
				if (valueName.textValue().equalsIgnoreCase(dlpUtil.MULTIPLE_VALUES)) {
					String values = section.get("values").textValue();
					int fieldId = section.get("field-id").asInt();
					JsonNode controlNode = idMap.get(fieldId);
					JsonNode optionList = controlNode.get("option");
					if (optionList != null) {
						LinkedHashMap<Integer, JsonNode> optionMap = new LinkedHashMap<>();
						if (optionList.isArray()) {
							optionList.forEach(option -> {
								int value = option.get("value").asInt();
								optionMap.put(value, option);
							});
						} else {
							int value = optionList.get("value").asInt();
							optionMap.put(value, optionList);
						}
						String[] splitId = values.split("\n");
						for (String idd : splitId) {
							int id = Integer.parseInt(idd);
							JsonNode opt = optionMap.get(id);
							String text = opt.get("text").textValue();
							valueList.add(text);

						}
					}
					entryFormRule.setValueName(valueList);
				} else {
					valueList.add(valueName.textValue());
					entryFormRule.setValueName(valueList);
				}
				entryFormRule.setFieldName(fieldName.textValue());
				entryForm.add(entryFormRule);
			}

		}

		return entryForm;

	}

	public List<Section> getEntryForm(JsonNode mSection, String uniqueIdentifier) {

		// JsonNode MsectionList=node.get(dlpUtil.M_SECTION);
		List<Section> entryFormList = new ArrayList<>();
		// MsectionList.forEach(n -> {
		JsonNode entryFromList = mSection.get(dlpUtil.ENTRY_FORM);
		String mSectionSeqNumber = mSection.get(dlpUtil.SEQUENCE_NUMBER).textValue();

		if (entryFromList != null && !entryFromList.isArray()) {

			Section sectionData = new Section();
			LinkedHashMap<Integer, InputTypes> sequenceMap = new LinkedHashMap<>();
			Integer entryFromListId = entryFromList.get(dlpUtil.ID).asInt();
			idMap.put(entryFromListId, entryFromList);

			JsonNode title = entryFromList.get(dlpUtil.DATA_KEY);
			JsonNode dropDownList = entryFromList.get(dlpUtil.DROPDOWN);
			JsonNode dateType = entryFromList.get(dlpUtil.DATE);
			JsonNode textList = entryFromList.get(dlpUtil.TEXT);
			JsonNode labelList = entryFromList.get(dlpUtil.LABLE);
			JsonNode numericList = entryFromList.get(dlpUtil.NUMERIC);
			JsonNode systemDropdownList = entryFromList.get(dlpUtil.SYSTEM_DROPDOWN);
			JsonNode textAreaList = entryFromList.get(dlpUtil.TEXT_AREA);
			JsonNode checkboxList = entryFromList.get(dlpUtil.CHECKBOX);
			JsonNode radioList = entryFromList.get(dlpUtil.RADIO);
			String sectionSeqNumber = entryFromList.get(dlpUtil.SEQUENCE_NUMBER).textValue();
			LinkedList<InputTypes> inputList = new LinkedList<>();
			LinkedList<InputTypes> inputListOrdered = new LinkedList<>();

			if (radioList != null && !radioList.isArray()) {

				JsonNode radio = radioList;

				Integer radioId = radio.get(dlpUtil.ID).asInt();
				idMap.put(radioId, radio);

				JsonNode visibilityType = radio.get(dlpUtil.VISIBILITY_TYPE);
				if (visibilityType == null || visibilityType.asBoolean()) {
					InputTypes inputTypes = new InputTypes();
					inputTypes.setFieldName(radio.get(dlpUtil.LABLE).textValue());
					inputTypes.setDataKey(radio.get(dlpUtil.DATA_KEY).textValue());
					inputTypes.setFieldType(dlpUtil.RADIO);
					inputTypes.setMandatory(radio.get(dlpUtil.MANDATORY).asBoolean());
					String seqNumber = radio.get(dlpUtil.SEQUENCE_NUMBER).textValue();
					JsonNode optionListItems = radio.get(dlpUtil.OPTION);
					LinkedList<String> optionNameList = new LinkedList<>();
					if (optionListItems != null && optionListItems.isArray()) {

						optionListItems.forEach(optionList -> {
							Integer radioOptionId = optionList.get(dlpUtil.ID).asInt();
							idMap.put(radioOptionId, optionList);
							optionNameList.add(optionList.get(dlpUtil.TEXT).textValue());
						});

					} else {
						Integer radioOptionId = optionListItems.get(dlpUtil.ID).asInt();
						idMap.put(radioOptionId, optionListItems);
						optionNameList.add(optionListItems.get(dlpUtil.TEXT).textValue());
					}
					inputTypes.setFieldValues(optionNameList);
					inputTypes.setSeqNumber(Integer.parseInt(seqNumber));
					sequenceMap.put(Integer.parseInt(seqNumber), inputTypes);
					inputList.add(inputTypes);

				}
			}

			if (radioList != null && radioList.isArray()) {
				radioList.forEach(radio -> {

					Integer radioId = radio.get(dlpUtil.ID).asInt();
					idMap.put(radioId, radio);

					JsonNode visibilityType = radio.get(dlpUtil.VISIBILITY_TYPE);
					if (visibilityType == null || visibilityType.asBoolean()) {
						InputTypes inputTypes = new InputTypes();
						inputTypes.setFieldName(radio.get(dlpUtil.LABLE).textValue());
						inputTypes.setDataKey(radio.get(dlpUtil.DATA_KEY).textValue());
						inputTypes.setFieldType(dlpUtil.RADIO);
						inputTypes.setMandatory(radio.get(dlpUtil.MANDATORY).asBoolean());
						String seqNumber = radio.get(dlpUtil.SEQUENCE_NUMBER).textValue();
						JsonNode optionListItems = radio.get(dlpUtil.OPTION);
						LinkedList<String> optionNameList = new LinkedList<>();
						if (optionListItems != null && optionListItems.isArray()) {

							optionListItems.forEach(optionList -> {

								optionNameList.add(optionList.get(dlpUtil.TEXT).textValue());

								Integer radioOptionId = optionList.get(dlpUtil.ID).asInt();
								idMap.put(radioOptionId, optionList);

							});

						} else {
							Integer radioOptionId = optionListItems.get(dlpUtil.ID).asInt();
							idMap.put(radioOptionId, optionListItems);
							optionNameList.add(optionListItems.get(dlpUtil.TEXT).textValue());
						}
						inputTypes.setFieldValues(optionNameList);
						inputTypes.setSeqNumber(Integer.parseInt(seqNumber));
						sequenceMap.put(Integer.parseInt(seqNumber), inputTypes);
						inputList.add(inputTypes);

					}
				});
			}

			if (checkboxList != null && !checkboxList.isArray()) {

				JsonNode checkbox = checkboxList;

				Integer checkboxId = checkbox.get(dlpUtil.ID).asInt();
				idMap.put(checkboxId, checkbox);

				JsonNode visibilityType = checkbox.get(dlpUtil.VISIBILITY_TYPE);
				if (visibilityType == null || visibilityType.asBoolean()) {
					InputTypes inputTypes = new InputTypes();
					inputTypes.setFieldName(checkbox.get(dlpUtil.LABLE).textValue());
					inputTypes.setDataKey(checkbox.get(dlpUtil.DATA_KEY).textValue());
					inputTypes.setFieldType(dlpUtil.CHECKBOX);
					inputTypes.setMandatory(checkbox.get(dlpUtil.MANDATORY).asBoolean());
					String seqNumber = checkbox.get(dlpUtil.SEQUENCE_NUMBER).textValue();
					JsonNode optionListItems = checkbox.get(dlpUtil.OPTION);
					LinkedList<String> optionNameList = new LinkedList<>();
					if (optionListItems != null && optionListItems.isArray()) {

						optionListItems.forEach(optionList -> {
							Integer checkboxOptionId = optionList.get(dlpUtil.ID).asInt();
							idMap.put(checkboxOptionId, optionList);
							optionNameList.add(optionList.get(dlpUtil.TEXT).textValue());
						});

					} else {
						optionNameList.add(optionListItems.get(dlpUtil.TEXT).textValue());
						Integer checkboxOptionId = optionListItems.get(dlpUtil.ID).asInt();
						idMap.put(checkboxOptionId, optionListItems);
					}
					inputTypes.setFieldValues(optionNameList);
					inputTypes.setSeqNumber(Integer.parseInt(seqNumber));
					sequenceMap.put(Integer.parseInt(seqNumber), inputTypes);
					inputList.add(inputTypes);
				}
			}

			if (checkboxList != null && checkboxList.isArray()) {
				checkboxList.forEach(checkbox -> {

					Integer checkboxId = checkbox.get(dlpUtil.ID).asInt();
					idMap.put(checkboxId, checkbox);

					JsonNode visibilityType = checkbox.get(dlpUtil.VISIBILITY_TYPE);
					if (visibilityType == null || visibilityType.asBoolean()) {
						InputTypes inputTypes = new InputTypes();
						inputTypes.setFieldName(checkbox.get(dlpUtil.LABLE).textValue());
						inputTypes.setDataKey(checkbox.get(dlpUtil.DATA_KEY).textValue());
						inputTypes.setFieldType(dlpUtil.DROPDOWN);
						inputTypes.setMandatory(checkbox.get(dlpUtil.MANDATORY).asBoolean());
						String seqNumber = checkbox.get(dlpUtil.SEQUENCE_NUMBER).textValue();
						JsonNode optionListItems = checkbox.get(dlpUtil.OPTION);
						LinkedList<String> optionNameList = new LinkedList<>();
						if (optionListItems != null && optionListItems.isArray()) {

							optionListItems.forEach(optionList -> {
								optionNameList.add(optionList.get(dlpUtil.TEXT).textValue());
								Integer checkboxOptionId = optionList.get(dlpUtil.ID).asInt();
								idMap.put(checkboxOptionId, optionList);
							});

						} else {
							optionNameList.add(optionListItems.get(dlpUtil.TEXT).textValue());
							Integer checkboxOptionId = optionListItems.get(dlpUtil.ID).asInt();
							idMap.put(checkboxOptionId, optionListItems);
						}
						inputTypes.setFieldValues(optionNameList);
						inputTypes.setSeqNumber(Integer.parseInt(seqNumber));
						sequenceMap.put(Integer.parseInt(seqNumber), inputTypes);
						inputList.add(inputTypes);

					}
				});
			}

			if (textAreaList != null) {

				if (!textAreaList.isArray()) {

					JsonNode textArea = textAreaList;

					Integer textAreaId = textArea.get(dlpUtil.ID).asInt();
					idMap.put(textAreaId, textArea);

					JsonNode visibilityType = textArea.get(dlpUtil.VISIBILITY_TYPE);
					if (visibilityType == null || visibilityType.asBoolean()) {
						InputTypes inputTypes = new InputTypes();
						inputTypes.setFieldName(textArea.get(dlpUtil.LABLE).textValue());

						inputTypes.setDataKey(textArea.get(dlpUtil.DATA_KEY).textValue());

						inputTypes.setFieldType(dlpUtil.TEXT_AREA);
						inputTypes.setMandatory(textArea.get(dlpUtil.MANDATORY).asBoolean());
						String seqNumber = textArea.get(dlpUtil.SEQUENCE_NUMBER).textValue();
						inputTypes.setSeqNumber(Integer.parseInt(seqNumber));
						sequenceMap.put(Integer.parseInt(seqNumber), inputTypes);
						inputList.add(inputTypes);
					}
				}

				else {
					textAreaList.forEach(textArea -> {

						Integer textAreaId = textArea.get(dlpUtil.ID).asInt();
						idMap.put(textAreaId, textArea);

						JsonNode visibilityType = textArea.get(dlpUtil.VISIBILITY_TYPE);
						if (visibilityType == null || visibilityType.asBoolean()) {
							InputTypes inputTypes = new InputTypes();
							inputTypes.setFieldName(textArea.get(dlpUtil.LABLE).textValue());

							inputTypes.setDataKey(textArea.get(dlpUtil.DATA_KEY).textValue());

							inputTypes.setFieldType(dlpUtil.TEXT_AREA);
							inputTypes.setMandatory(textArea.get(dlpUtil.MANDATORY).asBoolean());
							String seqNumber = textArea.get(dlpUtil.SEQUENCE_NUMBER).textValue();
							inputTypes.setSeqNumber(Integer.parseInt(seqNumber));
							sequenceMap.put(Integer.parseInt(seqNumber), inputTypes);
							inputList.add(inputTypes);
						}
					});
				}
			}

			if (systemDropdownList != null) {

				if (!systemDropdownList.isArray()) {

					JsonNode systemDropdown = systemDropdownList;

					Integer systemDropdownId = systemDropdown.get(dlpUtil.ID).asInt();
					idMap.put(systemDropdownId, systemDropdown);

					JsonNode visibilityType = systemDropdown.get(dlpUtil.VISIBILITY_TYPE);

					if (visibilityType == null || visibilityType.asBoolean()) {
						InputTypes inputTypes = new InputTypes();
						inputTypes.setFieldName(systemDropdown.get(dlpUtil.LABLE).textValue());

						inputTypes.setDataKey(systemDropdown.get(dlpUtil.DATA_KEY).textValue());

						if (systemDropdown.get("source-name") != null && systemDropdown.get("row-field") != null) {
							String tableName = systemDropdown.get("source-name").textValue();
							String columnName = systemDropdown.get("row-field").textValue();
							String result = commonUtil.getCounterPartyName(tableName, columnName, uniqueIdentifier);
							inputTypes.setCounterparty(result);
						}

						if (systemDropdown.get(dlpUtil.SOURCE) != null) {
							String source = systemDropdown.get(dlpUtil.SOURCE).textValue();
							List<?> systemList = commonUtil.getSystemDropDown(source);
							if (systemList != null) {
								inputTypes.setSystemDropDownList(systemList);
							} else {

								List<EntityDto> configList = commonUtil.getConfigList(source);
								inputTypes.setSystemDropDownList(configList);
							}

						}

						inputTypes.setFieldType(dlpUtil.SYSTEM_DROPDOWN);
						inputTypes.setMandatory(systemDropdown.get(dlpUtil.MANDATORY).asBoolean());
						String seqNumber = systemDropdown.get(dlpUtil.SEQUENCE_NUMBER).textValue();
						inputTypes.setSeqNumber(Integer.parseInt(seqNumber));
						sequenceMap.put(Integer.parseInt(seqNumber), inputTypes);
						inputList.add(inputTypes);
					}
				}

				else {
					systemDropdownList.forEach(systemDropdown -> {

						Integer systemDropdownId = systemDropdown.get(dlpUtil.ID).asInt();
						idMap.put(systemDropdownId, systemDropdown);

						JsonNode visibilityType = systemDropdown.get(dlpUtil.VISIBILITY_TYPE);

						if (visibilityType == null || visibilityType.asBoolean()) {
							InputTypes inputTypes = new InputTypes();
							inputTypes.setFieldName(systemDropdown.get(dlpUtil.LABLE).textValue());

							inputTypes.setDataKey(systemDropdown.get(dlpUtil.DATA_KEY).textValue());

							if (systemDropdown.get("source-name") != null && systemDropdown.get("row-field") != null) {
								String tableName = systemDropdown.get("source-name").textValue();
								String columnName = systemDropdown.get("row-field").textValue();
								String result = commonUtil.getCounterPartyName(tableName, columnName, uniqueIdentifier);
								inputTypes.setCounterparty(result);
							}

							if (systemDropdown.get(dlpUtil.SOURCE) != null) {
								String source = systemDropdown.get(dlpUtil.SOURCE).textValue();
								List<?> systemList = commonUtil.getSystemDropDown(source);
								if (systemList != null) {
									inputTypes.setSystemDropDownList(systemList);
								} else {

									List<EntityDto> configList = commonUtil.getConfigList(source);
									inputTypes.setSystemDropDownList(configList);
								}

							}

							inputTypes.setFieldType(dlpUtil.SYSTEM_DROPDOWN);
							inputTypes.setMandatory(systemDropdown.get(dlpUtil.MANDATORY).asBoolean());
							String seqNumber = systemDropdown.get(dlpUtil.SEQUENCE_NUMBER).textValue();
							inputTypes.setSeqNumber(Integer.parseInt(seqNumber));
							sequenceMap.put(Integer.parseInt(seqNumber), inputTypes);
							inputList.add(inputTypes);

						}
					});
				}
			}
			if (dropDownList != null && !dropDownList.isArray()) {

				JsonNode dropDown = dropDownList;

				Integer dropDownId = dropDown.get(dlpUtil.ID).asInt();
				idMap.put(dropDownId, dropDown);

				JsonNode visibilityType = dropDown.get(dlpUtil.VISIBILITY_TYPE);
				if (visibilityType == null || visibilityType.asBoolean()) {
					InputTypes inputTypes = new InputTypes();
					inputTypes.setFieldName(dropDown.get(dlpUtil.LABLE).textValue());
					inputTypes.setDataKey(dropDown.get(dlpUtil.DATA_KEY).textValue());
					inputTypes.setFieldType(dlpUtil.DROPDOWN);
					inputTypes.setMandatory(dropDown.get(dlpUtil.MANDATORY).asBoolean());
					String seqNumber = dropDown.get(dlpUtil.SEQUENCE_NUMBER).textValue();
					JsonNode optionListItems = dropDown.get(dlpUtil.OPTION);
					LinkedList<String> optionNameList = new LinkedList<>();
					if (optionListItems.isArray()) {

						optionListItems.forEach(optionList -> {
							optionNameList.add(optionList.get(dlpUtil.TEXT).textValue());
							Integer dropDownOptionListId = optionList.get(dlpUtil.ID).asInt();
							idMap.put(dropDownOptionListId, optionList);

						});

					} else {
						optionNameList.add(optionListItems.get(dlpUtil.TEXT).textValue());
						Integer dropDownOptionListId = optionListItems.get(dlpUtil.ID).asInt();
						idMap.put(dropDownOptionListId, optionListItems);
					}
					
					
					if (dropDown.get("source-name") != null && dropDown.get("row-field") != null) {
						String tableName = dropDown.get("source-name").textValue();
						String columnName = dropDown.get("row-field").textValue();
						String result = commonUtil.getCounterPartyName(tableName, columnName, uniqueIdentifier);
						inputTypes.setCounterparty(result);
					}
					
					inputTypes.setFieldValues(optionNameList);
					inputTypes.setSeqNumber(Integer.parseInt(seqNumber));
					sequenceMap.put(Integer.parseInt(seqNumber), inputTypes);
					inputList.add(inputTypes);

				}
			}

			if (dropDownList != null && dropDownList.isArray()) {
				dropDownList.forEach(dropDown -> {

					Integer dropDownId = dropDown.get(dlpUtil.ID).asInt();
					idMap.put(dropDownId, dropDown);

					JsonNode visibilityType = dropDown.get(dlpUtil.VISIBILITY_TYPE);
					if (visibilityType == null || visibilityType.asBoolean()) {
						InputTypes inputTypes = new InputTypes();
						inputTypes.setFieldName(dropDown.get(dlpUtil.LABLE).textValue());
						inputTypes.setDataKey(dropDown.get(dlpUtil.DATA_KEY).textValue());
						inputTypes.setFieldType(dlpUtil.DROPDOWN);
						inputTypes.setMandatory(dropDown.get(dlpUtil.MANDATORY).asBoolean());
						String seqNumber = dropDown.get(dlpUtil.SEQUENCE_NUMBER).textValue();
						JsonNode optionListItems = dropDown.get(dlpUtil.OPTION);
						LinkedList<String> optionNameList = new LinkedList<>();
						if (optionListItems != null && optionListItems.isArray()) {

							optionListItems.forEach(optionList -> {
								optionNameList.add(optionList.get(dlpUtil.TEXT).textValue());
								Integer dropDownOptionListId = optionList.get(dlpUtil.ID).asInt();
								idMap.put(dropDownOptionListId, optionList);

							});

						} else {
							optionNameList.add(optionListItems.get(dlpUtil.TEXT).textValue());
							Integer dropDownOptionListId = optionListItems.get(dlpUtil.ID).asInt();
							idMap.put(dropDownOptionListId, optionListItems);

						}
						
						
						if (dropDown.get("source-name") != null && dropDown.get("row-field") != null) {
							String tableName = dropDown.get("source-name").textValue();
							String columnName = dropDown.get("row-field").textValue();
							String result = commonUtil.getCounterPartyName(tableName, columnName, uniqueIdentifier);
							inputTypes.setCounterparty(result);
						}
						
						inputTypes.setFieldValues(optionNameList);
						inputTypes.setSeqNumber(Integer.parseInt(seqNumber));
						sequenceMap.put(Integer.parseInt(seqNumber), inputTypes);
						inputList.add(inputTypes);

					}
				});
			}
			if (dateType != null) {
				if (!dateType.isArray()) {

					Integer dateTypeId = dateType.get(dlpUtil.ID).asInt();
					idMap.put(dateTypeId, dateType);

					JsonNode visibilityType = dateType.get(dlpUtil.VISIBILITY_TYPE);
					if (visibilityType == null || visibilityType.asBoolean()) {
						InputTypes inputTypes = new InputTypes();
						String seqNumber = dateType.get(dlpUtil.SEQUENCE_NUMBER).asText();
						inputTypes.setFieldName(dateType.get(dlpUtil.LABLE).textValue());

						inputTypes.setDataKey(dateType.get(dlpUtil.DATA_KEY).textValue());

						if (dateType.get("source-name") != null && dateType.get("row-field") != null) {
							String tableName = dateType.get("source-name").textValue();
							String columnName = dateType.get("row-field").textValue();
							String result = commonUtil.getCounterPartyName(tableName, columnName, uniqueIdentifier);
							inputTypes.setCounterparty(result);
						}

						inputTypes.setMandatory(dateType.get(dlpUtil.MANDATORY).asBoolean());
						inputTypes.setFieldType(dlpUtil.DATE);
						inputTypes.setSeqNumber(Integer.parseInt(seqNumber));
						sequenceMap.put(Integer.parseInt(seqNumber), inputTypes);
						inputList.add(inputTypes);
					}
				}

				if (dateType.isArray()) {
					dateType.forEach(date -> {

						Integer dateTypeId = date.get(dlpUtil.ID).asInt();
						idMap.put(dateTypeId, date);

						JsonNode visibilityType = date.get(dlpUtil.VISIBILITY_TYPE);
						if (visibilityType == null || visibilityType.asBoolean()) {
							InputTypes inputTypes = new InputTypes();
							String seqNumber = date.get(dlpUtil.SEQUENCE_NUMBER).asText();
							inputTypes.setFieldName(date.get(dlpUtil.LABLE).textValue());

							inputTypes.setDataKey(date.get(dlpUtil.DATA_KEY).textValue());

							if (date.get("source-name") != null && date.get("row-field") != null) {
								String tableName = date.get("source-name").textValue();
								String columnName = date.get("row-field").textValue();
								String result = commonUtil.getCounterPartyName(tableName, columnName, uniqueIdentifier);
								inputTypes.setCounterparty(result);
							}
							inputTypes.setMandatory(date.get(dlpUtil.MANDATORY).asBoolean());
							inputTypes.setFieldType(dlpUtil.DATE);
							inputTypes.setSeqNumber(Integer.parseInt(seqNumber));
							sequenceMap.put(Integer.parseInt(seqNumber), inputTypes);
							inputList.add(inputTypes);
						}
					});

				}
			}

			if (textList != null) {
				if (textList.isArray())
					textList.forEach(text -> {

						Integer textId = text.get(dlpUtil.ID).asInt();
						idMap.put(textId, text);

						JsonNode visibilityType = text.get(dlpUtil.VISIBILITY_TYPE);
						if (visibilityType == null || visibilityType.asBoolean()) {
							InputTypes inputTypes = new InputTypes();
							inputTypes.setFieldName(text.get(dlpUtil.LABLE).textValue());

							inputTypes.setDataKey(text.get(dlpUtil.DATA_KEY).textValue());

							if (text.get("source-name") != null && text.get("row-field") != null) {
								String tableName = text.get("source-name").textValue();
								String columnName = text.get("row-field").textValue();
								String result = commonUtil.getCounterPartyName(tableName, columnName, uniqueIdentifier);
								inputTypes.setCounterparty(result);
							}

							if (text.get("max-length") != null) {
								String maxLength = text.get("max-length").textValue();
								inputTypes.setMaxLength(Integer.parseInt(maxLength));

							}

							inputTypes.setFieldType(dlpUtil.TEXT);
							inputTypes.setMandatory(text.get(dlpUtil.MANDATORY).asBoolean());
							String seqNumber = text.get(dlpUtil.SEQUENCE_NUMBER).asText();
							inputTypes.setSeqNumber(Integer.parseInt(seqNumber));
							sequenceMap.put(Integer.parseInt(seqNumber), inputTypes);
							inputList.add(inputTypes);
						}
					});

				else {

					Integer textId = textList.get(dlpUtil.ID).asInt();
					idMap.put(textId, textList);

					JsonNode visibilityType = textList.get(dlpUtil.VISIBILITY_TYPE);
					if (visibilityType == null || visibilityType.asBoolean()) {
						InputTypes inputTypes = new InputTypes();
						inputTypes.setFieldName(textList.get(dlpUtil.LABLE).textValue());

						inputTypes.setDataKey(textList.get(dlpUtil.DATA_KEY).textValue());

						if (textList.get("source-name") != null && textList.get("row-field") != null) {
							String tableName = textList.get("source-name").textValue();
							String columnName = textList.get("row-field").textValue();
							String result = commonUtil.getCounterPartyName(tableName, columnName, uniqueIdentifier);
							inputTypes.setCounterparty(result);
						}

						if (textList.get("max-length") != null) {
							String maxLength = textList.get("max-length").textValue();
							inputTypes.setMaxLength(Integer.parseInt(maxLength));

						}

						inputTypes.setFieldType(dlpUtil.TEXT);
						String seqNumber = textList.get(dlpUtil.SEQUENCE_NUMBER).asText();
						inputTypes.setSeqNumber(Integer.parseInt(seqNumber));
						sequenceMap.put(Integer.parseInt(seqNumber), inputTypes);
						inputList.add(inputTypes);
					}
				}
			}
			if (labelList != null) {
				if (labelList.isArray())

					labelList.forEach(lable -> {

						Integer lableId = lable.get(dlpUtil.ID).asInt();
						idMap.put(lableId, lable);

						JsonNode visibilityType = lable.get(dlpUtil.VISIBILITY_TYPE);
						if (visibilityType == null || visibilityType.asBoolean()) {
							InputTypes inputTypes = new InputTypes();
							inputTypes.setFieldName(lable.get(dlpUtil.LABLE).textValue());
							if (lable.get(dlpUtil.DATA_KEY) != null) {
								inputTypes.setDataKey(lable.get(dlpUtil.DATA_KEY).textValue());
							}
							inputTypes.setFieldType(dlpUtil.LABLE);

							if (lable.get(dlpUtil.SEQUENCE_NUMBER) != null) {
								int seqNumber = lable.get(dlpUtil.SEQUENCE_NUMBER).asInt();
								inputTypes.setSeqNumber(seqNumber);
								sequenceMap.put(seqNumber, inputTypes);
								inputList.add(inputTypes);
							} else {
								int seqNumber = 10 + random.nextInt(80);
								inputTypes.setSeqNumber(seqNumber);
								sequenceMap.put(seqNumber, inputTypes);
								inputList.add(inputTypes);
							}

						}
					});

				else {

					Integer lableId = labelList.get(dlpUtil.ID).asInt();
					idMap.put(lableId, labelList);

					JsonNode visibilityType = labelList.get(dlpUtil.VISIBILITY_TYPE);
					if (visibilityType == null || visibilityType.asBoolean()) {
						InputTypes inputTypes = new InputTypes();
						inputTypes.setFieldName(labelList.get(dlpUtil.LABLE).textValue());

						if (labelList.get(dlpUtil.DATA_KEY) != null) {
							inputTypes.setDataKey(labelList.get(dlpUtil.DATA_KEY).textValue());
						}
						inputTypes.setFieldType(dlpUtil.LABLE);
						if (labelList.get(dlpUtil.SEQUENCE_NUMBER) != null) {
							int seqNumber = labelList.get(dlpUtil.SEQUENCE_NUMBER).asInt();
							inputTypes.setSeqNumber(seqNumber);
							sequenceMap.put(seqNumber, inputTypes);
							inputList.add(inputTypes);
						} else {
							int seqNumber = 10 + random.nextInt(80);
							inputTypes.setSeqNumber(seqNumber);
							sequenceMap.put(seqNumber, inputTypes);
							inputList.add(inputTypes);
						}

					}
				}
			}
			if (numericList != null) {
				if (numericList.isArray()) {

					numericList.forEach(numeric -> {

						Integer numericId = numeric.get(dlpUtil.ID).asInt();
						idMap.put(numericId, numeric);

						JsonNode visibilityType = numeric.get(dlpUtil.VISIBILITY_TYPE);
						if (visibilityType == null || visibilityType.asBoolean()) {
							InputTypes inputTypes = new InputTypes();
							inputTypes.setFieldName(numeric.get(dlpUtil.LABLE).textValue());

							inputTypes.setDataKey(numeric.get(dlpUtil.DATA_KEY).textValue());

							if (numeric.get("source-name") != null && numeric.get("row-field") != null) {
								String tableName = numeric.get("source-name").textValue();
								String columnName = numeric.get("row-field").textValue();
								String result = commonUtil.getCounterPartyName(tableName, columnName, uniqueIdentifier);
								inputTypes.setCounterparty(result);
							}

							if (numeric.get("max-value") != null) {
								String maxLength = numeric.get("max-value").textValue();
								inputTypes.setMaxLength(Integer.parseInt(maxLength));

							}

							inputTypes.setFieldType(dlpUtil.NUMERIC);
							inputTypes.setMandatory(numeric.get(dlpUtil.MANDATORY).asBoolean());
							String seqNumber = numeric.get(dlpUtil.SEQUENCE_NUMBER).asText();
							inputTypes.setSeqNumber(Integer.parseInt(seqNumber));
							sequenceMap.put(Integer.parseInt(seqNumber), inputTypes);
							inputList.add(inputTypes);

						}

					});
				} else {

					Integer numericId = numericList.get(dlpUtil.ID).asInt();
					idMap.put(numericId, numericList);

					JsonNode visibilityType = numericList.get(dlpUtil.VISIBILITY_TYPE);
					if (visibilityType == null || visibilityType.asBoolean()) {
						InputTypes inputTypes = new InputTypes();
						inputTypes.setFieldName(numericList.get(dlpUtil.LABLE).textValue());

						inputTypes.setDataKey(numericList.get(dlpUtil.DATA_KEY).textValue());

						if (numericList.get("source-name") != null && numericList.get("row-field") != null) {
							String tableName = numericList.get("source-name").textValue();
							String columnName = numericList.get("row-field").textValue();
							String result = commonUtil.getCounterPartyName(tableName, columnName, uniqueIdentifier);
							inputTypes.setCounterparty(result);
						}

						if (numericList.get("max-value") != null) {
							String maxLength = numericList.get("max-value").textValue();
							inputTypes.setMaxLength(Integer.parseInt(maxLength));

						}

						inputTypes.setFieldType(dlpUtil.NUMERIC);
						String seqNumber = numericList.get(dlpUtil.SEQUENCE_NUMBER).asText();
						inputTypes.setSeqNumber(Integer.parseInt(seqNumber));
						sequenceMap.put(Integer.parseInt(seqNumber), inputTypes);
						inputList.add(inputTypes);
					}
				}

			}
			List<Integer> listInteger = new ArrayList<>();
			listInteger.addAll(sequenceMap.keySet());// ;.sort(sequenceMap.keySet())
			Collections.sort(listInteger);

			listInteger.forEach(seqData -> {
				inputListOrdered.add(sequenceMap.get(seqData));
			});

			sectionData.setSeqNumber(Integer.parseInt(sectionSeqNumber));
			sectionData.setTitle(title.textValue());
			sectionData.setInputType(inputListOrdered);
			sectionData.setType(dlpUtil.ENTRY_FORM);
			entryFormList.add(sectionData);
		}

		else if (entryFromList != null && entryFromList.isArray()) {
			entryFromList.forEach(section -> {

				Integer entryFromListId = section.get(dlpUtil.ID).asInt();
				idMap.put(entryFromListId, section);

				Section sectionData = new Section();
				LinkedHashMap<Integer, InputTypes> sequenceMap = new LinkedHashMap<>();
				JsonNode title = section.get(dlpUtil.DATA_KEY);
				JsonNode dropDownList = section.get(dlpUtil.DROPDOWN);
				JsonNode dateType = section.get(dlpUtil.DATE);
				JsonNode textList = section.get(dlpUtil.TEXT);
				JsonNode labelList = section.get(dlpUtil.LABLE);
				JsonNode numericList = section.get(dlpUtil.NUMERIC);
				String sectionSeqNumber = section.get(dlpUtil.SEQUENCE_NUMBER).textValue();
				JsonNode systemDropdownList = section.get(dlpUtil.SYSTEM_DROPDOWN);
				JsonNode textAreaList = section.get(dlpUtil.TEXT_AREA);
				JsonNode radioList = entryFromList.get(dlpUtil.RADIO);
				JsonNode checkboxList = entryFromList.get(dlpUtil.CHECKBOX);
				LinkedList<InputTypes> inputList = new LinkedList<>();
				LinkedList<InputTypes> inputListOrdered = new LinkedList<>();

				if (checkboxList != null && !checkboxList.isArray()) {

					JsonNode checkbox = checkboxList;

					Integer checkboxId = checkbox.get(dlpUtil.ID).asInt();
					idMap.put(checkboxId, checkbox);

					JsonNode visibilityType = checkbox.get(dlpUtil.VISIBILITY_TYPE);
					if (visibilityType == null || visibilityType.asBoolean()) {
						InputTypes inputTypes = new InputTypes();
						inputTypes.setFieldName(checkbox.get(dlpUtil.LABLE).textValue());
						inputTypes.setDataKey(checkbox.get(dlpUtil.DATA_KEY).textValue());
						inputTypes.setFieldType(dlpUtil.CHECKBOX);
						inputTypes.setMandatory(checkbox.get(dlpUtil.MANDATORY).asBoolean());
						String seqNumber = checkbox.get(dlpUtil.SEQUENCE_NUMBER).textValue();
						JsonNode optionListItems = checkbox.get(dlpUtil.OPTION);
						LinkedList<String> optionNameList = new LinkedList<>();
						if (optionListItems.isArray()) {

							optionListItems.forEach(optionList -> {
								optionNameList.add(optionList.get(dlpUtil.TEXT).textValue());
								Integer optionListId = optionList.get(dlpUtil.ID).asInt();
								idMap.put(optionListId, optionList);
							});

						} else {
							optionNameList.add(optionListItems.get(dlpUtil.TEXT).textValue());
							Integer optionListId = optionListItems.get(dlpUtil.ID).asInt();
							idMap.put(optionListId, optionListItems);
						}
						inputTypes.setFieldValues(optionNameList);
						inputTypes.setSeqNumber(Integer.parseInt(seqNumber));
						sequenceMap.put(Integer.parseInt(seqNumber), inputTypes);
						inputList.add(inputTypes);

					}
				}

				if (checkboxList != null && checkboxList.isArray()) {
					checkboxList.forEach(checkbox -> {

						Integer checkboxId = checkbox.get(dlpUtil.ID).asInt();
						idMap.put(checkboxId, checkbox);

						JsonNode visibilityType = checkbox.get(dlpUtil.VISIBILITY_TYPE);
						if (visibilityType == null || visibilityType.asBoolean()) {
							InputTypes inputTypes = new InputTypes();
							inputTypes.setFieldName(checkbox.get(dlpUtil.LABLE).textValue());
							inputTypes.setDataKey(checkbox.get(dlpUtil.DATA_KEY).textValue());
							inputTypes.setFieldType(dlpUtil.DROPDOWN);
							inputTypes.setMandatory(checkbox.get(dlpUtil.MANDATORY).asBoolean());
							String seqNumber = checkbox.get(dlpUtil.SEQUENCE_NUMBER).textValue();
							JsonNode optionListItems = checkbox.get(dlpUtil.OPTION);
							LinkedList<String> optionNameList = new LinkedList<>();
							if (optionListItems != null && optionListItems.isArray()) {

								optionListItems.forEach(optionList -> {
									optionNameList.add(optionList.get(dlpUtil.TEXT).textValue());
									Integer optionListId = optionList.get(dlpUtil.ID).asInt();
									idMap.put(optionListId, optionList);
								});

							} else {
								optionNameList.add(optionListItems.get(dlpUtil.TEXT).textValue());
								Integer optionListId = optionListItems.get(dlpUtil.ID).asInt();
								idMap.put(optionListId, optionListItems);
							}
							inputTypes.setFieldValues(optionNameList);
							inputTypes.setSeqNumber(Integer.parseInt(seqNumber));
							sequenceMap.put(Integer.parseInt(seqNumber), inputTypes);
							inputList.add(inputTypes);

						}
					});
				}

				if (radioList != null && !radioList.isArray()) {

					JsonNode radio = radioList;

					Integer radioId = radio.get(dlpUtil.ID).asInt();
					idMap.put(radioId, radio);

					JsonNode visibilityType = radio.get(dlpUtil.VISIBILITY_TYPE);
					if (visibilityType == null || visibilityType.asBoolean()) {
						InputTypes inputTypes = new InputTypes();
						inputTypes.setFieldName(radio.get(dlpUtil.LABLE).textValue());
						inputTypes.setDataKey(radio.get(dlpUtil.DATA_KEY).textValue());
						inputTypes.setFieldType(dlpUtil.RADIO);
						inputTypes.setMandatory(radio.get(dlpUtil.MANDATORY).asBoolean());
						String seqNumber = radio.get(dlpUtil.SEQUENCE_NUMBER).textValue();
						JsonNode optionListItems = radio.get(dlpUtil.OPTION);
						LinkedList<String> optionNameList = new LinkedList<>();
						if (optionListItems.isArray()) {

							optionListItems.forEach(optionList -> {
								optionNameList.add(optionList.get(dlpUtil.TEXT).textValue());
								Integer optionListId = optionList.get(dlpUtil.ID).asInt();
								idMap.put(optionListId, optionList);
							});

						} else {
							optionNameList.add(optionListItems.get(dlpUtil.TEXT).textValue());
							Integer optionListId = optionListItems.get(dlpUtil.ID).asInt();
							idMap.put(optionListId, optionListItems);
						}
						inputTypes.setFieldValues(optionNameList);
						inputTypes.setSeqNumber(Integer.parseInt(seqNumber));
						sequenceMap.put(Integer.parseInt(seqNumber), inputTypes);
						inputList.add(inputTypes);
					}
				}

				if (radioList != null && radioList.isArray()) {
					radioList.forEach(radio -> {

						Integer radioId = radio.get(dlpUtil.ID).asInt();
						idMap.put(radioId, radio);

						JsonNode visibilityType = radio.get(dlpUtil.VISIBILITY_TYPE);
						if (visibilityType == null || visibilityType.asBoolean()) {
							InputTypes inputTypes = new InputTypes();
							inputTypes.setFieldName(radio.get(dlpUtil.LABLE).textValue());
							inputTypes.setDataKey(radio.get(dlpUtil.DATA_KEY).textValue());
							inputTypes.setFieldType(dlpUtil.RADIO);
							inputTypes.setMandatory(radio.get(dlpUtil.MANDATORY).asBoolean());
							String seqNumber = radio.get(dlpUtil.SEQUENCE_NUMBER).textValue();
							JsonNode optionListItems = radio.get(dlpUtil.OPTION);
							LinkedList<String> optionNameList = new LinkedList<>();
							if (optionListItems.isArray()) {

								optionListItems.forEach(optionList -> {
									optionNameList.add(optionList.get(dlpUtil.TEXT).textValue());
									Integer optionListId = optionList.get(dlpUtil.ID).asInt();
									idMap.put(optionListId, optionList);

								});

							} else {
								optionNameList.add(optionListItems.get(dlpUtil.TEXT).textValue());
								Integer optionListId = optionListItems.get(dlpUtil.ID).asInt();
								idMap.put(optionListId, optionListItems);
							}
							inputTypes.setFieldValues(optionNameList);
							inputTypes.setSeqNumber(Integer.parseInt(seqNumber));
							sequenceMap.put(Integer.parseInt(seqNumber), inputTypes);
							inputList.add(inputTypes);

						}
					});
				}

				if (dateType != null) {
					if (!dateType.isArray()) {

						Integer dateTypeId = dateType.get(dlpUtil.ID).asInt();
						idMap.put(dateTypeId, dateType);

						JsonNode visibilityType = dateType.get(dlpUtil.VISIBILITY_TYPE);
						if (visibilityType == null || visibilityType.asBoolean()) {
							InputTypes inputTypes = new InputTypes();
							String seqNumber = dateType.get(dlpUtil.SEQUENCE_NUMBER).asText();
							inputTypes.setFieldName(dateType.get(dlpUtil.LABLE).textValue());

							if (dateType.get("source-name") != null && dateType.get("row-field") != null) {
								String tableName = dateType.get("source-name").textValue();
								String columnName = dateType.get("row-field").textValue();
								String result = commonUtil.getCounterPartyName(tableName, columnName, uniqueIdentifier);
								inputTypes.setCounterparty(result);
							}

							inputTypes.setDataKey(dateType.get(dlpUtil.DATA_KEY).textValue());

							inputTypes.setMandatory(dateType.get(dlpUtil.MANDATORY).asBoolean());
							inputTypes.setFieldType(dlpUtil.DATE);
							inputTypes.setSeqNumber(Integer.parseInt(seqNumber));
							sequenceMap.put(Integer.parseInt(seqNumber), inputTypes);
							inputList.add(inputTypes);
						}
					}

					if (dateType.isArray()) {
						dateType.forEach(date -> {

							Integer dateTypeId = date.get(dlpUtil.ID).asInt();
							idMap.put(dateTypeId, date);

							JsonNode visibilityType = date.get(dlpUtil.VISIBILITY_TYPE);
							if (visibilityType == null || visibilityType.asBoolean()) {
								InputTypes inputTypes = new InputTypes();
								String seqNumber = date.get(dlpUtil.SEQUENCE_NUMBER).asText();
								inputTypes.setFieldName(date.get(dlpUtil.LABLE).textValue());

								inputTypes.setDataKey(date.get(dlpUtil.DATA_KEY).textValue());

								if (date.get("source-name") != null && date.get("row-field") != null) {
									String tableName = date.get("source-name").textValue();
									String columnName = date.get("row-field").textValue();
									String result = commonUtil.getCounterPartyName(tableName, columnName,
											uniqueIdentifier);
									inputTypes.setCounterparty(result);
								}
								inputTypes.setMandatory(date.get(dlpUtil.MANDATORY).asBoolean());
								inputTypes.setFieldType(dlpUtil.DATE);
								inputTypes.setSeqNumber(Integer.parseInt(seqNumber));
								sequenceMap.put(Integer.parseInt(seqNumber), inputTypes);
								inputList.add(inputTypes);
							}
						});

					}
				}

				if (textAreaList != null) {

					if (!textAreaList.isArray()) {

						JsonNode textArea = textAreaList;

						Integer textAreaId = textArea.get(dlpUtil.ID).asInt();
						idMap.put(textAreaId, textArea);

						JsonNode visibilityType = textArea.get(dlpUtil.VISIBILITY_TYPE);
						if (visibilityType == null || visibilityType.asBoolean()) {
							InputTypes inputTypes = new InputTypes();
							// System.out.println("lable::::::" + textArea.get(dlpUtil.LABLE).toString());
							inputTypes.setFieldName(textArea.get(dlpUtil.LABLE).textValue());

							inputTypes.setDataKey(textArea.get(dlpUtil.DATA_KEY).textValue());

							inputTypes.setFieldType(dlpUtil.TEXT_AREA);
							inputTypes.setMandatory(textArea.get(dlpUtil.MANDATORY).asBoolean());
							String seqNumber = textArea.get(dlpUtil.SEQUENCE_NUMBER).textValue();
							inputTypes.setSeqNumber(Integer.parseInt(seqNumber));
							sequenceMap.put(Integer.parseInt(seqNumber), inputTypes);
							inputList.add(inputTypes);
						}
					}

					else {
						textAreaList.forEach(textArea -> {

							Integer textAreaId = textArea.get(dlpUtil.ID).asInt();
							idMap.put(textAreaId, textArea);

							JsonNode visibilityType = textArea.get(dlpUtil.VISIBILITY_TYPE);
							if (visibilityType == null || visibilityType.asBoolean()) {
								InputTypes inputTypes = new InputTypes();
								// System.out.println("lable::::::" + textArea.get(dlpUtil.LABLE).toString());
								inputTypes.setFieldName(textArea.get(dlpUtil.LABLE).textValue());

								inputTypes.setDataKey(textArea.get(dlpUtil.DATA_KEY).textValue());

								inputTypes.setFieldType(dlpUtil.TEXT_AREA);
								inputTypes.setMandatory(textArea.get(dlpUtil.MANDATORY).asBoolean());
								String seqNumber = textArea.get(dlpUtil.SEQUENCE_NUMBER).textValue();
								inputTypes.setSeqNumber(Integer.parseInt(seqNumber));
								sequenceMap.put(Integer.parseInt(seqNumber), inputTypes);
								inputList.add(inputTypes);
							}
						});
					}
				}

				if (systemDropdownList != null) {

					if (!systemDropdownList.isArray()) {

						JsonNode systemDropdown = systemDropdownList;

						Integer systemDropdownId = systemDropdown.get(dlpUtil.ID).asInt();
						idMap.put(systemDropdownId, systemDropdown);

						JsonNode visibilityType = systemDropdown.get(dlpUtil.VISIBILITY_TYPE);
						if (visibilityType == null || visibilityType.asBoolean()) {
							SystemDropdown system = new SystemDropdown();
							InputTypes inputTypes = new InputTypes();
							inputTypes.setFieldName(systemDropdown.get(dlpUtil.LABLE).textValue());

							inputTypes.setDataKey(systemDropdown.get(dlpUtil.DATA_KEY).textValue());

							if (systemDropdown.get("source-name") != null && systemDropdown.get("row-field") != null) {
								String tableName = systemDropdown.get("source-name").textValue();
								String columnName = systemDropdown.get("row-field").textValue();
								String result = commonUtil.getCounterPartyName(tableName, columnName, uniqueIdentifier);
								inputTypes.setCounterparty(result);
							}

							if (systemDropdown.get(dlpUtil.SOURCE) != null) {
								String source = systemDropdown.get(dlpUtil.SOURCE).textValue();
								List<?> systemList = commonUtil.getSystemDropDown(source);
								if (systemList != null) {
									inputTypes.setSystemDropDownList(systemList);
								} else {

									List<EntityDto> configList = commonUtil.getConfigList(source);
									inputTypes.setSystemDropDownList(configList);
								}

							}

							inputTypes.setFieldType(dlpUtil.SYSTEM_DROPDOWN);
							inputTypes.setMandatory(systemDropdown.get(dlpUtil.MANDATORY).asBoolean());
							String seqNumber = systemDropdown.get(dlpUtil.SEQUENCE_NUMBER).textValue();
							inputTypes.setSeqNumber(Integer.parseInt(seqNumber));
							sequenceMap.put(Integer.parseInt(seqNumber), inputTypes);
							inputList.add(inputTypes);
						}
					}

					else {
						systemDropdownList.forEach(systemDropdown -> {

							Integer systemDropdownId = systemDropdown.get(dlpUtil.ID).asInt();
							idMap.put(systemDropdownId, systemDropdown);

							JsonNode visibilityType = systemDropdown.get(dlpUtil.VISIBILITY_TYPE);
							if (visibilityType == null || visibilityType.asBoolean()) {
								InputTypes inputTypes = new InputTypes();
								SystemDropdown system = new SystemDropdown();
								inputTypes.setFieldName(systemDropdown.get(dlpUtil.LABLE).textValue());

								inputTypes.setDataKey(systemDropdown.get(dlpUtil.DATA_KEY).textValue());

								if (systemDropdown.get("source-name") != null
										&& systemDropdown.get("row-field") != null) {
									String tableName = systemDropdown.get("source-name").textValue();
									String columnName = systemDropdown.get("row-field").textValue();
									String result = commonUtil.getCounterPartyName(tableName, columnName,
											uniqueIdentifier);
									inputTypes.setCounterparty(result);
								}

								if (systemDropdown.get(dlpUtil.SOURCE) != null) {
									String source = systemDropdown.get(dlpUtil.SOURCE).textValue();
									List<?> systemList = commonUtil.getSystemDropDown(source);
									if (systemList != null) {
										inputTypes.setSystemDropDownList(systemList);
									} else {

										List<EntityDto> configList = commonUtil.getConfigList(source);
										inputTypes.setSystemDropDownList(configList);
									}

								}
								inputTypes.setFieldType(dlpUtil.SYSTEM_DROPDOWN);
								inputTypes.setMandatory(systemDropdown.get(dlpUtil.MANDATORY).asBoolean());
								String seqNumber = systemDropdown.get(dlpUtil.SEQUENCE_NUMBER).textValue();
								inputTypes.setSeqNumber(Integer.parseInt(seqNumber));
								sequenceMap.put(Integer.parseInt(seqNumber), inputTypes);
								inputList.add(inputTypes);
							}
						});

					}
				}

				if (dropDownList != null && !dropDownList.isArray()) {

					JsonNode dropDown = dropDownList;

					Integer dropDownId = dropDown.get(dlpUtil.ID).asInt();
					idMap.put(dropDownId, dropDown);

					JsonNode visibilityType = dropDown.get(dlpUtil.VISIBILITY_TYPE);
					if (visibilityType == null || visibilityType.asBoolean()) {
						InputTypes inputTypes = new InputTypes();
						// System.out.println("lable::::::" + dropDown.get(dlpUtil.LABLE).toString());
						inputTypes.setFieldName(dropDown.get(dlpUtil.LABLE).textValue());
						inputTypes.setDataKey(dropDown.get(dlpUtil.DATA_KEY).textValue());
						inputTypes.setFieldType(dlpUtil.DROPDOWN);
						inputTypes.setMandatory(dropDown.get(dlpUtil.MANDATORY).asBoolean());
						String seqNumber = dropDown.get(dlpUtil.SEQUENCE_NUMBER).textValue();
						JsonNode optionListItems = dropDown.get(dlpUtil.OPTION);
						LinkedList<String> optionNameList = new LinkedList<>();
						if (optionListItems.isArray()) {

							optionListItems.forEach(optionList -> {
								Integer optionListId = optionList.get(dlpUtil.ID).asInt();
								idMap.put(optionListId, optionList);
								optionNameList.add(optionList.get(dlpUtil.TEXT).textValue());

							});

						} else {
							Integer optionListId = optionListItems.get(dlpUtil.ID).asInt();
							idMap.put(optionListId, optionListItems);
							optionNameList.add(optionListItems.get(dlpUtil.TEXT).textValue());

						}
						
						
						if (dropDown.get("source-name") != null && dropDown.get("row-field") != null) {
							String tableName = dropDown.get("source-name").textValue();
							String columnName = dropDown.get("row-field").textValue();
							String result = commonUtil.getCounterPartyName(tableName, columnName, uniqueIdentifier);
							inputTypes.setCounterparty(result);
						}
						
						inputTypes.setFieldValues(optionNameList);
						inputTypes.setSeqNumber(Integer.parseInt(seqNumber));
						sequenceMap.put(Integer.parseInt(seqNumber), inputTypes);
						inputList.add(inputTypes);
					}
				}

				if (dropDownList != null && dropDownList.isArray())
					dropDownList.forEach(dropDown -> {

						Integer dropDownId = dropDown.get(dlpUtil.ID).asInt();
						idMap.put(dropDownId, dropDown);

						JsonNode visibilityType = dropDown.get(dlpUtil.VISIBILITY_TYPE);
						if (visibilityType == null || visibilityType.asBoolean()) {
							InputTypes inputTypes = new InputTypes();
							// System.out.println("lable::::::" + dropDown.get(dlpUtil.LABLE).toString());
							inputTypes.setFieldName(dropDown.get(dlpUtil.LABLE).textValue());
							inputTypes.setDataKey(dropDown.get(dlpUtil.DATA_KEY).textValue());
							inputTypes.setFieldType(dlpUtil.DROPDOWN);
							inputTypes.setMandatory(dropDown.get(dlpUtil.MANDATORY).asBoolean());
							String seqNumber = dropDown.get(dlpUtil.SEQUENCE_NUMBER).textValue();
							JsonNode optionListItems = dropDown.get(dlpUtil.OPTION);
							LinkedList<String> optionNameList = new LinkedList<>();
							if (optionListItems.isArray()) {

								optionListItems.forEach(optionList -> {
									Integer optionListId = optionList.get(dlpUtil.ID).asInt();
									idMap.put(optionListId, optionList);
									optionNameList.add(optionList.get(dlpUtil.TEXT).textValue());

								});

							} else {
								Integer optionListId = optionListItems.get(dlpUtil.ID).asInt();
								idMap.put(optionListId, optionListItems);
								optionNameList.add(optionListItems.get(dlpUtil.TEXT).textValue());

							}
							
							if (dropDown.get("source-name") != null && dropDown.get("row-field") != null) {
								String tableName = dropDown.get("source-name").textValue();
								String columnName = dropDown.get("row-field").textValue();
								String result = commonUtil.getCounterPartyName(tableName, columnName, uniqueIdentifier);
								inputTypes.setCounterparty(result);
							}
							
							inputTypes.setFieldValues(optionNameList);
							inputTypes.setSeqNumber(Integer.parseInt(seqNumber));
							sequenceMap.put(Integer.parseInt(seqNumber), inputTypes);
							inputList.add(inputTypes);

						}
					});

				if (textList != null) {
					if (textList.isArray())
						textList.forEach(text -> {

							Integer textId = text.get(dlpUtil.ID).asInt();
							idMap.put(textId, text);

							JsonNode visibilityType = text.get(dlpUtil.VISIBILITY_TYPE);
							if (visibilityType == null || visibilityType.asBoolean()) {
								InputTypes inputTypes = new InputTypes();
								inputTypes.setFieldName(text.get(dlpUtil.LABLE).textValue());

								inputTypes.setDataKey(text.get(dlpUtil.DATA_KEY).textValue());

								if (text.get("source-name") != null && text.get("row-field") != null) {
									String tableName = text.get("source-name").textValue();
									String columnName = text.get("row-field").textValue();
									String result = commonUtil.getCounterPartyName(tableName, columnName,
											uniqueIdentifier);
									inputTypes.setCounterparty(result);
								}

								if (text.get("max-length") != null) {
									String maxLength = text.get("max-length").textValue();
									inputTypes.setMaxLength(Integer.parseInt(maxLength));

								}

								inputTypes.setFieldType(dlpUtil.TEXT);
								inputTypes.setMandatory(text.get(dlpUtil.MANDATORY).asBoolean());
								String seqNumber = text.get(dlpUtil.SEQUENCE_NUMBER).asText();
								inputTypes.setSeqNumber(Integer.parseInt(seqNumber));
								sequenceMap.put(Integer.parseInt(seqNumber), inputTypes);
								inputList.add(inputTypes);
							}
						});

					else {

						Integer textId = textList.get(dlpUtil.ID).asInt();
						idMap.put(textId, textList);

						JsonNode visibilityType = textList.get(dlpUtil.VISIBILITY_TYPE);
						if (visibilityType == null || visibilityType.asBoolean()) {
							InputTypes inputTypes = new InputTypes();
							inputTypes.setFieldName(textList.get(dlpUtil.LABLE).textValue());

							inputTypes.setDataKey(textList.get(dlpUtil.DATA_KEY).textValue());

							if (textList.get("source-name") != null && textList.get("row-field") != null) {
								String tableName = textList.get("source-name").textValue();
								String columnName = textList.get("row-field").textValue();
								String result = commonUtil.getCounterPartyName(tableName, columnName, uniqueIdentifier);
								inputTypes.setCounterparty(result);
							}

							if (textList.get("max-length") != null) {
								String maxLength = textList.get("max-length").textValue();
								inputTypes.setMaxLength(Integer.parseInt(maxLength));

							}

							inputTypes.setFieldType(dlpUtil.TEXT);
							String seqNumber = textList.get(dlpUtil.SEQUENCE_NUMBER).asText();
							inputTypes.setSeqNumber(Integer.parseInt(seqNumber));
							sequenceMap.put(Integer.parseInt(seqNumber), inputTypes);
							inputList.add(inputTypes);
						}
					}
				}
				if (labelList != null) {
					if (labelList.isArray())

						labelList.forEach(lable -> {
							Integer lableId = lable.get(dlpUtil.ID).asInt();
							idMap.put(lableId, lable);

							JsonNode visibilityType = lable.get(dlpUtil.VISIBILITY_TYPE);
							if (visibilityType == null || visibilityType.asBoolean()) {
								InputTypes inputTypes = new InputTypes();
								inputTypes.setFieldName(lable.get(dlpUtil.LABLE).textValue());

								if (lable.get(dlpUtil.DATA_KEY) != null) {
									inputTypes.setDataKey(lable.get(dlpUtil.DATA_KEY).textValue());
								}

								inputTypes.setFieldType(dlpUtil.LABLE);
								if (lable.get(dlpUtil.SEQUENCE_NUMBER) != null) {
									int seqNumber = lable.get(dlpUtil.SEQUENCE_NUMBER).asInt();
									inputTypes.setSeqNumber(seqNumber);
									sequenceMap.put(seqNumber, inputTypes);
									inputList.add(inputTypes);
								} else {
									int seqNumber = 10 + random.nextInt(80);
									inputTypes.setSeqNumber(seqNumber);
									sequenceMap.put(seqNumber, inputTypes);
									inputList.add(inputTypes);
								}

							}
						});

					else {
						Integer lableId = labelList.get(dlpUtil.ID).asInt();
						idMap.put(lableId, labelList);

						JsonNode visibilityType = labelList.get(dlpUtil.VISIBILITY_TYPE);
						if (visibilityType == null || visibilityType.asBoolean()) {
							InputTypes inputTypes = new InputTypes();
							inputTypes.setFieldName(labelList.get(dlpUtil.LABLE).textValue());
							inputTypes.setFieldType(dlpUtil.LABLE);

							if (labelList.get(dlpUtil.DATA_KEY) != null) {
								inputTypes.setDataKey(labelList.get(dlpUtil.DATA_KEY).textValue());
							}

							if (labelList.get(dlpUtil.SEQUENCE_NUMBER) != null) {
								int seqNumber = labelList.get(dlpUtil.SEQUENCE_NUMBER).asInt();
								inputTypes.setSeqNumber(seqNumber);
								sequenceMap.put(seqNumber, inputTypes);
								inputList.add(inputTypes);
							} else {
								int seqNumber = 10 + random.nextInt(80);
								inputTypes.setSeqNumber(seqNumber);
								sequenceMap.put(seqNumber, inputTypes);
								inputList.add(inputTypes);
							}

						}
					}
				}
				if (numericList != null) {
					if (numericList.isArray())

						numericList.forEach(numeric -> {
							Integer numericId = numeric.get(dlpUtil.ID).asInt();
							idMap.put(numericId, numeric);

							JsonNode visibilityType = numeric.get(dlpUtil.VISIBILITY_TYPE);
							if (visibilityType == null || visibilityType.asBoolean()) {
								InputTypes inputTypes = new InputTypes();
								inputTypes.setFieldName(numeric.get(dlpUtil.LABLE).textValue());

								inputTypes.setDataKey(numeric.get(dlpUtil.DATA_KEY).textValue());

								if (numeric.get("source-name") != null && numeric.get("row-field") != null) {
									String tableName = numeric.get("source-name").textValue();
									String columnName = numeric.get("row-field").textValue();
									String result = commonUtil.getCounterPartyName(tableName, columnName,
											uniqueIdentifier);
									inputTypes.setCounterparty(result);
								}

								if (numeric.get("max-value") != null) {
									String maxLength = numeric.get("max-value").textValue();
									inputTypes.setMaxLength(Integer.parseInt(maxLength));

								}

								inputTypes.setFieldType(dlpUtil.NUMERIC);
								inputTypes.setMandatory(numeric.get(dlpUtil.MANDATORY).asBoolean());
								String seqNumber = numeric.get(dlpUtil.SEQUENCE_NUMBER).asText();
								inputTypes.setSeqNumber(Integer.parseInt(seqNumber));
								sequenceMap.put(Integer.parseInt(seqNumber), inputTypes);
								inputList.add(inputTypes);

							}
						});
					else {
						Integer numericId = numericList.get(dlpUtil.ID).asInt();
						idMap.put(numericId, numericList);

						JsonNode visibilityType = numericList.get(dlpUtil.VISIBILITY_TYPE);
						if (visibilityType == null || visibilityType.asBoolean()) {
							InputTypes inputTypes = new InputTypes();
							inputTypes.setFieldName(numericList.get(dlpUtil.LABLE).textValue());

							inputTypes.setDataKey(numericList.get(dlpUtil.DATA_KEY).textValue());

							if (numericList.get("source-name") != null && numericList.get("row-field") != null) {
								String tableName = numericList.get("source-name").textValue();
								String columnName = numericList.get("row-field").textValue();
								String result = commonUtil.getCounterPartyName(tableName, columnName, uniqueIdentifier);
								inputTypes.setCounterparty(result);
							}

							if (numericList.get("max-value") != null) {
								String maxLength = numericList.get("max-value").textValue();
								inputTypes.setMaxLength(Integer.parseInt(maxLength));

							}

							inputTypes.setFieldType(dlpUtil.NUMERIC);
							String seqNumber = numericList.get(dlpUtil.SEQUENCE_NUMBER).asText();
							inputTypes.setSeqNumber(Integer.parseInt(seqNumber));
							sequenceMap.put(Integer.parseInt(seqNumber), inputTypes);
							inputList.add(inputTypes);
						}
					}

					List<Integer> listInteger = new ArrayList<>();
					listInteger.addAll(sequenceMap.keySet());// ;.sort(sequenceMap.keySet())
					Collections.sort(listInteger);

					listInteger.forEach(seqData -> {
						inputListOrdered.add(sequenceMap.get(seqData));
					});

					sectionData.setSeqNumber(Integer.parseInt(sectionSeqNumber));
					sectionData.setTitle(title.textValue());
					sectionData.setInputType(inputListOrdered);
					sectionData.setType(dlpUtil.ENTRY_FORM);
					entryFormList.add(sectionData);

				}
			});
		}
		// });

		return entryFormList;

	}

	public List<Section> getDynamicColumnGrid(JsonNode mSection, String uniqueIdentifier) {

		JsonNode dynamicColumnGridList = mSection.get(dlpUtil.DYNAMIC_GRID);
		List<Section> dynamicGridList = new ArrayList<>();

		if (dynamicColumnGridList != null && !dynamicColumnGridList.isArray()) {

			JsonNode dynamicColumnGrid = dynamicColumnGridList;
			Integer dynamicColumnGridId = dynamicColumnGrid.get(dlpUtil.ID).asInt();
			idMap.put(dynamicColumnGridId, dynamicColumnGrid);

			Section sectionData = new Section();
			// JsonNode section; // = sectionList.get(i);
			LinkedHashMap<Integer, InputTypes> sequenceMap = new LinkedHashMap<>();
			JsonNode title = dynamicColumnGrid.get(dlpUtil.DATA_KEY);
			JsonNode dropDownList = dynamicColumnGrid.get(dlpUtil.DROPDOWN);
			JsonNode dateType = dynamicColumnGrid.get(dlpUtil.DATE);
			JsonNode textList = dynamicColumnGrid.get(dlpUtil.TEXT);
			JsonNode labelList = dynamicColumnGrid.get(dlpUtil.LABLE);
			JsonNode numericList = dynamicColumnGrid.get(dlpUtil.NUMERIC);
			JsonNode systemDropdownList = dynamicColumnGrid.get(dlpUtil.SYSTEM_DROPDOWN);
			JsonNode textAreaList = dynamicColumnGrid.get(dlpUtil.TEXT_AREA);
			JsonNode radioList = dynamicColumnGrid.get(dlpUtil.RADIO);
			String sectionSeqNumber = dynamicColumnGrid.get(dlpUtil.SEQUENCE_NUMBER).textValue();
			LinkedList<InputTypes> inputList = new LinkedList<>();
			LinkedList<InputTypes> inputListOrdered = new LinkedList<>();

			if (radioList != null && !radioList.isArray()) {

				Integer radioListId = radioList.get(dlpUtil.ID).asInt();
				idMap.put(radioListId, radioList);

				JsonNode visibilityType = radioList.get(dlpUtil.VISIBILITY_TYPE);
				if (visibilityType == null || visibilityType.asBoolean()) {
					JsonNode radio = radioList;

					InputTypes inputTypes = new InputTypes();
					inputTypes.setFieldName(radio.get(dlpUtil.LABLE).textValue());
					inputTypes.setDataKey(radio.get(dlpUtil.DATA_KEY).textValue());
					inputTypes.setFieldType(dlpUtil.RADIO);
					inputTypes.setMandatory(radio.get(dlpUtil.MANDATORY).asBoolean());
					String seqNumber = radio.get(dlpUtil.SEQUENCE_NUMBER).textValue();
					JsonNode optionListItems = radio.get(dlpUtil.OPTION);
					LinkedList<String> optionNameList = new LinkedList<>();
					if (optionListItems.isArray()) {

						optionListItems.forEach(optionList -> {
							optionNameList.add(optionList.get(dlpUtil.TEXT).textValue());
							Integer radioOptionId = optionList.get(dlpUtil.ID).asInt();
							idMap.put(radioOptionId, optionList);
						});

					} else {
						optionNameList.add(optionListItems.get(dlpUtil.TEXT).textValue());
						Integer radioOptionId = optionListItems.get(dlpUtil.ID).asInt();
						idMap.put(radioOptionId, optionListItems);
					}
					inputTypes.setFieldValues(optionNameList);
					inputTypes.setSeqNumber(Integer.parseInt(seqNumber));
					sequenceMap.put(Integer.parseInt(seqNumber), inputTypes);
					inputList.add(inputTypes);
				}
			}

			if (radioList != null && radioList.isArray()) {
				radioList.forEach(radio -> {
					Integer radioId = radio.get(dlpUtil.ID).asInt();
					idMap.put(radioId, radio);

					JsonNode visibilityType = radio.get(dlpUtil.VISIBILITY_TYPE);
					if (visibilityType == null || visibilityType.asBoolean()) {
						InputTypes inputTypes = new InputTypes();
						inputTypes.setFieldName(radio.get(dlpUtil.LABLE).textValue());
						inputTypes.setDataKey(radio.get(dlpUtil.DATA_KEY).textValue());
						inputTypes.setFieldType(dlpUtil.RADIO);
						inputTypes.setMandatory(radio.get(dlpUtil.MANDATORY).asBoolean());
						String seqNumber = radio.get(dlpUtil.SEQUENCE_NUMBER).textValue();
						JsonNode optionListItems = radio.get(dlpUtil.OPTION);
						LinkedList<String> optionNameList = new LinkedList<>();
						if (optionListItems.isArray()) {

							optionListItems.forEach(optionList -> {
								optionNameList.add(optionList.get(dlpUtil.TEXT).textValue());
								Integer radioOptionId = optionList.get(dlpUtil.ID).asInt();
								idMap.put(radioOptionId, optionList);

							});

						} else {
							optionNameList.add(optionListItems.get(dlpUtil.TEXT).textValue());
							Integer radioOptionId = optionListItems.get(dlpUtil.ID).asInt();
							idMap.put(radioOptionId, optionListItems);

						}
						inputTypes.setFieldValues(optionNameList);
						inputTypes.setSeqNumber(Integer.parseInt(seqNumber));
						sequenceMap.put(Integer.parseInt(seqNumber), inputTypes);
						inputList.add(inputTypes);

					}
				});
			}

			if (textAreaList != null) {

				if (!textAreaList.isArray()) {

					JsonNode textArea = textAreaList;
					Integer textAreaId = textArea.get(dlpUtil.ID).asInt();
					idMap.put(textAreaId, textArea);

					JsonNode visibilityType = textArea.get(dlpUtil.VISIBILITY_TYPE);
					if (visibilityType == null || visibilityType.asBoolean()) {
						InputTypes inputTypes = new InputTypes();
						// System.out.println("lable::::::" + textArea.get(dlpUtil.LABLE).toString());
						inputTypes.setFieldName(textArea.get(dlpUtil.LABLE).textValue());

						inputTypes.setDataKey(textArea.get(dlpUtil.DATA_KEY).textValue());

						inputTypes.setFieldType(dlpUtil.TEXT_AREA);
						inputTypes.setMandatory(textArea.get(dlpUtil.MANDATORY).asBoolean());
						String seqNumber = textArea.get(dlpUtil.SEQUENCE_NUMBER).textValue();
						inputTypes.setSeqNumber(Integer.parseInt(seqNumber));
						sequenceMap.put(Integer.parseInt(seqNumber), inputTypes);
						inputList.add(inputTypes);
					}
				}

				else {
					textAreaList.forEach(textArea -> {

						Integer textAreaId = textArea.get(dlpUtil.ID).asInt();
						idMap.put(textAreaId, textArea);

						JsonNode visibilityType = textArea.get(dlpUtil.VISIBILITY_TYPE);
						if (visibilityType == null || visibilityType.asBoolean()) {
							InputTypes inputTypes = new InputTypes();
							// System.out.println("lable::::::" + textArea.get(dlpUtil.LABLE).toString());
							inputTypes.setFieldName(textArea.get(dlpUtil.LABLE).textValue());

							inputTypes.setDataKey(textArea.get(dlpUtil.DATA_KEY).textValue());

							inputTypes.setFieldType(dlpUtil.TEXT_AREA);
							inputTypes.setMandatory(textArea.get(dlpUtil.MANDATORY).asBoolean());
							String seqNumber = textArea.get(dlpUtil.SEQUENCE_NUMBER).textValue();
							inputTypes.setSeqNumber(Integer.parseInt(seqNumber));
							sequenceMap.put(Integer.parseInt(seqNumber), inputTypes);
							inputList.add(inputTypes);

						}
					});
				}
			}

			if (systemDropdownList != null) {

				if (!systemDropdownList.isArray()) {

					Integer systemDropdownListId = systemDropdownList.get(dlpUtil.ID).asInt();
					idMap.put(systemDropdownListId, systemDropdownList);

					JsonNode visibilityType = systemDropdownList.get(dlpUtil.VISIBILITY_TYPE);
					if (visibilityType == null || visibilityType.asBoolean()) {
						JsonNode systemDropdown = systemDropdownList;

						InputTypes inputTypes = new InputTypes();
						SystemDropdown system = new SystemDropdown();
						inputTypes.setFieldName(systemDropdown.get(dlpUtil.LABLE).textValue());

						inputTypes.setDataKey(systemDropdown.get(dlpUtil.DATA_KEY).textValue());

						if (systemDropdown.get("source-name") != null && systemDropdown.get("row-field") != null) {
							String tableName = systemDropdown.get("source-name").textValue();
							String columnName = systemDropdown.get("row-field").textValue();
							String result = commonUtil.getCounterPartyName(tableName, columnName, uniqueIdentifier);
							inputTypes.setCounterparty(result);
						}

						inputTypes.setFieldType(dlpUtil.SYSTEM_DROPDOWN);
						inputTypes.setMandatory(systemDropdown.get(dlpUtil.MANDATORY).asBoolean());
						String seqNumber = systemDropdown.get(dlpUtil.SEQUENCE_NUMBER).textValue();

						if (systemDropdown.get(dlpUtil.SOURCE) != null) {
							String source = systemDropdown.get(dlpUtil.SOURCE).textValue();
							List<?> systemList = commonUtil.getSystemDropDown(source);
							if (systemList != null) {
								inputTypes.setSystemDropDownList(systemList);
							} else {

								List<EntityDto> configList = commonUtil.getConfigList(source);
								inputTypes.setSystemDropDownList(configList);
							}

						}

						inputTypes.setSeqNumber(Integer.parseInt(seqNumber));
						sequenceMap.put(Integer.parseInt(seqNumber), inputTypes);
						inputList.add(inputTypes);
					}
				}

				else {
					systemDropdownList.forEach(systemDropdown -> {

						Integer systemDropdownId = systemDropdown.get(dlpUtil.ID).asInt();
						idMap.put(systemDropdownId, systemDropdown);

						JsonNode visibilityType = systemDropdown.get(dlpUtil.VISIBILITY_TYPE);
						if (visibilityType == null || visibilityType.asBoolean()) {
							InputTypes inputTypes = new InputTypes();
							SystemDropdown system = new SystemDropdown();
							inputTypes.setFieldName(systemDropdown.get(dlpUtil.LABLE).textValue());

							inputTypes.setDataKey(systemDropdown.get(dlpUtil.DATA_KEY).textValue());

							if (systemDropdown.get("source-name") != null && systemDropdown.get("row-field") != null) {
								String tableName = systemDropdown.get("source-name").textValue();
								String columnName = systemDropdown.get("row-field").textValue();
								String result = commonUtil.getCounterPartyName(tableName, columnName, uniqueIdentifier);
								inputTypes.setCounterparty(result);
							}

							if (systemDropdown.get(dlpUtil.SOURCE) != null) {
								String source = systemDropdown.get(dlpUtil.SOURCE).textValue();
								List<?> systemList = commonUtil.getSystemDropDown(source);
								if (systemList != null) {
									inputTypes.setSystemDropDownList(systemList);
								} else {

									List<EntityDto> configList = commonUtil.getConfigList(source);
									inputTypes.setSystemDropDownList(configList);
								}

							}

							inputTypes.setFieldType(dlpUtil.SYSTEM_DROPDOWN);
							inputTypes.setMandatory(systemDropdown.get(dlpUtil.MANDATORY).asBoolean());
							String seqNumber = systemDropdown.get(dlpUtil.SEQUENCE_NUMBER).textValue();
							inputTypes.setSeqNumber(Integer.parseInt(seqNumber));
							sequenceMap.put(Integer.parseInt(seqNumber), inputTypes);
							inputList.add(inputTypes);
						}
					});
				}
			}
			if (dropDownList != null && !dropDownList.isArray()) {

				JsonNode dropDown = dropDownList;

				Integer dropDownId = dropDown.get(dlpUtil.ID).asInt();
				idMap.put(dropDownId, dropDown);

				JsonNode visibilityType = dropDown.get(dlpUtil.VISIBILITY_TYPE);
				if (visibilityType == null || visibilityType.asBoolean()) {
					InputTypes inputTypes = new InputTypes();
					// System.out.println("lable::::::" + dropDown.get(dlpUtil.LABLE).toString());
					inputTypes.setFieldName(dropDown.get(dlpUtil.LABLE).textValue());
					inputTypes.setDataKey(dropDown.get(dlpUtil.DATA_KEY).textValue());
					inputTypes.setFieldType(dlpUtil.DROPDOWN);
					inputTypes.setMandatory(dropDown.get(dlpUtil.MANDATORY).asBoolean());
					String seqNumber = dropDown.get(dlpUtil.SEQUENCE_NUMBER).textValue();
					JsonNode optionListItems = dropDown.get(dlpUtil.OPTION);
					LinkedList<String> optionNameList = new LinkedList<>();
					if (optionListItems.isArray()) {

						optionListItems.forEach(optionList -> {
							Integer optionListId = optionList.get(dlpUtil.ID).asInt();
							idMap.put(optionListId, optionList);
							optionNameList.add(optionList.get(dlpUtil.TEXT).textValue());
						});

					} else {
						Integer optionListId = optionListItems.get(dlpUtil.ID).asInt();
						idMap.put(optionListId, optionListItems);
						optionNameList.add(optionListItems.get(dlpUtil.TEXT).textValue());
					}
					
					if (dropDown.get("source-name") != null && dropDown.get("row-field") != null) {
						String tableName = dropDown.get("source-name").textValue();
						String columnName = dropDown.get("row-field").textValue();
						String result = commonUtil.getCounterPartyName(tableName, columnName, uniqueIdentifier);
						inputTypes.setCounterparty(result);
					}
					
					inputTypes.setFieldValues(optionNameList);
					inputTypes.setSeqNumber(Integer.parseInt(seqNumber));
					sequenceMap.put(Integer.parseInt(seqNumber), inputTypes);
					inputList.add(inputTypes);

				}
			}

			if (dropDownList != null && dropDownList.isArray())
				dropDownList.forEach(dropDown -> {

					Integer dropDownId = dropDown.get(dlpUtil.ID).asInt();
					idMap.put(dropDownId, dropDown);

					JsonNode visibilityType = dropDown.get(dlpUtil.VISIBILITY_TYPE);
					if (visibilityType == null || visibilityType.asBoolean()) {
						InputTypes inputTypes = new InputTypes();
						// System.out.println("lable::::::" + dropDown.get(dlpUtil.LABLE).toString());
						inputTypes.setFieldName(dropDown.get(dlpUtil.LABLE).textValue());
						inputTypes.setDataKey(dropDown.get(dlpUtil.DATA_KEY).textValue());
						inputTypes.setFieldType(dlpUtil.DROPDOWN);
						inputTypes.setMandatory(dropDown.get(dlpUtil.MANDATORY).asBoolean());
						String seqNumber = dropDown.get(dlpUtil.SEQUENCE_NUMBER).textValue();
						JsonNode optionListItems = dropDown.get(dlpUtil.OPTION);
						LinkedList<String> optionNameList = new LinkedList<>();
						if (optionListItems.isArray()) {

							optionListItems.forEach(optionList -> {
								Integer optionListId = optionList.get(dlpUtil.ID).asInt();
								idMap.put(optionListId, optionList);
								optionNameList.add(optionList.get(dlpUtil.TEXT).textValue());
							});

						} else {
							Integer optionListId = optionListItems.get(dlpUtil.ID).asInt();
							idMap.put(optionListId, optionListItems);
							optionNameList.add(optionListItems.get(dlpUtil.TEXT).textValue());
						}
						
						if (dropDown.get("source-name") != null && dropDown.get("row-field") != null) {
							String tableName = dropDown.get("source-name").textValue();
							String columnName = dropDown.get("row-field").textValue();
							String result = commonUtil.getCounterPartyName(tableName, columnName, uniqueIdentifier);
							inputTypes.setCounterparty(result);
						}
						
						inputTypes.setFieldValues(optionNameList);
						inputTypes.setSeqNumber(Integer.parseInt(seqNumber));
						sequenceMap.put(Integer.parseInt(seqNumber), inputTypes);
						inputList.add(inputTypes);

					}
				});
			if (dateType != null) {
				if (!dateType.isArray()) {

					Integer dateTypeId = dateType.get(dlpUtil.ID).asInt();
					idMap.put(dateTypeId, dateType);

					JsonNode visibilityType = dateType.get(dlpUtil.VISIBILITY_TYPE);
					if (visibilityType == null || visibilityType.asBoolean()) {
						InputTypes inputTypes = new InputTypes();
						String seqNumber = dateType.get(dlpUtil.SEQUENCE_NUMBER).asText();
						inputTypes.setFieldName(dateType.get(dlpUtil.LABLE).textValue());

						if (dateType.get("source-name") != null && dateType.get("row-field") != null) {
							String tableName = dateType.get("source-name").textValue();
							String columnName = dateType.get("row-field").textValue();
							String result = commonUtil.getCounterPartyName(tableName, columnName, uniqueIdentifier);
							inputTypes.setCounterparty(result);
						}

						inputTypes.setDataKey(dateType.get(dlpUtil.DATA_KEY).textValue());
						inputTypes.setMandatory(dateType.get(dlpUtil.MANDATORY).asBoolean());

						inputTypes.setFieldType(dlpUtil.DATE);
						inputTypes.setSeqNumber(Integer.parseInt(seqNumber));
						sequenceMap.put(Integer.parseInt(seqNumber), inputTypes);
						inputList.add(inputTypes);
					}
				}
				if (dateType.isArray()) {
					dateType.forEach(date -> {
						Integer dateId = date.get(dlpUtil.ID).asInt();
						idMap.put(dateId, date);

						JsonNode visibilityType = date.get(dlpUtil.VISIBILITY_TYPE);
						if (visibilityType == null || visibilityType.asBoolean()) {
							InputTypes inputTypes = new InputTypes();
							String seqNumber = date.get(dlpUtil.SEQUENCE_NUMBER).asText();
							inputTypes.setFieldName(date.get(dlpUtil.LABLE).textValue());

							inputTypes.setDataKey(date.get(dlpUtil.DATA_KEY).textValue());

							if (date.get("source-name") != null && date.get("row-field") != null) {
								String tableName = date.get("source-name").textValue();
								String columnName = date.get("row-field").textValue();
								String result = commonUtil.getCounterPartyName(tableName, columnName, uniqueIdentifier);
								inputTypes.setCounterparty(result);
							}
							inputTypes.setMandatory(date.get(dlpUtil.MANDATORY).asBoolean());
							inputTypes.setFieldType(dlpUtil.DATE);
							inputTypes.setSeqNumber(Integer.parseInt(seqNumber));
							sequenceMap.put(Integer.parseInt(seqNumber), inputTypes);
							inputList.add(inputTypes);
						}
					});

				}
			}

			if (textList != null) {
				if (textList.isArray())
					textList.forEach(text -> {

						Integer textId = text.get(dlpUtil.ID).asInt();
						idMap.put(textId, text);

						JsonNode visibilityType = text.get(dlpUtil.VISIBILITY_TYPE);
						if (visibilityType == null || visibilityType.asBoolean()) {
							InputTypes inputTypes = new InputTypes();
							inputTypes.setFieldName(text.get(dlpUtil.LABLE).textValue());

							inputTypes.setDataKey(text.get(dlpUtil.DATA_KEY).textValue());

							if (text.get("source-name") != null && text.get("row-field") != null) {
								String tableName = text.get("source-name").textValue();
								String columnName = text.get("row-field").textValue();
								String result = commonUtil.getCounterPartyName(tableName, columnName, uniqueIdentifier);
								inputTypes.setCounterparty(result);
							}

							if (text.get("max-length") != null) {
								String maxLength = text.get("max-length").textValue();
								inputTypes.setMaxLength(Integer.parseInt(maxLength));

							}

							inputTypes.setFieldType(dlpUtil.TEXT);
							inputTypes.setMandatory(text.get(dlpUtil.MANDATORY).asBoolean());
							String seqNumber = text.get(dlpUtil.SEQUENCE_NUMBER).asText();
							inputTypes.setSeqNumber(Integer.parseInt(seqNumber));
							sequenceMap.put(Integer.parseInt(seqNumber), inputTypes);
							inputList.add(inputTypes);
						}
					});

				else {
					Integer textListId = textList.get(dlpUtil.ID).asInt();
					idMap.put(textListId, textList);

					JsonNode visibilityType = textList.get(dlpUtil.VISIBILITY_TYPE);
					if (visibilityType == null || visibilityType.asBoolean()) {
						InputTypes inputTypes = new InputTypes();
						inputTypes.setFieldName(textList.get(dlpUtil.LABLE).textValue());

						inputTypes.setDataKey(textList.get(dlpUtil.DATA_KEY).textValue());

						if (textList.get("source-name") != null && textList.get("row-field") != null) {
							String tableName = textList.get("source-name").textValue();
							String columnName = textList.get("row-field").textValue();
							String result = commonUtil.getCounterPartyName(tableName, columnName, uniqueIdentifier);
							inputTypes.setCounterparty(result);
						}

						if (textList.get("max-length") != null) {
							String maxLength = textList.get("max-length").textValue();
							inputTypes.setMaxLength(Integer.parseInt(maxLength));

						}

						inputTypes.setFieldType(dlpUtil.TEXT);
						String seqNumber = textList.get(dlpUtil.SEQUENCE_NUMBER).asText();
						inputTypes.setSeqNumber(Integer.parseInt(seqNumber));
						sequenceMap.put(Integer.parseInt(seqNumber), inputTypes);
						inputList.add(inputTypes);
					}
				}
			}
			if (labelList != null) {
				if (labelList.isArray())

					labelList.forEach(lable -> {

						Integer lableId = lable.get(dlpUtil.ID).asInt();
						idMap.put(lableId, lable);

						JsonNode visibilityType = lable.get(dlpUtil.VISIBILITY_TYPE);
						if (visibilityType == null || visibilityType.asBoolean()) {
							InputTypes inputTypes = new InputTypes();
							inputTypes.setFieldName(lable.get(dlpUtil.LABLE).textValue());
							inputTypes.setFieldType(dlpUtil.LABLE);
							if (lable.get(dlpUtil.SEQUENCE_NUMBER) != null) {
								int seqNumber = lable.get(dlpUtil.SEQUENCE_NUMBER).asInt();
								inputTypes.setSeqNumber(seqNumber);
								sequenceMap.put(seqNumber, inputTypes);
								inputList.add(inputTypes);
							} else {
								int seqNumber = 10 + random.nextInt(80);
								inputTypes.setSeqNumber(seqNumber);
								sequenceMap.put(seqNumber, inputTypes);
								inputList.add(inputTypes);
							}

						}
					});

				else {

					Integer labelListId = labelList.get(dlpUtil.ID).asInt();
					idMap.put(labelListId, labelList);

					JsonNode visibilityType = labelList.get(dlpUtil.VISIBILITY_TYPE);
					if (visibilityType == null || visibilityType.asBoolean()) {
						InputTypes inputTypes = new InputTypes();
						inputTypes.setFieldName(labelList.get(dlpUtil.LABLE).textValue());
						inputTypes.setFieldType(dlpUtil.LABLE);
						if (labelList.get(dlpUtil.SEQUENCE_NUMBER) != null) {
							int seqNumber = labelList.get(dlpUtil.SEQUENCE_NUMBER).asInt();
							inputTypes.setSeqNumber(seqNumber);
							sequenceMap.put(seqNumber, inputTypes);
							inputList.add(inputTypes);
						} else {
							int seqNumber = 10 + random.nextInt(80);
							inputTypes.setSeqNumber(seqNumber);
							sequenceMap.put(seqNumber, inputTypes);
							inputList.add(inputTypes);
						}

					}
				}
			}
			if (numericList != null) {
				if (numericList.isArray())

					numericList.forEach(numeric -> {

						Integer numericId = numeric.get(dlpUtil.ID).asInt();
						idMap.put(numericId, numeric);

						JsonNode visibilityType = numeric.get(dlpUtil.VISIBILITY_TYPE);
						if (visibilityType == null || visibilityType.asBoolean()) {
							InputTypes inputTypes = new InputTypes();
							inputTypes.setFieldName(numeric.get(dlpUtil.LABLE).textValue());

							inputTypes.setDataKey(numeric.get(dlpUtil.DATA_KEY).textValue());

							if (numeric.get("source-name") != null && numeric.get("row-field") != null) {
								String tableName = numeric.get("source-name").textValue();
								String columnName = numeric.get("row-field").textValue();
								String result = commonUtil.getCounterPartyName(tableName, columnName, uniqueIdentifier);
								inputTypes.setCounterparty(result);
							}

							if (numeric.get("max-value") != null) {
								String maxLength = numeric.get("max-value").textValue();
								inputTypes.setMaxLength(Integer.parseInt(maxLength));

							}

							inputTypes.setFieldType(dlpUtil.NUMERIC);
							inputTypes.setMandatory(numeric.get(dlpUtil.MANDATORY).asBoolean());
							String seqNumber = numeric.get(dlpUtil.SEQUENCE_NUMBER).asText();
							inputTypes.setSeqNumber(Integer.parseInt(seqNumber));
							sequenceMap.put(Integer.parseInt(seqNumber), inputTypes);
							inputList.add(inputTypes);

						}
					});
				else {
					Integer numericListId = numericList.get(dlpUtil.ID).asInt();
					idMap.put(numericListId, numericList);

					JsonNode visibilityType = numericList.get(dlpUtil.VISIBILITY_TYPE);
					if (visibilityType == null || visibilityType.asBoolean()) {
						InputTypes inputTypes = new InputTypes();
						inputTypes.setFieldName(numericList.get(dlpUtil.LABLE).textValue());

						inputTypes.setDataKey(numericList.get(dlpUtil.DATA_KEY).textValue());

						if (numericList.get("source-name") != null && numericList.get("row-field") != null) {
							String tableName = numericList.get("source-name").textValue();
							String columnName = numericList.get("row-field").textValue();
							String result = commonUtil.getCounterPartyName(tableName, columnName, uniqueIdentifier);
							inputTypes.setCounterparty(result);
						}

						if (numericList.get("max-value") != null) {
							String maxLength = numericList.get("max-value").textValue();
							inputTypes.setMaxLength(Integer.parseInt(maxLength));

						}

						inputTypes.setFieldType(dlpUtil.NUMERIC);
						String seqNumber = numericList.get(dlpUtil.SEQUENCE_NUMBER).asText();
						inputTypes.setSeqNumber(Integer.parseInt(seqNumber));
						sequenceMap.put(Integer.parseInt(seqNumber), inputTypes);
						inputList.add(inputTypes);
					}
				}

				List<Integer> listInteger = new ArrayList<>();
				listInteger.addAll(sequenceMap.keySet());// ;.sort(sequenceMap.keySet())
				Collections.sort(listInteger);

				listInteger.forEach(seqData -> {
					inputListOrdered.add(sequenceMap.get(seqData));
				});

				sectionData.setSeqNumber(Integer.parseInt(sectionSeqNumber));
				sectionData.setTitle(title.textValue());
				sectionData.setInputType(inputListOrdered);
				sectionData.setType(dlpUtil.DYNAMIC_GRID);
				dynamicGridList.add(sectionData);

			}
		}

		else if (dynamicColumnGridList != null && dynamicColumnGridList.isArray()) {

			dynamicColumnGridList.forEach(dynamicGrid -> {

				Integer dynamicGridId = dynamicGrid.get(dlpUtil.ID).asInt();
				idMap.put(dynamicGridId, dynamicGrid);

				Section sectionData = new Section();

				JsonNode title = dynamicGrid.get(dlpUtil.DATA_KEY);
				JsonNode dropDownList = dynamicGrid.get(dlpUtil.DROPDOWN);
				JsonNode dateType = dynamicGrid.get(dlpUtil.DATE);
				JsonNode textList = dynamicGrid.get(dlpUtil.TEXT);
				JsonNode labelList = dynamicGrid.get(dlpUtil.LABLE);
				JsonNode numericList = dynamicGrid.get(dlpUtil.NUMERIC);
				JsonNode systemDropdownList = dynamicGrid.get(dlpUtil.SYSTEM_DROPDOWN);
				JsonNode textAreaList = dynamicGrid.get(dlpUtil.TEXT_AREA);
				String sectionSeqNumber = dynamicGrid.get(dlpUtil.SEQUENCE_NUMBER).textValue();
				JsonNode radioList = dynamicGrid.get(dlpUtil.RADIO);
				LinkedHashMap<Integer, InputTypes> sequenceMap = new LinkedHashMap<>();
				LinkedList<InputTypes> inputList = new LinkedList<>();
				LinkedList<InputTypes> inputListOrdered = new LinkedList<>();

				if (radioList != null && !radioList.isArray()) {

					JsonNode radio = radioList;
					Integer radioId = radio.get(dlpUtil.ID).asInt();
					idMap.put(radioId, radio);

					JsonNode visibilityType = radio.get(dlpUtil.VISIBILITY_TYPE);
					if (visibilityType == null || visibilityType.asBoolean()) {
						InputTypes inputTypes = new InputTypes();
						inputTypes.setFieldName(radio.get(dlpUtil.LABLE).textValue());
						inputTypes.setDataKey(radio.get(dlpUtil.DATA_KEY).textValue());
						inputTypes.setFieldType(dlpUtil.RADIO);
						inputTypes.setMandatory(radio.get(dlpUtil.MANDATORY).asBoolean());
						String seqNumber = radio.get(dlpUtil.SEQUENCE_NUMBER).textValue();
						JsonNode optionListItems = radio.get(dlpUtil.OPTION);
						LinkedList<String> optionNameList = new LinkedList<>();
						if (optionListItems.isArray()) {

							optionListItems.forEach(optionList -> {
								Integer optionListId = optionList.get(dlpUtil.ID).asInt();
								idMap.put(optionListId, optionList);
								optionNameList.add(optionList.get(dlpUtil.TEXT).textValue());
							});

						} else {
							Integer optionListId = optionListItems.get(dlpUtil.ID).asInt();
							idMap.put(optionListId, optionListItems);
							optionNameList.add(optionListItems.get(dlpUtil.TEXT).textValue());
						}
						inputTypes.setFieldValues(optionNameList);
						inputTypes.setSeqNumber(Integer.parseInt(seqNumber));
						sequenceMap.put(Integer.parseInt(seqNumber), inputTypes);
						inputList.add(inputTypes);

					}
				}

				if (radioList != null && radioList.isArray()) {
					radioList.forEach(radio -> {

						Integer radioId = radio.get(dlpUtil.ID).asInt();
						idMap.put(radioId, radio);

						JsonNode visibilityType = radio.get(dlpUtil.VISIBILITY_TYPE);
						if (visibilityType == null || visibilityType.asBoolean()) {
							InputTypes inputTypes = new InputTypes();
							inputTypes.setFieldName(radio.get(dlpUtil.LABLE).textValue());
							inputTypes.setDataKey(radio.get(dlpUtil.DATA_KEY).textValue());
							inputTypes.setFieldType(dlpUtil.RADIO);
							inputTypes.setMandatory(radio.get(dlpUtil.MANDATORY).asBoolean());
							String seqNumber = radio.get(dlpUtil.SEQUENCE_NUMBER).textValue();
							JsonNode optionListItems = radio.get(dlpUtil.OPTION);
							LinkedList<String> optionNameList = new LinkedList<>();
							if (optionListItems.isArray()) {

								optionListItems.forEach(optionList -> {
									Integer optionListId = optionList.get(dlpUtil.ID).asInt();
									idMap.put(optionListId, optionList);
									optionNameList.add(optionList.get(dlpUtil.TEXT).textValue());
								});

							} else {
								Integer optionListId = optionListItems.get(dlpUtil.ID).asInt();
								idMap.put(optionListId, optionListItems);
								optionNameList.add(optionListItems.get(dlpUtil.TEXT).textValue());
							}
							inputTypes.setFieldValues(optionNameList);
							inputTypes.setSeqNumber(Integer.parseInt(seqNumber));
							sequenceMap.put(Integer.parseInt(seqNumber), inputTypes);
							inputList.add(inputTypes);

						}
					});
				}

				if (textAreaList != null) {

					if (!textAreaList.isArray()) {

						JsonNode textArea = textAreaList;
						Integer textAreaId = textArea.get(dlpUtil.ID).asInt();
						idMap.put(textAreaId, textArea);

						JsonNode visibilityType = textArea.get(dlpUtil.VISIBILITY_TYPE);
						if (visibilityType == null || visibilityType.asBoolean()) {
							InputTypes inputTypes = new InputTypes();
							// System.out.println("lable::::::" + textArea.get(dlpUtil.LABLE).toString());
							inputTypes.setFieldName(textArea.get(dlpUtil.LABLE).textValue());

							inputTypes.setDataKey(textArea.get(dlpUtil.DATA_KEY).textValue());

							inputTypes.setFieldType(dlpUtil.TEXT_AREA);
							inputTypes.setMandatory(textArea.get(dlpUtil.MANDATORY).asBoolean());
							String seqNumber = textArea.get(dlpUtil.SEQUENCE_NUMBER).textValue();
							inputTypes.setSeqNumber(Integer.parseInt(seqNumber));
							sequenceMap.put(Integer.parseInt(seqNumber), inputTypes);
							inputList.add(inputTypes);
						}
					} else {
						textAreaList.forEach(textArea -> {
							Integer textAreaId = textArea.get(dlpUtil.ID).asInt();
							idMap.put(textAreaId, textArea);

							JsonNode visibilityType = textArea.get(dlpUtil.VISIBILITY_TYPE);
							if (visibilityType == null || visibilityType.asBoolean()) {
								InputTypes inputTypes = new InputTypes();
								inputTypes.setFieldName(textArea.get(dlpUtil.LABLE).textValue());

								inputTypes.setDataKey(textArea.get(dlpUtil.DATA_KEY).textValue());

								inputTypes.setFieldType(dlpUtil.TEXT_AREA);
								inputTypes.setMandatory(textArea.get(dlpUtil.MANDATORY).asBoolean());
								String seqNumber = textArea.get(dlpUtil.SEQUENCE_NUMBER).textValue();
								inputTypes.setSeqNumber(Integer.parseInt(seqNumber));
								sequenceMap.put(Integer.parseInt(seqNumber), inputTypes);
								inputList.add(inputTypes);
							}
						});
					}
				}

				if (systemDropdownList != null) {

					if (!systemDropdownList.isArray()) {

						JsonNode systemDropdown = systemDropdownList;
						Integer systemDropdownId = systemDropdown.get(dlpUtil.ID).asInt();
						idMap.put(systemDropdownId, systemDropdown);

						JsonNode visibilityType = systemDropdown.get(dlpUtil.VISIBILITY_TYPE);
						if (visibilityType == null || visibilityType.asBoolean()) {
							InputTypes inputTypes = new InputTypes();
							SystemDropdown system = new SystemDropdown();
							inputTypes.setFieldName(systemDropdown.get(dlpUtil.LABLE).textValue());

							inputTypes.setDataKey(systemDropdown.get(dlpUtil.DATA_KEY).textValue());

							if (systemDropdown.get("source-name") != null && systemDropdown.get("row-field") != null) {
								String tableName = systemDropdown.get("source-name").textValue();
								String columnName = systemDropdown.get("row-field").textValue();
								String result = commonUtil.getCounterPartyName(tableName, columnName, uniqueIdentifier);
								inputTypes.setCounterparty(result);
							}

							if (systemDropdown.get(dlpUtil.SOURCE) != null) {
								String source = systemDropdown.get(dlpUtil.SOURCE).textValue();
								List<?> systemList = commonUtil.getSystemDropDown(source);
								if (systemList != null) {
									inputTypes.setSystemDropDownList(systemList);
								} else {

									List<EntityDto> configList = commonUtil.getConfigList(source);
									inputTypes.setSystemDropDownList(configList);
								}

							}

							inputTypes.setFieldType(dlpUtil.SYSTEM_DROPDOWN);
							inputTypes.setMandatory(systemDropdown.get(dlpUtil.MANDATORY).asBoolean());
							String seqNumber = systemDropdown.get(dlpUtil.SEQUENCE_NUMBER).textValue();
							inputTypes.setSeqNumber(Integer.parseInt(seqNumber));
							sequenceMap.put(Integer.parseInt(seqNumber), inputTypes);
							inputList.add(inputTypes);

						}
					}

					else {
						systemDropdownList.forEach(systemDropdown -> {

							Integer systemDropdownId = systemDropdown.get(dlpUtil.ID).asInt();
							idMap.put(systemDropdownId, systemDropdown);

							JsonNode visibilityType = systemDropdown.get(dlpUtil.VISIBILITY_TYPE);
							if (visibilityType == null || visibilityType.asBoolean()) {
								InputTypes inputTypes = new InputTypes();
								SystemDropdown system = new SystemDropdown();
								inputTypes.setFieldName(systemDropdown.get(dlpUtil.LABLE).textValue());

								inputTypes.setDataKey(systemDropdown.get(dlpUtil.DATA_KEY).textValue());

								if (systemDropdown.get("source-name") != null
										&& systemDropdown.get("row-field") != null) {
									String tableName = systemDropdown.get("source-name").textValue();
									String columnName = systemDropdown.get("row-field").textValue();
									String result = commonUtil.getCounterPartyName(tableName, columnName,
											uniqueIdentifier);
									inputTypes.setCounterparty(result);
								}

								if (systemDropdown.get(dlpUtil.SOURCE) != null) {
									String source = systemDropdown.get(dlpUtil.SOURCE).textValue();
									List<?> systemList = commonUtil.getSystemDropDown(source);
									if (systemList != null) {
										inputTypes.setSystemDropDownList(systemList);
									} else {

										List<EntityDto> configList = commonUtil.getConfigList(source);
										inputTypes.setSystemDropDownList(configList);
									}

								}
								inputTypes.setFieldType(dlpUtil.SYSTEM_DROPDOWN);
								inputTypes.setMandatory(systemDropdown.get(dlpUtil.MANDATORY).asBoolean());
								String seqNumber = systemDropdown.get(dlpUtil.SEQUENCE_NUMBER).textValue();
								inputTypes.setSeqNumber(Integer.parseInt(seqNumber));
								sequenceMap.put(Integer.parseInt(seqNumber), inputTypes);
								inputList.add(inputTypes);
							}
						});
					}
				}

				if (dropDownList != null && !dropDownList.isArray()) {

					JsonNode dropDown = dropDownList;
					Integer dropDownId = dropDown.get(dlpUtil.ID).asInt();
					idMap.put(dropDownId, dropDown);

					JsonNode visibilityType = dropDown.get(dlpUtil.VISIBILITY_TYPE);
					if (visibilityType == null || visibilityType.asBoolean()) {
						InputTypes inputTypes = new InputTypes();
						inputTypes.setFieldName(dropDown.get(dlpUtil.LABLE).textValue());
						inputTypes.setDataKey(dropDown.get(dlpUtil.DATA_KEY).textValue());
						inputTypes.setFieldType(dlpUtil.DROPDOWN);
						inputTypes.setMandatory(dropDown.get(dlpUtil.MANDATORY).asBoolean());
						String seqNumber = dropDown.get(dlpUtil.SEQUENCE_NUMBER).textValue();
						JsonNode optionListItems = dropDown.get(dlpUtil.OPTION);
						LinkedList<String> optionNameList = new LinkedList<>();
						if (optionListItems.isArray()) {

							optionListItems.forEach(optionList -> {
								Integer optionListId = optionList.get(dlpUtil.ID).asInt();
								idMap.put(optionListId, optionList);
								optionNameList.add(optionList.get(dlpUtil.TEXT).textValue());
							});

						} else {
							Integer optionListId = optionListItems.get(dlpUtil.ID).asInt();
							idMap.put(optionListId, optionListItems);
							optionNameList.add(optionListItems.get(dlpUtil.TEXT).textValue());
						}
						
						
						if (dropDown.get("source-name") != null && dropDown.get("row-field") != null) {
							String tableName = dropDown.get("source-name").textValue();
							String columnName = dropDown.get("row-field").textValue();
							String result = commonUtil.getCounterPartyName(tableName, columnName, uniqueIdentifier);
							inputTypes.setCounterparty(result);
						}
						
						inputTypes.setFieldValues(optionNameList);
						inputTypes.setSeqNumber(Integer.parseInt(seqNumber));
						sequenceMap.put(Integer.parseInt(seqNumber), inputTypes);
						inputList.add(inputTypes);

					}
				}

				if (dropDownList != null && dropDownList.isArray())
					dropDownList.forEach(dropDown -> {

						Integer dropDownId = dropDown.get(dlpUtil.ID).asInt();
						idMap.put(dropDownId, dropDown);

						JsonNode visibilityType = dropDown.get(dlpUtil.VISIBILITY_TYPE);
						if (visibilityType == null || visibilityType.asBoolean()) {
							InputTypes inputTypes = new InputTypes();
							inputTypes.setFieldName(dropDown.get(dlpUtil.LABLE).textValue());
							inputTypes.setDataKey(dropDown.get(dlpUtil.DATA_KEY).textValue());
							inputTypes.setFieldType(dlpUtil.DROPDOWN);
							inputTypes.setMandatory(dropDown.get(dlpUtil.MANDATORY).asBoolean());
							String seqNumber = dropDown.get(dlpUtil.SEQUENCE_NUMBER).textValue();
							JsonNode optionListItems = dropDown.get(dlpUtil.OPTION);
							LinkedList<String> optionNameList = new LinkedList<>();
							if (optionListItems.isArray()) {

								optionListItems.forEach(optionList -> {
									Integer optionListId = optionList.get(dlpUtil.ID).asInt();
									idMap.put(optionListId, optionList);
									optionNameList.add(optionList.get(dlpUtil.TEXT).textValue());
								});

							} else {
								Integer optionListId = optionListItems.get(dlpUtil.ID).asInt();
								idMap.put(optionListId, optionListItems);
								optionNameList.add(optionListItems.get(dlpUtil.TEXT).textValue());
							}
							
							if (dropDown.get("source-name") != null && dropDown.get("row-field") != null) {
								String tableName = dropDown.get("source-name").textValue();
								String columnName = dropDown.get("row-field").textValue();
								String result = commonUtil.getCounterPartyName(tableName, columnName, uniqueIdentifier);
								inputTypes.setCounterparty(result);
							}
							
							inputTypes.setFieldValues(optionNameList);
							inputTypes.setSeqNumber(Integer.parseInt(seqNumber));
							sequenceMap.put(Integer.parseInt(seqNumber), inputTypes);
							inputList.add(inputTypes);

						}
					});
				if (dateType != null) {
					if (!dateType.isArray()) {

						Integer dateTypeId = dateType.get(dlpUtil.ID).asInt();
						idMap.put(dateTypeId, dateType);

						JsonNode visibilityType = dateType.get(dlpUtil.VISIBILITY_TYPE);
						if (visibilityType == null || visibilityType.asBoolean()) {
							InputTypes inputTypes = new InputTypes();
							String seqNumber = dateType.get(dlpUtil.SEQUENCE_NUMBER).asText();
							inputTypes.setFieldName(dateType.get(dlpUtil.LABLE).textValue());

							inputTypes.setDataKey(dateType.get(dlpUtil.DATA_KEY).textValue());

							if (dateType.get("source-name") != null && dateType.get("row-field") != null) {
								String tableName = dateType.get("source-name").textValue();
								String columnName = dateType.get("row-field").textValue();
								String result = commonUtil.getCounterPartyName(tableName, columnName, uniqueIdentifier);
								inputTypes.setCounterparty(result);
							}
							inputTypes.setMandatory(dateType.get(dlpUtil.MANDATORY).asBoolean());
							inputTypes.setFieldType(dlpUtil.DATE);
							inputTypes.setSeqNumber(Integer.parseInt(seqNumber));
							sequenceMap.put(Integer.parseInt(seqNumber), inputTypes);
							inputList.add(inputTypes);
						}
					}

					if (dateType.isArray()) {
						dateType.forEach(date -> {
							Integer dateId = date.get(dlpUtil.ID).asInt();
							idMap.put(dateId, date);

							JsonNode visibilityType = date.get(dlpUtil.VISIBILITY_TYPE);
							if (visibilityType == null || visibilityType.asBoolean()) {
								InputTypes inputTypes = new InputTypes();
								String seqNumber = date.get(dlpUtil.SEQUENCE_NUMBER).asText();
								inputTypes.setFieldName(date.get(dlpUtil.LABLE).textValue());

								inputTypes.setDataKey(date.get(dlpUtil.DATA_KEY).textValue());

								if (date.get("source-name") != null && date.get("row-field") != null) {
									String tableName = date.get("source-name").textValue();
									String columnName = date.get("row-field").textValue();
									String result = commonUtil.getCounterPartyName(tableName, columnName,
											uniqueIdentifier);
									inputTypes.setCounterparty(result);
								}
								inputTypes.setMandatory(date.get(dlpUtil.MANDATORY).asBoolean());
								inputTypes.setFieldType(dlpUtil.DATE);
								inputTypes.setSeqNumber(Integer.parseInt(seqNumber));
								sequenceMap.put(Integer.parseInt(seqNumber), inputTypes);
								inputList.add(inputTypes);
							}
						});

					}
				}

				if (textList != null) {
					if (textList.isArray())
						textList.forEach(text -> {
							Integer textId = text.get(dlpUtil.ID).asInt();
							idMap.put(textId, text);

							JsonNode visibilityType = text.get(dlpUtil.VISIBILITY_TYPE);
							if (visibilityType == null || visibilityType.asBoolean()) {
								InputTypes inputTypes = new InputTypes();
								inputTypes.setFieldName(text.get(dlpUtil.LABLE).textValue());

								inputTypes.setDataKey(text.get(dlpUtil.DATA_KEY).textValue());

								if (text.get("source-name") != null && text.get("row-field") != null) {
									String tableName = text.get("source-name").textValue();
									String columnName = text.get("row-field").textValue();
									String result = commonUtil.getCounterPartyName(tableName, columnName,
											uniqueIdentifier);
									inputTypes.setCounterparty(result);
								}

								if (text.get("max-length") != null) {
									String maxLength = text.get("max-length").textValue();
									inputTypes.setMaxLength(Integer.parseInt(maxLength));

								}

								inputTypes.setFieldType(dlpUtil.TEXT);
								inputTypes.setMandatory(text.get(dlpUtil.MANDATORY).asBoolean());
								String seqNumber = text.get(dlpUtil.SEQUENCE_NUMBER).asText();
								inputTypes.setSeqNumber(Integer.parseInt(seqNumber));
								sequenceMap.put(Integer.parseInt(seqNumber), inputTypes);
								inputList.add(inputTypes);
							}
						});

					else {
						Integer textId = textList.get(dlpUtil.ID).asInt();
						idMap.put(textId, textList);

						JsonNode visibilityType = textList.get(dlpUtil.VISIBILITY_TYPE);
						if (visibilityType == null || visibilityType.asBoolean()) {
							InputTypes inputTypes = new InputTypes();
							inputTypes.setFieldName(textList.get(dlpUtil.LABLE).textValue());

							inputTypes.setDataKey(textList.get(dlpUtil.DATA_KEY).textValue());

							if (textList.get("source-name") != null && textList.get("row-field") != null) {
								String tableName = textList.get("source-name").textValue();
								String columnName = textList.get("row-field").textValue();
								String result = commonUtil.getCounterPartyName(tableName, columnName, uniqueIdentifier);
								inputTypes.setCounterparty(result);
							}

							if (textList.get("max-length") != null) {
								String maxLength = textList.get("max-length").textValue();
								inputTypes.setMaxLength(Integer.parseInt(maxLength));

							}

							inputTypes.setFieldType(dlpUtil.TEXT);
							String seqNumber = textList.get(dlpUtil.SEQUENCE_NUMBER).asText();
							inputTypes.setSeqNumber(Integer.parseInt(seqNumber));
							sequenceMap.put(Integer.parseInt(seqNumber), inputTypes);
							inputList.add(inputTypes);
						}
					}
				}
				if (labelList != null) {
					if (labelList.isArray())

						labelList.forEach(lable -> {
							Integer lableId = lable.get(dlpUtil.ID).asInt();
							idMap.put(lableId, lable);

							JsonNode visibilityType = lable.get(dlpUtil.VISIBILITY_TYPE);
							if (visibilityType == null || visibilityType.asBoolean()) {
								InputTypes inputTypes = new InputTypes();
								inputTypes.setFieldName(lable.get(dlpUtil.LABLE).textValue());
								// inputTypes.setDataKey(lable.get(dlpUtil.DATA_KEY).textValue());
								inputTypes.setFieldType(dlpUtil.LABLE);
								if (lable.get(dlpUtil.SEQUENCE_NUMBER) != null) {
									int seqNumber = lable.get(dlpUtil.SEQUENCE_NUMBER).asInt();
									inputTypes.setSeqNumber(seqNumber);
									sequenceMap.put(seqNumber, inputTypes);
									inputList.add(inputTypes);
								} else {
									int seqNumber = 10 + random.nextInt(80);
									inputTypes.setSeqNumber(seqNumber);
									sequenceMap.put(seqNumber, inputTypes);
									inputList.add(inputTypes);
								}

							}
						});

					else {
						Integer lableId = labelList.get(dlpUtil.ID).asInt();
						idMap.put(lableId, labelList);

						JsonNode visibilityType = labelList.get(dlpUtil.VISIBILITY_TYPE);
						if (visibilityType == null || visibilityType.asBoolean()) {
							InputTypes inputTypes = new InputTypes();
							inputTypes.setFieldName(labelList.get(dlpUtil.LABLE).textValue());
							inputTypes.setFieldType(dlpUtil.LABLE);

							if (labelList.get(dlpUtil.SEQUENCE_NUMBER) != null) {
								int seqNumber = labelList.get(dlpUtil.SEQUENCE_NUMBER).asInt();
								inputTypes.setSeqNumber(seqNumber);
								sequenceMap.put(seqNumber, inputTypes);
								inputList.add(inputTypes);
							} else {
								int seqNumber = 10 + random.nextInt(80);
								inputTypes.setSeqNumber(seqNumber);
								sequenceMap.put(seqNumber, inputTypes);
								inputList.add(inputTypes);
							}

						}
					}
				}
				if (numericList != null) {
					if (numericList.isArray())

						numericList.forEach(numeric -> {
							Integer numericId = numeric.get(dlpUtil.ID).asInt();
							idMap.put(numericId, numeric);

							JsonNode visibilityType = numeric.get(dlpUtil.VISIBILITY_TYPE);
							if (visibilityType == null || visibilityType.asBoolean()) {
								InputTypes inputTypes = new InputTypes();
								inputTypes.setFieldName(numeric.get(dlpUtil.LABLE).textValue());

								inputTypes.setDataKey(numeric.get(dlpUtil.DATA_KEY).textValue());

								if (numeric.get("source-name") != null && numeric.get("row-field") != null) {
									String tableName = numeric.get("source-name").textValue();
									String columnName = numeric.get("row-field").textValue();
									String result = commonUtil.getCounterPartyName(tableName, columnName,
											uniqueIdentifier);
									inputTypes.setCounterparty(result);
								}

								if (numeric.get("max-value") != null) {
									String maxLength = numeric.get("max-value").textValue();
									inputTypes.setMaxLength(Integer.parseInt(maxLength));

								}
								inputTypes.setFieldType(dlpUtil.NUMERIC);
								inputTypes.setMandatory(numeric.get(dlpUtil.MANDATORY).asBoolean());
								String seqNumber = numeric.get(dlpUtil.SEQUENCE_NUMBER).asText();
								inputTypes.setSeqNumber(Integer.parseInt(seqNumber));
								sequenceMap.put(Integer.parseInt(seqNumber), inputTypes);
								inputList.add(inputTypes);

							}
						});
					else {
						Integer numericId = numericList.get(dlpUtil.ID).asInt();
						idMap.put(numericId, numericList);

						JsonNode visibilityType = numericList.get(dlpUtil.VISIBILITY_TYPE);
						if (visibilityType == null || visibilityType.asBoolean()) {
							InputTypes inputTypes = new InputTypes();
							inputTypes.setFieldName(numericList.get(dlpUtil.LABLE).textValue());

							inputTypes.setDataKey(numericList.get(dlpUtil.DATA_KEY).textValue());

							if (numericList.get("source-name") != null && numericList.get("row-field") != null) {
								String tableName = numericList.get("source-name").textValue();
								String columnName = numericList.get("row-field").textValue();
								String result = commonUtil.getCounterPartyName(tableName, columnName, uniqueIdentifier);
								inputTypes.setCounterparty(result);
							}

							if (numericList.get("max-value") != null) {
								String maxLength = numericList.get("max-value").textValue();
								inputTypes.setMaxLength(Integer.parseInt(maxLength));

							}
							inputTypes.setFieldType(dlpUtil.NUMERIC);
							String seqNumber = numericList.get(dlpUtil.SEQUENCE_NUMBER).asText();
							inputTypes.setSeqNumber(Integer.parseInt(seqNumber));
							sequenceMap.put(Integer.parseInt(seqNumber), inputTypes);
							inputList.add(inputTypes);
						}
					}

					List<Integer> listInteger = new ArrayList<>();
					listInteger.addAll(sequenceMap.keySet());// ;.sort(sequenceMap.keySet())
					Collections.sort(listInteger);

					listInteger.forEach(seqData -> {
						inputListOrdered.add(sequenceMap.get(seqData));
					});

					sectionData.setSeqNumber(Integer.parseInt(sectionSeqNumber));
					sectionData.setTitle(title.textValue());
					sectionData.setInputType(inputListOrdered);
					sectionData.setType(dlpUtil.DYNAMIC_GRID);
					dynamicGridList.add(sectionData);

				}
			});
		}

		return dynamicGridList;

	}

	public List<EntryFormRule> getDropdownGridRule(JsonNode node) {

		JsonNode sectionList = node.get("dropdown-grid-rule");
		List<EntryFormRule> entryForm = new ArrayList<>();
		if (sectionList != null && sectionList.isArray()) {
			sectionList.forEach(section -> {

				JsonNode visibilityTyp_1 = section.get(dlpUtil.VISIBILITY_TYPE);
				if (visibilityTyp_1 == null || visibilityTyp_1.asBoolean()) {

					EntryFormRule entryFormRule = new EntryFormRule();
					LinkedHashMap<Integer, ControlAction> sequenceMap = new LinkedHashMap<>();
					List<String> valueList = new ArrayList<>();
					JsonNode fieldName = section.get("field-name");
					JsonNode valueName = section.get("value-name");
					JsonNode controlActionList = section.get("control-action");
					JsonNode gridFieldActionList = section.get("grid-field-action");
					String sectionSeqNumber = section.get(dlpUtil.ID).textValue();
					LinkedList<ControlAction> controlActionOrdered = new LinkedList<>();

					String gridFieldAct = "";
					String controlActt = "";

					if (gridFieldActionList != null && !gridFieldActionList.isArray()) {
						JsonNode visibilityType = gridFieldActionList.get(dlpUtil.VISIBILITY_TYPE);
						if (visibilityType == null || visibilityType.asBoolean()) {
							gridFieldAct = "grid-field-action";
							ControlAction controlAct = new ControlAction();
							List<String> labelList = new ArrayList<>();

							controlAct.setActionName(gridFieldActionList.get("action-name").textValue());
							String multipleValues = gridFieldActionList.get("field-name").textValue();
							if (multipleValues.equalsIgnoreCase(dlpUtil.MULTIPLE_VALUES)) {
								String fieldId = gridFieldActionList.get("field-id").textValue();
								String[] splitId = fieldId.split("\n");
								for (String id : splitId) {
									labelList.add(id);
								}
								controlAct.setControlName(labelList);
							} else {

								labelList.add(gridFieldActionList.get("field-id").textValue());
								controlAct.setControlName(labelList);
							}
							controlAct.setMatchType(gridFieldActionList.get("match-type").asText());
							String seqNumber = (gridFieldActionList.get(dlpUtil.ID).textValue());
							controlAct.setSeqNumber(Integer.parseInt(seqNumber));
							controlAct.setMatchType(gridFieldActionList.get("match-type").asText());
							sequenceMap.put(Integer.parseInt(seqNumber), controlAct);
						}

					}

					else if (gridFieldActionList != null && gridFieldActionList.isArray()) {
						gridFieldAct = "grid-field-action";
						gridFieldActionList.forEach(gridFieldAction -> {
							JsonNode visibilityType = gridFieldAction.get(dlpUtil.VISIBILITY_TYPE);
							if (visibilityType == null || visibilityType.asBoolean()) {
								ControlAction controlAct = new ControlAction();
								List<String> labelList = new ArrayList<>();

								controlAct.setActionName(gridFieldAction.get("action-name").textValue());

								String multipleValues = gridFieldAction.get("field-name").textValue();
								if (multipleValues.equalsIgnoreCase(dlpUtil.MULTIPLE_VALUES)) {
									String fieldId = gridFieldAction.get("field-id").textValue();
									String[] splitId = fieldId.split("\n");
									for (String id : splitId) {
										labelList.add(id);
									}
									controlAct.setControlName(labelList);
								} else {

									labelList.add(gridFieldAction.get("field-id").textValue());
									controlAct.setControlName(labelList);
								}
								controlAct.setMatchType(gridFieldAction.get("match-type").asText());
								String seqNumber = gridFieldAction.get(dlpUtil.ID).textValue();
								controlAct.setSeqNumber(Integer.parseInt(seqNumber));
								controlAct.setMatchType(gridFieldAction.get("match-type").asText());
								sequenceMap.put(Integer.parseInt(seqNumber), controlAct);
							}
						});
					}

					if (controlActionList != null && !controlActionList.isArray()) {

						JsonNode visibilityType = controlActionList.get(dlpUtil.VISIBILITY_TYPE);
						if (visibilityType == null || visibilityType.asBoolean()) {
							controlActt = "control-action";

							ControlAction controlAct = new ControlAction();
							List<String> labelList = new ArrayList<>();

							controlAct.setActionName(controlActionList.get("action-name").textValue());
							labelList.add(controlActionList.get("control-name").textValue());
							controlAct.setControlName(labelList);
							String seqNumber = (controlActionList.get(dlpUtil.ID).textValue());
							controlAct.setSeqNumber(Integer.parseInt(seqNumber));
							controlAct.setMatchType(controlActionList.get("match-type").asText());
							sequenceMap.put(Integer.parseInt(seqNumber), controlAct);
						}
					}

					else if (controlActionList != null && controlActionList.isArray()) {
						controlActt = "control-action";
						controlActionList.forEach(controlAction -> {
							JsonNode visibilityType = controlAction.get(dlpUtil.VISIBILITY_TYPE);
							if (visibilityType == null || visibilityType.asBoolean()) {
								ControlAction controlAct = new ControlAction();
								List<String> labelList = new ArrayList<>();

								controlAct.setActionName(controlAction.get("action-name").textValue());
								labelList.add(controlAction.get("control-name").textValue());
								controlAct.setControlName(labelList);
								String seqNumber = controlAction.get(dlpUtil.ID).textValue();
								controlAct.setSeqNumber(Integer.parseInt(seqNumber));
								controlAct.setMatchType(controlAction.get("match-type").asText());
								sequenceMap.put(Integer.parseInt(seqNumber), controlAct);
							}
						});
					}

					List<Integer> listInteger = new ArrayList<>();
					listInteger.addAll(sequenceMap.keySet());// ;.sort(sequenceMap.keySet())
					Collections.sort(listInteger);

					listInteger.forEach(seqData -> {
						controlActionOrdered.add(sequenceMap.get(seqData));
					});

					if (gridFieldAct.equalsIgnoreCase("grid-field-action")) {
						entryFormRule.setGridFieldAction(controlActionOrdered);
					} else if (controlActt.equalsIgnoreCase("control-action")) {
						entryFormRule.setControlAction(controlActionOrdered);
					}
					entryFormRule.setSeqNumber(Integer.parseInt(sectionSeqNumber));

					if (valueName.textValue().equalsIgnoreCase(dlpUtil.MULTIPLE_VALUES)) {
						String values = section.get("values").textValue();
						int fieldId = section.get("field-id").asInt();
						JsonNode controlNode = idMap.get(fieldId);
						JsonNode optionList = controlNode.get("option");
						if (optionList != null) {
							LinkedHashMap<Integer, JsonNode> optionMap = new LinkedHashMap<>();
							if (optionList.isArray()) {
								optionList.forEach(option -> {
									int value = option.get("value").asInt();
									optionMap.put(value, option);
								});
							} else {
								int value = optionList.get("value").asInt();
								optionMap.put(value, optionList);
							}
							String[] splitId = values.split("\n");
							for (String idd : splitId) {
								int id = Integer.parseInt(idd);
								JsonNode opt = optionMap.get(id);
								String text = opt.get("text").textValue();
								valueList.add(text);

							}
						}
						entryFormRule.setValueName(valueList);
					} else {
						valueList.add(valueName.textValue());
						entryFormRule.setValueName(valueList);
					}

					entryFormRule.setFieldName(fieldName.textValue());
					entryForm.add(entryFormRule);
				}
			});
		}

		else if (sectionList != null && !sectionList.isArray()) {

			JsonNode section = sectionList;

			JsonNode visibilityType_1 = section.get(dlpUtil.VISIBILITY_TYPE);
			if (visibilityType_1 == null && visibilityType_1.asBoolean()) {

				EntryFormRule entryFormRule = new EntryFormRule();
				LinkedHashMap<Integer, ControlAction> sequenceMap = new LinkedHashMap<>();
				List<String> valueList = new ArrayList<>();
				JsonNode fieldName = section.get("field-name");
				JsonNode valueName = section.get("value-name");
				JsonNode controlActionList = section.get("control-action");
				JsonNode gridFieldActionList = section.get("grid-field-action");
				String sectionSeqNumber = section.get(dlpUtil.ID).textValue();
				LinkedList<ControlAction> controlActionOrdered = new LinkedList<>();

				String gridFieldAct = "";
				String controlActt = "";

				if (gridFieldActionList != null && !gridFieldActionList.isArray()) {

					JsonNode visibilityType = gridFieldActionList.get(dlpUtil.VISIBILITY_TYPE);
					if (visibilityType == null || visibilityType.asBoolean()) {
						gridFieldAct = "grid-field-action";

						ControlAction controlAct = new ControlAction();
						List<String> labelList = new ArrayList<>();
						controlAct.setActionName(gridFieldActionList.get("action-name").textValue());
						String multipleValues = gridFieldActionList.get("field-name").textValue();
						if (multipleValues.equalsIgnoreCase(dlpUtil.MULTIPLE_VALUES)) {
							String fieldId = gridFieldActionList.get("field-id").textValue();
							String[] splitId = fieldId.split("\n");
							for (String id : splitId) {
								labelList.add(id);
							}
							controlAct.setControlName(labelList);
						} else {

							labelList.add(gridFieldActionList.get("field-id").textValue());
							controlAct.setControlName(labelList);
						}
						controlAct.setMatchType(gridFieldActionList.get("match-type").asText());
						String seqNumber = (gridFieldActionList.get(dlpUtil.ID).textValue());
						controlAct.setSeqNumber(Integer.parseInt(seqNumber));
						controlAct.setMatchType(gridFieldActionList.get("match-type").asText());
						sequenceMap.put(Integer.parseInt(seqNumber), controlAct);

					}

				}

				else if (gridFieldActionList != null && gridFieldActionList.isArray()) {

					gridFieldAct = "grid-field-action";

					gridFieldActionList.forEach(gridFieldAction -> {
						JsonNode visibilityType = gridFieldAction.get(dlpUtil.VISIBILITY_TYPE);
						if (visibilityType == null || visibilityType.asBoolean()) {
							ControlAction controlAct = new ControlAction();
							List<String> labelList = new ArrayList<>();
							controlAct.setActionName(gridFieldAction.get("action-name").textValue());
							String multipleValues = gridFieldAction.get("field-name").textValue();
							if (multipleValues.equalsIgnoreCase(dlpUtil.MULTIPLE_VALUES)) {
								String fieldId = gridFieldAction.get("field-id").textValue();
								String[] splitId = fieldId.split("\n");
								for (String id : splitId) {
									labelList.add(id);
								}
								controlAct.setControlName(labelList);
							} else {

								labelList.add(gridFieldAction.get("field-id").textValue());
								controlAct.setControlName(labelList);
							}
							controlAct.setMatchType(gridFieldAction.get("match-type").asText());
							String seqNumber = gridFieldAction.get(dlpUtil.ID).textValue();
							controlAct.setSeqNumber(Integer.parseInt(seqNumber));
							controlAct.setMatchType(gridFieldAction.get("match-type").asText());
							sequenceMap.put(Integer.parseInt(seqNumber), controlAct);
						}
					});
				}

				if (controlActionList != null && !controlActionList.isArray()) {

					JsonNode visibilityType = controlActionList.get(dlpUtil.VISIBILITY_TYPE);
					if (visibilityType == null || visibilityType.asBoolean()) {
						controlActt = "control-action";
						ControlAction controlAct = new ControlAction();
						List<String> labelList = new ArrayList<>();
						controlAct.setActionName(controlActionList.get("action-name").textValue());
						labelList.add(controlActionList.get("control-name").textValue());
						controlAct.setControlName(labelList);
						String seqNumber = (controlActionList.get(dlpUtil.ID).textValue());
						controlAct.setSeqNumber(Integer.parseInt(seqNumber));
						controlAct.setMatchType(controlActionList.get("match-type").asText());
						sequenceMap.put(Integer.parseInt(seqNumber), controlAct);
					}
				}

				else if (controlActionList != null && controlActionList.isArray()) {

					controlActt = "control-action";

					controlActionList.forEach(controlAction -> {
						JsonNode visibilityType = controlAction.get(dlpUtil.VISIBILITY_TYPE);
						if (visibilityType == null || visibilityType.asBoolean()) {
							ControlAction controlAct = new ControlAction();
							List<String> labelList = new ArrayList<>();
							controlAct.setActionName(controlAction.get("action-name").textValue());
							labelList.add(controlAction.get("control-name").textValue());
							controlAct.setControlName(labelList);
							String seqNumber = controlAction.get(dlpUtil.ID).textValue();
							controlAct.setSeqNumber(Integer.parseInt(seqNumber));
							controlAct.setMatchType(controlAction.get("match-type").asText());
							sequenceMap.put(Integer.parseInt(seqNumber), controlAct);
						}
					});
				}

				List<Integer> listInteger = new ArrayList<>();
				listInteger.addAll(sequenceMap.keySet());// ;.sort(sequenceMap.keySet())
				Collections.sort(listInteger);

				listInteger.forEach(seqData -> {
					controlActionOrdered.add(sequenceMap.get(seqData));
				});
				if (gridFieldAct.equalsIgnoreCase("grid-field-action")) {
					entryFormRule.setGridFieldAction(controlActionOrdered);
				} else if (controlActt.equalsIgnoreCase("control-action")) {
					entryFormRule.setControlAction(controlActionOrdered);
				}
				entryFormRule.setSeqNumber(Integer.parseInt(sectionSeqNumber));

				if (valueName.textValue().equalsIgnoreCase(dlpUtil.MULTIPLE_VALUES)) {
					String values = section.get("values").textValue();
					int fieldId = section.get("field-id").asInt();
					JsonNode controlNode = idMap.get(fieldId);
					JsonNode optionList = controlNode.get("option");
					if (optionList != null) {
						LinkedHashMap<Integer, JsonNode> optionMap = new LinkedHashMap<>();
						if (optionList.isArray()) {
							optionList.forEach(option -> {
								int value = option.get("value").asInt();
								optionMap.put(value, option);
							});
						} else {
							int value = optionList.get("value").asInt();
							optionMap.put(value, optionList);
						}
						String[] splitId = values.split("\n");
						for (String idd : splitId) {
							int id = Integer.parseInt(idd);
							JsonNode opt = optionMap.get(id);
							String text = opt.get("text").textValue();
							valueList.add(text);

						}
					}
					entryFormRule.setValueName(valueList);
				} else {
					valueList.add(valueName.textValue());
					entryFormRule.setValueName(valueList);
				}
				entryFormRule.setFieldName(fieldName.textValue());
				entryForm.add(entryFormRule);
			}
		}

		return entryForm;

	}
}
