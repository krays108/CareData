package com.care.BOBDLPAPI.model.dto;

import java.sql.Timestamp;
import java.time.LocalDateTime;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.JsonNode;

import lombok.Data;

@Data
@Component
public class LoanDataDto {

	public Long loanDataId;

	public String customerId;

	public JsonNode jsonData;

	public String description;

	public Timestamp createdDate = Timestamp.valueOf(LocalDateTime.now());

	public Integer revisionNumber;

	public Integer isValidated;

	public Integer journeySetuId;

	public String uniqueIdentifier;

	public String uniqueIdentifierNumber;

}
