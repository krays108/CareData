package com.care.BOBDLPAPI.service;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.care.BOBDLPAPI.model.DocumentDetails;
import com.care.BOBDLPAPI.model.dto.DocumentDetailsDto;
import com.care.BOBDLPAPI.repository.DocumentDetailsRepository;
import com.care.BOBDLPAPI.util.BobUtil;
import com.care.BOBDLPAPI.util.DlpUtil;



@Service
public class DocumentDetailsService {
	
	@Autowired
	DocumentDetailsRepository  documentDetailsRepository;
	
	@Autowired
	DlpUtil dlpUtil;
	
	@Autowired
	BobUtil bobUtil;
	
	@Autowired
	private ModelMapper modelMapper;
	

	public ResponseEntity<List<DocumentDetails>> addDoucmentDetails(List<DocumentDetailsDto> documentDetailsDto) {
		
		List<DocumentDetails> documentDtls= new ArrayList<>();
		
		
		
		
		documentDetailsDto.forEach(n->{
		
			
		      try {
		    	  System.out.println("before split ::: "+n.getDocumentContent());
		    	  String[] tokens=n.getDocumentContent().split(",");  
		    	  System.out.println("After split ::: "+tokens[1].trim());

		
			MultipartFile    file =	BobUtil.convertBase64ToMultipartFile(tokens[1]);
    	  
    	  DocumentDetails	documentDetails = DocumentDetails.builder()
								.createdDate(new Timestamp(System.currentTimeMillis()))
								.customerId(n.getCustomerId())
								.documentContent(file.getBytes())
								.documentFileName(n.getDocumentFileName())
								.documentIdLos(n.getDocumentIdLos())
								.documentType(n.getDocumentType())
								.journeySetupId(n.getJourneySetupId())
								.build();
			documentDtls.add(documentDetails);

		} catch (IOException e) {
			e.printStackTrace();
		}
			
			
		});
		
		/*
		 * List<DocumentDetails> documentDetails = Arrays
		 * .asList(modelMapper.map(documentDetailsDto, DocumentDetails[].class));
		 * List<DocumentDetails> documentDtls =
		 * documentDetailsRepository.saveAll(documentDetails); List<DocumentDetailsDto>
		 * documentDto = Arrays.asList(modelMapper.map(documentDtls,
		 * DocumentDetailsDto[].class));
		 */
		
		documentDetailsRepository.saveAll(documentDtls);
		
		return ResponseEntity.ok(documentDtls);
	}

	public ResponseEntity<List<DocumentDetailsDto>> getDocumentDetails(String customerId) {
		List<DocumentDetails> documentDtls = documentDetailsRepository.findByCustomerId(customerId);
	//	List<DocumentDetailsDto> documentDto= Arrays.asList(modelMapper.map(documentDtls, DocumentDetailsDto[].class));
		List<DocumentDetailsDto> documentDto= new ArrayList<>();
		
		documentDtls.forEach(n ->{
			DocumentDetailsDto docDtls=	DocumentDetailsDto.builder()
								.createdDate(n.getCreatedDate())
								.customerId(n.getCustomerId())
					//			.documentContent(new String(n.getDocumentContent()))
						//		.documentContentFile(new File(n.getDocumentContent().))
								.documentFileName(n.getDocumentFileName())
								.documentId(n.getDocumentId())
								.documentIdLos(n.getDocumentIdLos())
								.documentType(n.getDocumentType())
								.journeySetupId(n.getJourneySetupId())
								.build();
			
			documentDto.add(docDtls);
		});
		
		
		return ResponseEntity.ok(documentDto);
	}


	
}
