package com.care.BOBDLPAPI.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.care.BOBDLPAPI.dto.TransactionDetailsDto;
import com.care.BOBDLPAPI.model.TransactionDetails;
import com.care.BOBDLPAPI.model.dto.TransactionDtlsDto;
import com.care.BOBDLPAPI.repository.TransactionDetailsRepository;
import com.care.BOBDLPAPI.util.DlpUtil;

@Service
public class TransactionDetailsService {
	
	@Autowired
	TransactionDetailsRepository transactionDetailsRepository;
	
	@Autowired DlpUtil dlpUtil;
	
	@Autowired private ModelMapper modelMapper;

	
	public ResponseEntity<TransactionDtlsDto> saveTransactionDetails(TransactionDtlsDto transactionDtlsDto) {
		TransactionDetails transactionDtls=	modelMapper.map(transactionDtlsDto, TransactionDetails.class);
		TransactionDetails transactionDetails=	 transactionDetailsRepository.save(transactionDtls) ;
		TransactionDtlsDto dto=  modelMapper.map(transactionDetails, TransactionDtlsDto.class);
		 return  ResponseEntity.ok(dto);
	}

	public ResponseEntity<?> getTransactionDetails(String customerId) {
	List<TransactionDetails> transactionDtls=
			transactionDetailsRepository.findByCustomerId(customerId);
 if(transactionDtls.isEmpty()) {
	 return ResponseEntity.ok(dlpUtil.INVALID_CUSTOMER);
 }
	
	List<TransactionDtlsDto> DtoList = Arrays.asList(modelMapper.map(transactionDtls, TransactionDtlsDto[].class));
		return ResponseEntity.ok(DtoList) ;
	}
	

	public ResponseEntity<?> getResumeApplication(Long mobile) {
		
		List<String> customerIdList = transactionDetailsRepository.findCustomerIdByMobile(mobile);
		if(customerIdList.isEmpty()) {
			return ResponseEntity.ok(dlpUtil.INVALID_CUSTOMER);
		}
		List<TransactionDetailsDto> transactionDtlsList=new ArrayList<>();

		customerIdList.forEach(customerId->{
			TransactionDetailsDto transactionDtls=	transactionDetailsRepository.findResumeByCustomerId(customerId).get(0);
		transactionDtlsList.add(transactionDtls);
		} );
	
	if(transactionDtlsList.isEmpty()) {
		return ResponseEntity.ok(dlpUtil.INVALID_CUSTOMER);
	}
	
	  
	
		return ResponseEntity.ok(transactionDtlsList);
	
		
	}

	


}
