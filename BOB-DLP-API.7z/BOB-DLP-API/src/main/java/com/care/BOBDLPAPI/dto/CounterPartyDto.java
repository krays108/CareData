package com.care.BOBDLPAPI.dto;


public interface CounterPartyDto {
	
	public Integer getCounterparty_id();
	
	public String getName();

}
