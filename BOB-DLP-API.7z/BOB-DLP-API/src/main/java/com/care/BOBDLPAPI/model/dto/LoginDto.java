package com.care.BOBDLPAPI.model.dto;

import java.sql.Timestamp;
import java.time.LocalDateTime;

import lombok.Data;

@Data
public class LoginDto {

	public Long loginId;

	public String fullName;

	public Long mobile;

	public String email;

	public String agreeDtc;

	public String mobileOtp;

	public String emailOtp;

	public String customerId;

	public Timestamp loggedInDate = Timestamp.valueOf(LocalDateTime.now());

	public Timestamp loggedOutDate;

	public String ip;

	public String lockedStatus;

	public String loanType;

	public String purposeOfLoan;

	public String agentCode;

	public String uniqueIdentifier;

	public String uniqueIdentifierNumber;

	public String sourceOfRequest;

	public Integer journeySetupId;

	public Integer productTypeId;

	public Integer productId;
	
	public String product;
	
	public String subProduct;
}
