package com.care.BOBDLPAPI.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.care.BOBDLPAPI.model.LoanData;
import com.care.BOBDLPAPI.model.dto.LoanDataDto;
import com.care.BOBDLPAPI.service.LoanDataService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
//@ApiIgnore
@CrossOrigin(origins="*")
@RestController
@RequestMapping(value =  "/dlp/api",produces="application/json")
public class LoanDataController {
	
	@Autowired LoanDataService loanDataService;
	
	@PostMapping("/saveLoanData")
	public ResponseEntity<LoanData> saveLoanData(@RequestBody LoanDataDto loanDataDto   ){
		return loanDataService.saveLoanData(loanDataDto);
		
	}
	
	@GetMapping("/getLoanDataInJson")
	public ResponseEntity<?> getLoanDataInJson(@RequestHeader String customerId) throws JsonMappingException, JsonProcessingException{
		return loanDataService.getLoanDataInJson(customerId);
		
	}

}
