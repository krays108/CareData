package com.care.BOBDLPAPI.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.care.BOBDLPAPI.model.History;

@Repository
public interface HistoryRepository extends CrudRepository<History, Long> {

}
