package com.care.BOBDLPAPI.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.care.BOBDLPAPI.dto.AdefXmlDto;
import com.care.BOBDLPAPI.dto.ConfigList;
import com.care.BOBDLPAPI.dto.Entity;
import com.care.BOBDLPAPI.dto.EntityDto;
import com.care.BOBDLPAPI.dto.OutParameter;
import com.care.BOBDLPAPI.model.AdefAppform;



@Repository
public interface AdefRepository extends JpaRepository<AdefAppform, Integer> {
	
	

	@Query(value =  "select XML_DATA from KCR_ADEF_APPFORM a  join KCR_JOURNEY_APPFORM  b on a.ADEF_APPFORM_ID = b.ADEF_APPFORM_ID where b.JOURNEY_SETUP_ID=?1",nativeQuery = true)
	AdefXmlDto getXmlData(Integer journeySetupId);

	@Query(value="select text1 as tablename from kco_config_list where text0=?1",nativeQuery=true)
	String findBySystemDataKey(String source);

	@Query(value="select CODE, DESCRIPTION from kcr_dzongkhag",nativeQuery=true)
	List<EntityDto> findByDzongkhag(String tableName);

	@Query(value="select CODE, DESCRIPTION from kcr_gewog",nativeQuery=true)
	List<EntityDto> findByGewog(String tableName);
	
	@Query(value="select CODE, DESCRIPTION from kco_entity",nativeQuery=true)
	List<EntityDto> findByEntity(String tableName);
	
	@Query(value="select get_code('kco_entity') as Entity  from dual",nativeQuery=true)
	List<Entity> findByFunction(String tableName);

	@Query(value="select dynamic_query1(:tableName,:columnName,:uniqueIdentifier) as result from dual",nativeQuery=true)
	String findCounterPartyId(String tableName ,String columnName, String uniqueIdentifier );

	@Query(value="select config_list_id as Code, text1 as Description from kco_config_list where config_code=?1 order by text1 asc",nativeQuery=true)
	List<EntityDto> getConfigList(String tableName);

	@Query(value="select TEXT2 from kco_config_list where config_code='SOURCE_MAPPING' and TEXT0=?1",nativeQuery=true)
	String getTableForConfig(String source);
	
	@Query(value="select CODE,DESCRIPTION from kcr_gewog WHERE DZONGKHAG_ID=(select DZONGKHAG_ID from kcr_dzongkhag WHERE CODE=?1)",nativeQuery = true)
	List<EntityDto> findEntityDtoByCode(String code);

	

}
